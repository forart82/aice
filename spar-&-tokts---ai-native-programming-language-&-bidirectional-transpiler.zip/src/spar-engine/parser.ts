/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SPAR AST Parser: Constructs univalent Universal AST from token stream
 */

import { Token, tokenizeSpar } from "./tokenizer.ts";
import {
  SparModule,
  SparEntity,
  SparTypeDecl,
  SparFunctionDecl,
  SparComponentDecl,
  SparStyleDecl,
  SparTypeExpr,
  PrimitiveKind,
  SparParam,
  SparExpr,
  SparLayoutNode,
  SourceSpan,
  EffectKind,
  DiagnosticEntry
} from "./types.ts";

export interface ParseResult {
  module: SparModule | null;
  diagnostics: DiagnosticEntry[];
}

export function parseSpar(source: string): ParseResult {
  const tokens = tokenizeSpar(source);
  const diagnostics: DiagnosticEntry[] = [];
  let idx = 0;

  function peek(): Token {
    return tokens[idx] || { type: "EOF", value: "", line: 0, col: 0, offset: 0 };
  }

  function next(): Token {
    const t = peek();
    if (idx < tokens.length) idx++;
    return t;
  }

  function spanOf(t: Token): SourceSpan {
    return { line: t.line, col: t.col, symbol: t.value };
  }

  function match(type: string): boolean {
    if (peek().type === type) {
      next();
      return true;
    }
    return false;
  }

  function expect(type: string): Token {
    const t = next();
    if (t.type !== type) {
      diagnostics.push({
        status: "REJECTED",
        error_phase: "SYNTACTIC_CONFORMANCE",
        span: spanOf(t),
        violation: {
          code: "E1001_UNEXPECTED_TOKEN",
          message: `Expected token type '${type}', but encountered '${t.type}' ('${t.value}') at line ${t.line}:${t.col}.`
        },
        invariant_correction_rule: `Insert expected '${type}' delimiter before '${t.value}'.`,
        fix: type === "RPAREN" ? ")" : type === "ATTR_END" ? ".)" : ""
      });
    }
    return t;
  }

  // Parse root module
  const firstTok = peek();
  if (firstTok.type !== "MODULE_TAG") {
    diagnostics.push({
      status: "REJECTED",
      error_phase: "SYNTACTIC_CONFORMANCE",
      span: spanOf(firstTok),
      violation: {
        code: "E1000_MISSING_MODULE_HEADER",
        message: "A SPAR translation unit must begin with an '(@module <identifier>' declaration."
      },
      invariant_correction_rule: "Prepend '(@module <id> ... )' container around your definitions.",
      fix: "(@module app\n"
    });
    return { module: null, diagnostics };
  }

  next(); // consume (@module
  const moduleIdTok = expect("SYMBOL");
  const moduleId = moduleIdTok.value || "unnamed";

  const manifest: Record<string, string | number | boolean> = {};
  const dependencies: SparModule["dependencies"] = [];
  const entities: SparEntity[] = [];

  // Parse inner module constructs until closing RPAREN
  while (peek().type !== "EOF" && peek().type !== "RPAREN") {
    const cur = peek();

    // Manifest (* key "value" ... *)
    if (cur.type === "MANIFEST_BEG") {
      next();
      while (peek().type !== "MANIFEST_END" && peek().type !== "EOF") {
        const kTok = expect("SYMBOL");
        const vTok = next();
        let val: string | number | boolean = vTok.value;
        if (vTok.type === "NUMBER") val = Number(vTok.value);
        if (vTok.type === "BOOLEAN") val = vTok.value === "true";
        manifest[kTok.value] = val;
      }
      expect("MANIFEST_END");
      continue;
    }

    // Dependencies (deps ( (mod sym1 sym2) ... ))
    if (cur.type === "LPAREN" && tokens[idx + 1]?.value === "deps") {
      next(); // (
      next(); // deps
      if (peek().type === "LPAREN") {
        next(); // (
        while (peek().type !== "RPAREN" && peek().type !== "EOF") {
          if (peek().type === "LPAREN") {
            next();
            const modPathTok = next();
            const modPath = modPathTok.value;
            const importedSyms: string[] = [];
            while (peek().type !== "RPAREN" && peek().type !== "EOF") {
              importedSyms.push(next().value);
            }
            expect("RPAREN");
            dependencies.push({ modulePath: modPath, imports: importedSyms });
          } else {
            next();
          }
        }
        expect("RPAREN");
      }
      expect("RPAREN");
      continue;
    }

    // Type Declaration (: Name TypeExpr)
    if (cur.type === "TYPE_DECL") {
      next();
      const nameTok = expect("SYMBOL");
      const typeExpr = parseTypeExpr();
      expect("RPAREN");
      entities.push({
        kind: "TypeDecl",
        name: nameTok.value,
        typeExpr,
        isExported: true,
        span: spanOf(nameTok)
      });
      continue;
    }

    // Function Declaration (! Name (-> (params) RetType) Body)
    if (cur.type === "FN_DECL") {
      next();
      const fnNameTok = next();
      const fnName = fnNameTok.value;

      // Check if it's a test: (!test "..." (-> () ...))
      if (fnName === "test" || fnName === "describe") {
        const testNameTok = next();
        const testSig = parseTypeExpr();
        const testBody = parseExpr();
        expect("RPAREN");
        entities.push({
          kind: "FunctionDecl",
          name: `__test_${testNameTok.value.replace(/[^a-zA-Z0-9]/g, "_")}`,
          params: [],
          returnType: { kind: "PrimitiveType", name: "!void" },
          body: testBody,
          effects: ["IO"],
          isExported: false,
          span: spanOf(fnNameTok)
        });
        continue;
      }

      // Standard function signature (-> (p1 t1 p2 t2) RetType)
      let params: SparParam[] = [];
      let retType: SparTypeExpr = { kind: "PrimitiveType", name: "!void" };
      let effects: EffectKind[] = [];

      if (peek().type === "LPAREN" && tokens[idx + 1]?.type === "ARROW") {
        next(); // (
        next(); // ->
        // Parameter list
        if (peek().type === "LPAREN") {
          next(); // (
          while (peek().type !== "RPAREN" && peek().type !== "EOF") {
            const pName = next().value;
            const pType = parseTypeExpr();
            params.push({ name: pName, type: pType });
          }
          expect("RPAREN");
        } else if (peek().type === "SYMBOL" && peek().value === "%") {
          // Record shorthand parameter e.g. (% canvas !unknown)
          const pType = parseTypeExpr();
          if (pType.kind === "RecordType") {
            params = pType.fields.map(f => ({ name: f.name, type: f.type }));
          }
        }
        retType = parseTypeExpr();
        if (retType.kind === "EffectType") {
          effects = retType.effects;
        }
        expect("RPAREN");
      }

      const body = parseExpr();
      expect("RPAREN");
      entities.push({
        kind: "FunctionDecl",
        name: fnName,
        params,
        returnType: retType,
        body,
        effects,
        isExported: true,
        span: spanOf(fnNameTok)
      });
      continue;
    }

    // Component Declaration (# Name PropContract LayoutNode)
    if (cur.type === "COMP_DECL") {
      next();
      const compNameTok = expect("SYMBOL");
      let props: Array<{ name: string; type: SparTypeExpr }> = [];
      let propContractName: string | undefined;

      // Parse prop contract
      if (peek().type === "LPAREN") {
        const pType = parseTypeExpr();
        if (pType.kind === "RecordType") {
          props = pType.fields.map(f => ({ name: f.name, type: f.type }));
        } else if (pType.kind === "TypeRef") {
          propContractName = pType.name;
        }
      }

      // Component body (state/hooks) and layout node
      let bodyExpr: SparExpr = { kind: "BlockExpr", expressions: [] };
      let layoutNode: SparLayoutNode;

      if (peek().type === "LPAREN" && tokens[idx + 1]?.value === "do") {
        bodyExpr = parseExpr();
        layoutNode = parseLayoutNode();
      } else {
        layoutNode = parseLayoutNode();
      }

      expect("RPAREN");
      entities.push({
        kind: "ComponentDecl",
        name: compNameTok.value,
        props,
        propContractName,
        body: bodyExpr,
        layout: layoutNode,
        span: spanOf(compNameTok)
      });
      continue;
    }

    // Style Declaration (& Name (+ prop val ... +))
    if (cur.type === "STYLE_DECL") {
      next();
      const styleNameTok = expect("SYMBOL");
      const rules: SparStyleDecl["rules"] = [];
      if (peek().type === "STYLE_BEG") {
        next();
        while (peek().type !== "STYLE_END" && peek().type !== "EOF") {
          const propTok = expect("SYMBOL");
          const valTok = next();
          rules.push({ property: propTok.value, value: valTok.value });
        }
        expect("STYLE_END");
      }
      expect("RPAREN");
      entities.push({
        kind: "StyleDecl",
        name: styleNameTok.value,
        rules,
        span: spanOf(styleNameTok)
      });
      continue;
    }

    // Skip stray token
    next();
  }

  // Consume final RPAREN if present
  if (peek().type === "RPAREN") {
    next();
  }

  return {
    module: {
      id: moduleId,
      manifest,
      dependencies,
      entities,
      rawSource: source
    },
    diagnostics
  };

  // Helper: Parse Type Expressions
  function parseTypeExpr(): SparTypeExpr {
    const t = peek();

    // Refinement type (?: symbol primitive predicate)
    if (t.type === "LPAREN" && tokens[idx + 1]?.value === "?:") {
      next(); // (
      next(); // ?:
      const symTok = expect("SYMBOL");
      const baseTok = expect("SYMBOL");
      const pred = parseExpr();
      expect("RPAREN");
      return {
        kind: "RefinementType",
        symbol: symTok.value,
        baseType: baseTok.value as PrimitiveKind,
        predicate: pred,
        span: spanOf(symTok)
      };
    }

    // Linear Typestate (~ S1 -> S2)
    if (t.type === "TYPESTATE_OP") {
      next(); // (~
      const fromTok = expect("SYMBOL");
      expect("ARROW");
      const toTok = expect("SYMBOL");
      expect("RPAREN");
      return {
        kind: "TypestateType",
        resource: "Resource",
        fromState: fromTok.value,
        toState: toTok.value,
        span: spanOf(fromTok)
      };
    }

    // Algebraic Effect Type (!^ RetType [Effects])
    if (t.type === "EFFECT_OP") {
      next(); // (!^
      const innerRet = parseTypeExpr();
      const effects: EffectKind[] = [];
      if (peek().type === "LBRACKET") {
        next();
        while (peek().type !== "RBRACKET" && peek().type !== "EOF") {
          const effTok = next();
          effects.push(effTok.value as EffectKind);
        }
        expect("RBRACKET");
      }
      expect("RPAREN");
      return {
        kind: "EffectType",
        returnType: innerRet,
        effects,
        span: spanOf(t)
      };
    }

    // Union Type (| t1 t2 ...)
    if (t.type === "LPAREN" && tokens[idx + 1]?.value === "|") {
      next(); // (
      next(); // |
      const types: SparTypeExpr[] = [];
      while (peek().type !== "RPAREN" && peek().type !== "EOF") {
        types.push(parseTypeExpr());
      }
      expect("RPAREN");
      return { kind: "UnionType", types, span: spanOf(t) };
    }

    // Record Type (% field1 type1 field2 type2 ...)
    if (t.type === "LPAREN" && tokens[idx + 1]?.value === "%") {
      next(); // (
      next(); // %
      const fields: Array<{ name: string; type: SparTypeExpr; optional?: boolean }> = [];
      while (peek().type !== "RPAREN" && peek().type !== "EOF") {
        const fName = next().value;
        const isOpt = fName.endsWith("?");
        const cleanName = isOpt ? fName.slice(0, -1) : fName;
        const fType = parseTypeExpr();
        fields.push({ name: cleanName, type: fType, optional: isOpt });
      }
      expect("RPAREN");
      return { kind: "RecordType", fields, span: spanOf(t) };
    }

    // Result[T, E] from TokTS
    if (t.type === "SYMBOL" && t.value === "Result" && tokens[idx + 1]?.type === "LBRACKET") {
      next(); // Result
      next(); // [
      const okT = parseTypeExpr();
      match("COMMA");
      const errT = parseTypeExpr();
      expect("RBRACKET");
      return { kind: "ResultType", okType: okT, errType: errT, span: spanOf(t) };
    }

    // Primitive Type
    if (t.type === "SYMBOL" && t.value.startsWith("!")) {
      next();
      return { kind: "PrimitiveType", name: t.value as PrimitiveKind, span: spanOf(t) };
    }

    // Type identifier / alias
    if (t.type === "SYMBOL") {
      next();
      return { kind: "TypeRef", name: t.value, span: spanOf(t) };
    }

    // Fallback
    next();
    return { kind: "PrimitiveType", name: "!unknown" };
  }

  // Helper: Parse Layout Nodes
  function parseLayoutNode(): SparLayoutNode {
    const t = peek();

    // Element node (< tag (. attr val .) children... >)
    if (t.type === "LANGLE") {
      next(); // <
      const tagTok = expect("SYMBOL");
      const attrs: Record<string, SparExpr> = {};

      if (peek().type === "ATTR_BEG") {
        next(); // (.
        while (peek().type !== "ATTR_END" && peek().type !== "EOF") {
          const attrNameTok = expect("SYMBOL");
          const attrVal = parseExpr();
          attrs[attrNameTok.value] = attrVal;
        }
        expect("ATTR_END");
      }

      const children: SparLayoutNode[] = [];
      while (peek().type !== "RANGLE" && peek().type !== "EOF") {
        children.push(parseLayoutNode());
      }
      expect("RANGLE");

      return {
        kind: "ElementNode",
        tag: tagTok.value,
        attributes: attrs,
        children,
        span: spanOf(tagTok)
      };
    }

    // Conditional Layout Node (? cond then else?)
    if (t.type === "COND_DECL") {
      next(); // (?
      const condExpr = parseExpr();
      const thenNode = parseLayoutNode();
      let elseNode: SparLayoutNode | undefined;
      if (peek().type !== "RPAREN") {
        elseNode = parseLayoutNode();
      }
      expect("RPAREN");
      return {
        kind: "ConditionalLayoutNode",
        condition: condExpr,
        thenBranch: thenNode,
        elseBranch: elseNode,
        span: spanOf(t)
      };
    }

    // Loop Layout Node (* list item template)
    if (t.type === "MANIFEST_BEG") {
      next(); // (*
      const listExpr = parseExpr();
      const itemSym = expect("SYMBOL").value;
      const tpl = parseLayoutNode();
      expect("RPAREN");
      return {
        kind: "LoopLayoutNode",
        listExpr,
        itemSymbol: itemSym,
        template: tpl,
        span: spanOf(t)
      };
    }

    // Text Literal !str "..."
    if (t.type === "STR_TAG") {
      next(); // !str
      const strTok = expect("STRING");
      return { kind: "TextLiteralNode", content: strTok.value, span: spanOf(strTok) };
    }

    // Text Dynamic (!val expr)
    if (t.type === "VAL_OP") {
      next(); // (!val
      const inner = parseExpr();
      expect("RPAREN");
      return { kind: "TextDynamicNode", expr: inner, span: spanOf(t) };
    }

    // Literal string directly in layout
    if (t.type === "STRING") {
      const s = next();
      return { kind: "TextLiteralNode", content: s.value, span: spanOf(s) };
    }

    // Dynamic value fallback
    const fallbackExpr = parseExpr();
    return { kind: "TextDynamicNode", expr: fallbackExpr };
  }

  // Helper: Parse Expressions
  function parseExpr(): SparExpr {
    const t = peek();

    // Literal Expressions
    if (t.type === "STRING") {
      next();
      return { kind: "LiteralExpr", raw: t.value, litType: "!s", span: spanOf(t) };
    }
    if (t.type === "NUMBER") {
      next();
      const num = Number(t.value);
      return { kind: "LiteralExpr", raw: num, litType: t.value.includes(".") ? "!f" : "!i", span: spanOf(t) };
    }
    if (t.type === "BOOLEAN") {
      next();
      return { kind: "LiteralExpr", raw: t.value === "true", litType: "!b", span: spanOf(t) };
    }

    // Variable assignment (:= name expr)
    if (t.type === "ASSIGN_OP") {
      next(); // (:=
      const varTok = next();
      const val = parseExpr();
      if (t.value === "(:=") {
        expect("RPAREN");
      }
      return { kind: "AssignExpr", variable: varTok.value, value: val, span: spanOf(varTok) };
    }

    // Match expression (== target (case pat res)+)
    if (t.type === "MATCH_OP") {
      next(); // (==
      const target = parseExpr();
      const cases: Array<{ pattern: SparExpr; result: SparExpr }> = [];
      while (peek().type !== "RPAREN" && peek().type !== "EOF") {
        if (peek().type === "LPAREN" && tokens[idx + 1]?.value === "case") {
          next(); // (
          next(); // case
          const pat = parseExpr();
          const res = parseExpr();
          expect("RPAREN");
          cases.push({ pattern: pat, result: res });
        } else {
          next();
        }
      }
      expect("RPAREN");
      return { kind: "MatchExpr", target, cases, span: spanOf(t) };
    }

    // S-Expression: (op arg1 arg2 ...) or (do expr1 expr2 ...)
    if (t.type === "LPAREN") {
      next(); // (
      const opTok = peek();

      // Block expression (do expr1 expr2 ...)
      if (opTok.value === "do") {
        next(); // do
        const expressions: SparExpr[] = [];
        while (peek().type !== "RPAREN" && peek().type !== "EOF") {
          expressions.push(parseExpr());
        }
        expect("RPAREN");
        return { kind: "BlockExpr", expressions, span: spanOf(opTok) };
      }

      // Lambda (-> (params) body)
      if (opTok.type === "ARROW") {
        next(); // ->
        const params: SparParam[] = [];
        if (peek().type === "LPAREN") {
          next();
          while (peek().type !== "RPAREN" && peek().type !== "EOF") {
            const pName = next().value;
            let pType: SparTypeExpr = { kind: "PrimitiveType", name: "!unknown" };
            if (peek().type === "SYMBOL" && (peek().value.startsWith("!") || peek().value.startsWith("%"))) {
              pType = parseTypeExpr();
            }
            params.push({ name: pName, type: pType });
          }
          expect("RPAREN");
        }
        let retType: SparTypeExpr | undefined;
        if (peek().type === "SYMBOL" && peek().value.startsWith("!")) {
          retType = parseTypeExpr();
        }
        const body = parseExpr();
        expect("RPAREN");
        return { kind: "LambdaExpr", params, returnType: retType, body, span: spanOf(opTok) };
      }

      // Reactive Hooks: (!state init), (!signal init), (!computed expr), (!inject type)
      if (opTok.value === "!state" || opTok.value === "!signal" || opTok.value === "!computed" || opTok.value === "!inject") {
        const hookName = next().value.slice(1) as "state" | "signal" | "computed" | "inject";
        const inner = parseExpr();
        expect("RPAREN");
        return { kind: "HookExpr", hookType: hookName, initOrDep: inner, span: spanOf(opTok) };
      }

      // Linear GPU Allocation: (!linearAlloc expr)
      if (opTok.value === "!linearAlloc") {
        next();
        const inner = parseExpr();
        expect("RPAREN");
        return { kind: "LinearAllocExpr", target: inner, stateName: "Allocated", span: spanOf(opTok) };
      }

      // Linear Disposal / Transition: (!dispose res) or (!transition res State)
      if (opTok.value === "!dispose") {
        next();
        const resTok = expect("SYMBOL");
        expect("RPAREN");
        return { kind: "LinearTransitionExpr", resource: resTok.value, toState: "Disposed", span: spanOf(opTok) };
      }

      // Native Device Call: (!nativeCall api arg1 arg2)
      if (opTok.value === "!nativeCall") {
        next();
        const apiTok = expect("SYMBOL");
        const args: SparExpr[] = [];
        while (peek().type !== "RPAREN" && peek().type !== "EOF") {
          args.push(parseExpr());
        }
        expect("RPAREN");
        return { kind: "NativeCallExpr", api: apiTok.value, args, span: spanOf(opTok) };
      }

      // General Application: (op arg1 arg2 ...)
      const op = next().value;
      const args: SparExpr[] = [];
      while (peek().type !== "RPAREN" && peek().type !== "EOF") {
        args.push(parseExpr());
      }
      expect("RPAREN");

      let exprNode: SparExpr = { kind: "ApplyExpr", operator: op, args, span: spanOf(opTok) };

      // Check for postfix try unwrap: (expr)?
      if (peek().type === "TRY_OP") {
        next();
        exprNode = { kind: "TryPropagateExpr", inner: exprNode, span: spanOf(opTok) };
      }

      return exprNode;
    }

    // Identifier or Postfix unwrap
    if (t.type === "SYMBOL") {
      const sym = next();
      let exprNode: SparExpr = { kind: "IdentifierExpr", name: sym.value, span: spanOf(sym) };
      if (peek().type === "TRY_OP") {
        next();
        exprNode = { kind: "TryPropagateExpr", inner: exprNode, span: spanOf(sym) };
      }
      return exprNode;
    }

    // Fallback
    const stray = next();
    return { kind: "IdentifierExpr", name: stray.value, span: spanOf(stray) };
  }
}
