/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SPAR & TokTS Production Preset Catalog
 * Grounded in the 5 canonical stack archetypes and theoretical blueprints
 */

import { TargetLanguage } from "./types.ts";

export interface PresetItem {
  id: string;
  title: string;
  category: string;
  target: TargetLanguage;
  description: string;
  sparCode: string;
}

export const PRESETS: PresetItem[] = [
  {
    id: "workspace-polyglot-web",
    title: "Multi-Language Web Workspace (*.XX.spar)",
    category: "Multi-File Full-Stack Project",
    target: "vue",
    description: "Complete full-stack web project combining Vue SFC, Svelte, SCSS, Python FastAPI, Go, and GraphQL in a unified SPAR workspace.",
    sparCode: `(@workspace "polyglot-web-hub"
  (* convention "*.XX.spar" bundler "vite" version "2.0" *)

  (@file "src/components/Counter.vue.spar"
    (@module ui/counter
      (* framework "vue-3" sfc true *)
      (: Props (% label !s initial !i))

      (# Counter (% props Props)
        (do
          (:= [count setCount] (!state 0))
          (:= increment (-> () !void) (setCount (+ count 1)))

          (< div (. class "p-4 bg-slate-900 rounded-xl border border-slate-800 text-white" .)
            (< h3 (. class "text-sm font-bold text-emerald-400" .) (!val props.label) >)
            (< button (. class "mt-2 px-3 py-1 bg-emerald-600 text-white rounded font-medium" on:click increment .)
              (!str "Vue Count: ") (!val count)
            >)
          >)
        )
      )
    )
  )

  (@file "src/components/UserCard.svelte.spar"
    (@module ui/user-card
      (* framework "svelte-5" runes true *)
      (: UserProfile (% name !s role !s active !b))

      (# UserCard (% props UserProfile)
        (do
          (< div (. class "p-4 bg-slate-900 rounded-xl border border-orange-800/80 text-white" .)
            (< h4 (. class "text-sm font-bold text-orange-400" .) (!val props.name) >)
            (< span (. class "text-xs px-2 py-0.5 rounded bg-orange-950 text-orange-300 font-mono" .) (!val props.role) >)
          >)
        )
      )
    )
  )

  (@file "src/styles/theme.scss.spar"
    (@module styles/theme
      (* format "scss" *)
      (& brand-header (+
        color "#06b6d4"
        font-weight "bold"
        letter-spacing "0.05em"
      +))
      (& glass-card (+
        background "rgba(15, 23, 42, 0.8)"
        border "1px solid rgba(51, 65, 85, 0.5)"
        backdrop-filter "blur(12px)"
        border-radius "0.75rem"
      +))
    )
  )

  (@file "server/api.py.spar"
    (@module server/api
      (* runtime "python-fastapi" *)
      (: Account (% id !s balance !i verified !b))
      (: Transaction (% from !s to !s amount !i))

      (! transferFunds (-> (% tx Transaction) Result[Account, !s])
        (do
          (console.log "Executing FastAPI transfer")
          (ok (% id "acc-101" balance 450 verified true))
        )
      )
    )
  )

  (@file "server/main.go.spar"
    (@module server/main
      (* runtime "golang" package "main" *)
      (: HealthResponse (% status !s uptime !i))

      (! HealthCheck (-> () HealthResponse)
        (do
          (% status "healthy" uptime 12480)
        )
      )
    )
  )

  (@file "schema/api.graphql.spar"
    (@module schema/api
      (* format "graphql" *)
      (: Product (% id !s title !s price !i inStock !b))
      (: Customer (% id !s email !s name !s))
    )
  )
)`
  },
  {
    id: "vue-sfc-counter",
    title: "Vue 3 SFC: Counter.vue.spar",
    category: "Single-File Components & Templates",
    target: "vue",
    description: "Compiles Counter.vue.spar to Vue 3 Single-File Component (<template>, <script setup>, <style scoped>).",
    sparCode: `(@module ui/vue-counter
  (* framework "vue-3" sfc true *)
  (: CounterProps (% title !s initial !i))

  (# Counter (% props CounterProps)
    (do
      (:= [count setCount] (!state 0))
      (:= increment (-> () !void) (setCount (+ count 1)))

      (< div (. class "p-5 bg-slate-900 border border-slate-800 rounded-xl text-white" .)
        (< h2 (. class "text-sm font-bold text-emerald-400 uppercase" .) (!val props.title) >)
        (< p (. class "text-xs text-slate-400 mt-1" .) (!str "Vue 3 Composition API with TypeScript") >)
        (< button (. class "mt-3 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 font-semibold text-xs rounded-lg transition"
                    on:click increment .)
          (!str "Count: ") (!val count)
        >)
      >)
    )
  )
)`
  },
  {
    id: "svelte-runes-card",
    title: "Svelte 5: Card.svelte.spar",
    category: "Single-File Components & Templates",
    target: "svelte",
    description: "Compiles Card.svelte.spar to Svelte 5 runes component ($state, reactive events).",
    sparCode: `(@module ui/svelte-card
  (* framework "svelte-5" runes true *)
  (: Profile (% username !s rating !f))

  (# UserBadge (% props Profile)
    (do
      (:= active (!state true))

      (< div (. class "p-5 bg-slate-900 border border-orange-900/60 rounded-xl text-white" .)
        (< h3 (. class "text-base font-bold text-orange-400" .) (!val props.username) >)
        (< span (. class "inline-block mt-2 text-xs font-mono px-2 py-0.5 rounded bg-slate-800" .)
          (!str "Rating: ") (!val props.rating)
        >)
      >)
    )
  )
)`
  },
  {
    id: "python-fastapi-service",
    title: "Python FastAPI: server.py.spar",
    category: "Backend & Server-Side Web Languages",
    target: "py",
    description: "Compiles server.py.spar to Python FastAPI endpoints with typed Pydantic models.",
    sparCode: `(@module server/fastapi
  (* runtime "python-fastapi" *)
  (: UserDto (% id !s email !s isSuperuser !b))
  (: OrderDto (% orderId !s total !i status !s))

  (! fetchOrders (-> (% userId !s) Result[[OrderDto], !s])
    (do
      (ok [(% orderId "ord-1" total 150 status "PAID")])
    )
  )
)`
  },
  {
    id: "golang-microservice",
    title: "Go (Golang): handler.go.spar",
    category: "Backend & Server-Side Web Languages",
    target: "go",
    description: "Compiles handler.go.spar to Go Net/HTTP microservice with typed structs and JSON tags.",
    sparCode: `(@module server/handler
  (* runtime "golang" package "main" *)
  (: SessionPayload (% token !s userId !s expiresAt !i))

  (! HandleAuth (-> (% token !s) !b)
    (do
      (> token.length 0)
    )
  )
)`
  },
  {
    id: "rust-axum-service",
    title: "Rust: service.rs.spar",
    category: "Backend & Server-Side Web Languages",
    target: "rs",
    description: "Compiles service.rs.spar to Rust Axum async web routes with Serde structs.",
    sparCode: `(@module server/axum
  (* runtime "rust-axum" *)
  (: MetricRecord (% cpuUsage !f memoryMb !i host !s))

  (! RecordMetrics (-> (% m MetricRecord) !void)
    (do
      (console.log m.host)
    )
  )
)`
  },
  {
    id: "graphql-schema-def",
    title: "GraphQL: schema.graphql.spar",
    category: "Web Data, Config & APIs",
    target: "graphql",
    description: "Compiles schema.graphql.spar to clean GraphQL Schema Definition (SDL).",
    sparCode: `(@module api/schema
  (* format "graphql" *)
  (: Query (% me Customer product Product))
  (: Customer (% id !s name !s email !s))
  (: Product (% id !s title !s price !i inStock !b))
)`
  },
  {
    id: "scss-theme-styles",
    title: "SCSS Stylesheet: theme.scss.spar",
    category: "Styles & CSS Preprocessors",
    target: "scss",
    description: "Compiles theme.scss.spar to SCSS stylesheet with scoped nesting and custom properties.",
    sparCode: `(@module styles/theme
  (* format "scss" *)
  (& primary-btn (+
    background "#06b6d4"
    color "#ffffff"
    padding "0.5rem 1rem"
    border-radius "0.5rem"
    font-weight "600"
  +))
  (& alert-box (+
    background "#450a0a"
    border "1px solid #991b1b"
    color "#fca5a5"
    padding "1rem"
    border-radius "0.75rem"
  +))
)`
  },
  {
    id: "workspace-fullstack-store",
    title: "Multi-File Project: Full-Stack Workspace (@workspace)",
    category: "Multi-File Full-Stack Project",
    target: "react-tailwind",
    description: "Multi-file repository containing models, UI components, and domain services encapsulated in an (@workspace) container.",
    sparCode: `(@workspace "hyper-store"
  (* target "react-tailwind" bundler "vite" version "1.0" *)

  (@file "src/types/store.ts"
    (@module types/store
      (: Product (% id !s title !s price !i inStock !b))
      (: CartItem (% product Product quantity !i))
      (: CartState (% items [CartItem] total !i))
    )
  )

  (@file "src/components/ProductCard.tsx"
    (@module ui/product-card
      (* framework "react-19" styling "tailwind-v4" *)
      (deps (("../types/store" Product)))

      (# ProductCard (% props (% item Product onAddToCart !unknown))
        (do
          (:= handleBuy (-> () !void) (props.onAddToCart props.item))

          (< div (. class "p-4 bg-slate-900 border border-slate-800 rounded-xl flex flex-col gap-3 shadow-lg" .)
            (< div (. class "flex justify-between items-start" .)
              (< h3 (. class "text-sm font-bold text-white" .) (!val props.item.title) >)
              (< span (. class "text-xs font-semibold px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800" .)
                (!str "$") (!val props.item.price)
              >)
            >)
            (< button (. class "w-full py-2 px-3 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg transition"
                        on:click handleBuy .)
              (!str "Add to Cart")
            >)
          >)
        )
      )
    )
  )

  (@file "src/services/pricing.ts"
    (@module services/pricing
      (* runtime "node-native" *)
      (: DiscountCode (?: d !s (and (>= d.length 3) (<= d.length 12))))

      (! calculateTotal (-> (subtotal !i discountPct !i) !i)
        (do
          (:= savings (/ (* subtotal discountPct) 100))
          (- subtotal savings)
        )
      )
    )
  )
)`
  },
  {
    id: "react-tailwind-counter",
    title: "React 19 + Tailwind v4 Reactive Counter",
    category: "Web UI & Components",
    target: "react-tailwind",
    description: "Component declaration with algebraic effects, typed props contract, and zero-redundancy JSX layout.",
    sparCode: `(@module ui/counter
  (* framework "react-19" styling "tailwind-v4" *)
  (: CounterProps (% label !s initial !i))

  (# Counter (% props CounterProps)
    (do
      (:= [count setCount] (!state props.initial))
      (:= increment (-> () !void) (setCount (+ count 1)))
      (:= reset (-> () !void) (setCount 0))

      (< div (. class "flex flex-col gap-3 p-5 bg-slate-900 border border-slate-800 rounded-xl shadow-lg" .)
        (< div (. class "flex items-center justify-between" .)
          (< span (. class "text-xs font-semibold uppercase tracking-wider text-cyan-400" .)
            (!val props.label)
          >)
          (<span (. class "text-2xl font-bold text-white tabular-nums" .)
            (!val count)
          >)
        >)
        (< div (. class "flex gap-2 pt-2" .)
          (< button (. class "flex-1 py-2 px-4 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-sm rounded-lg transition"
                      on:click increment .)
            (!str "Increment (+1)")
          >)
          (< button (. class "py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-sm rounded-lg transition"
                      on:click reset .)
            (!str "Reset")
          >)
        >)
      >)
    )
  )
)`
  },
  {
    id: "angular-signals-card",
    title: "Angular 19 Reactive Signals Card",
    category: "Full-Stack Web",
    target: "angular-signals",
    description: "Standalone Angular 19 component mapped to signals, computed expressions, and inject() API.",
    sparCode: `(@module core/user-card
  (* framework "angular" version "19" *)
  (deps (
    ("@angular/core" Component signal computed inject)
    ("services/auth" AuthService)
  ))

  (: UserProfile (% id !s name !s email !s role !s))

  (# UserCard (% inputs (% userId !s))
    (do
      (:= authService (!inject AuthService))
      (:= userData (!signal (% id "u-101" name "Alex Chen" email "alex@sys.io" role "Lead Architect")))
      (:= isAuthenticated (!computed (-> () !b) (!ne (!val authService.currentUser) null)))

      (< div (. class "p-5 bg-slate-900 border border-slate-800 rounded-xl text-white" .)
        (? isAuthenticated
          (< div (. class "space-y-2" .)
            (< h2 (. class "text-lg font-semibold text-emerald-400" .) (!val userData.name) >)
            (< p (. class "text-sm text-slate-400" .) (!val userData.email) >)
            (< span (. class "inline-block px-2 py-0.5 text-xs bg-slate-800 rounded text-slate-300" .) (!val userData.role) >)
          >)
          (< p (. class "text-sm text-slate-500" .) (!str "User session unauthenticated.") >)
        )
      >)
    )
  )
)`
  },
  {
    id: "threejs-linear-gpu",
    title: "Three.js 3D WebGL with Linear GPU Typestates",
    category: "Graphics & 3D WebGL",
    target: "threejs-webgl",
    description: "Enforces strict linear resource allocations for WebGL buffers to prevent memory leaks with typestate checking.",
    sparCode: `(@module graphics/scene-director
  (* engine "threejs" pipeline "webgl" *)
  (deps (
    ("three" Scene PerspectiveCamera WebGLRenderer BoxGeometry MeshBasicMaterial Mesh)
  ))

  (: GeomState (~ Allocated -> Disposed))

  (! initScene (-> (% canvas !unknown) (!^ !void [GPU IO]))
    (do
      (:= scene (!new Scene))
      (:= camera (!new PerspectiveCamera 75 (/ 16 9) 0.1 1000))
      (:= renderer (!new WebGLRenderer (% canvas canvas antialias true)))

      (:= geom (!linearAlloc (!new BoxGeometry 1.5 1.5 1.5)))
      (:= mat (!linearAlloc (!new MeshBasicMaterial (% color 0x00f0ff))))
      (:= cube (!new Mesh geom mat))

      (scene.add cube)
      (camera.position.set 0 0 5)

      (!renderLoop (-> (delta !f)
        (do
          (:= cube.rotation.x (+ cube.rotation.x (* 1.0 delta)))
          (:= cube.rotation.y (+ cube.rotation.y (* 1.2 delta)))
          (renderer.render scene camera)
        )
      ))
    )
  )
)`
  },
  {
    id: "phaser-space-arcade",
    title: "Phaser 2D Arcade Game Pipeline",
    category: "Game Engineering",
    target: "phaser-2d",
    description: "2D Arcade physics game scene with sprite damping, collision boundaries, and cursor control loop.",
    sparCode: `(@module games/space-pilot
  (* engine "phaser" physics "arcade" version "3.80" *)
  (deps (("phaser" Scene Game AUTO)))

  (: GameState (% score !i active !b level !i))

  (! initGame (-> (% containerId !s) (!^ !void [DOM GPU State]))
    (do
      (:= gameConfig (%
        type AUTO
        width 800
        height 600
        parent containerId
        physics (% default "arcade")
      ))
      (!new Game gameConfig)
    )
  )
)`
  },
  {
    id: "node-result-algebra",
    title: "Node 22 Native + TokTS Result[T, E] & Refinement",
    category: "Backend & Systems",
    target: "node-native",
    description: "Algebraic Result[T, E] error handling with '?' postfix unwrapping, refinement type predicates, and zero-dep tests.",
    sparCode: `(@module core/account-service
  (* runtime "node-native" strip-types true zero-dep true *)
  (deps (
    ("node:test" test describe it)
    ("node:assert/strict" assert)
  ))

  ;; Refinement Type with linear Presburger bounds: 1 <= Port <= 65535
  (: Port (?: p !i (and (>= p 1) (<= p 65535))))

  ;; TokTS algebraic Result sum type
  (: Account (% id !s balance !i))
  (: DomainError (% code !s message !s))

  (! parseAccount (-> (rawJson !s) Result[Account, DomainError])
    (do
      (:= parsed (JSON.parse rawJson)?)
      (? (< parsed.balance 0)
        (err (% code "NEGATIVE_BALANCE" message "Balance cannot be negative"))
        (ok (% id parsed.id balance parsed.balance))
      )
    )
  )

  (!test "validates account parsing" (-> () !void)
    (do
      (:= res (parseAccount "{\\"id\\":\\"acc-1\\",\\"balance\\":500}"))
      (assert.equal res.ok true)
    )
  )
)`
  },
  {
    id: "capacitor-mobile-bridge",
    title: "Capacitor 8 Mobile Native Hardware Bridge",
    category: "Mobile & Hybrid",
    target: "capacitor-mobile",
    description: "Mobile bridge with platform detection, Haptics, and StatusBar state automaton.",
    sparCode: `(@module mobile/device-bridge
  (* target "capacitor" platform "hybrid" *)
  (deps (
    ("@capacitor/core" Capacitor)
    ("@capacitor/haptics" Haptics ImpactStyle)
    ("@capacitor/status-bar" StatusBar Style)
  ))

  (: BridgeState (~ Uninitialized -> Active))

  (! setupDevice (-> () (!^ !void [Native Async]))
    (do
      (:= isNative (Capacitor.isNativePlatform))
      (? isNative
        (do
          (StatusBar.setStyle (% style Style.Dark))
          (Haptics.impact (% style ImpactStyle.Light))
        )
        (console.log "Running in Web Browser Sandbox")
      )
    )
  )
)`
  },
  {
    id: "typestate-violation-diagnostic",
    title: "Autonomous AI Diagnostics: Typestate Violation (E3002)",
    category: "AI Autonomous Diagnostics",
    target: "threejs-webgl",
    description: "Demonstrates how SPAR compiler catches premature disposal and emits deterministic JSON telemetry for AI self-repair.",
    sparCode: `(@module test/typestate-error
  (* engine "threejs" test "error-recovery" *)

  (! renderFaultyScene (-> (% canvas !unknown) (!^ !void [GPU]))
    (do
      (:= geom (!linearAlloc (!new BoxGeometry 1 1 1)))
      (:= renderer (!new WebGLRenderer (% canvas canvas)))

      ;; Premature disposal before rendering call!
      (!dispose geom)

      ;; Static error: Resource 'geom' utilized in typestate 'Disposed'. Required: 'Allocated'.
      (renderer.render geom camera)
    )
  )
)`
  }
];
