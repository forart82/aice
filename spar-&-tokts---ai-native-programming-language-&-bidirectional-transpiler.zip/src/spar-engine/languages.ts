/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Web Languages & Frameworks Registry for SPAR
 * Defines all 32+ web formats across 5 categories with *.XX.spar conventions.
 */

export type WebLanguageCategory =
  | "Frontend Core & Scripts"
  | "Styles & CSS Preprocessors"
  | "Single-File Components & Templates"
  | "Backend & Server-Side Web Languages"
  | "Web Data, Config & APIs";

export interface WebLanguageDef {
  id: string;              // e.g. "vue", "svelte", "tsx", "py", "go", "rs", "html", "scss"
  extension: string;       // e.g. "vue", "svelte", "tsx", "py", "go", "rs", "html", "scss"
  sparExtension: string;   // e.g. ".vue.spar", ".tsx.spar", ".py.spar"
  name: string;            // e.g. "Vue.js Single-File Component"
  category: WebLanguageCategory;
  description: string;
  defaultFilename: string; // e.g. "Counter.vue.spar"
  mimeType?: string;
  isComponent?: boolean;
  isBackend?: boolean;
  isStyle?: boolean;
  isData?: boolean;
}

export const WEB_LANGUAGES: WebLanguageDef[] = [
  // 1. Frontend Core & Scripts
  {
    id: "html",
    extension: "html",
    sparExtension: ".html.spar",
    name: "HTML5 Document",
    category: "Frontend Core & Scripts",
    description: "HyperText Markup Language core document structure",
    defaultFilename: "index.html.spar"
  },
  {
    id: "js",
    extension: "js",
    sparExtension: ".js.spar",
    name: "JavaScript (ES/Node)",
    category: "Frontend Core & Scripts",
    description: "Standard client-side and Node.js scripting",
    defaultFilename: "app.js.spar"
  },
  {
    id: "mjs",
    extension: "mjs",
    sparExtension: ".mjs.spar",
    name: "JavaScript ESM Module",
    category: "Frontend Core & Scripts",
    description: "ECMAScript Module (import / export syntax)",
    defaultFilename: "module.mjs.spar"
  },
  {
    id: "cjs",
    extension: "cjs",
    sparExtension: ".cjs.spar",
    name: "CommonJS Module",
    category: "Frontend Core & Scripts",
    description: "CommonJS module (require / module.exports syntax)",
    defaultFilename: "bundle.cjs.spar"
  },
  {
    id: "ts",
    extension: "ts",
    sparExtension: ".ts.spar",
    name: "TypeScript",
    category: "Frontend Core & Scripts",
    description: "Statically typed superset of JavaScript",
    defaultFilename: "service.ts.spar"
  },
  {
    id: "jsx",
    extension: "jsx",
    sparExtension: ".jsx.spar",
    name: "JavaScript with JSX",
    category: "Frontend Core & Scripts",
    description: "React component syntax with JSX extensions",
    defaultFilename: "Button.jsx.spar",
    isComponent: true
  },
  {
    id: "tsx",
    extension: "tsx",
    sparExtension: ".tsx.spar",
    name: "TypeScript with JSX",
    category: "Frontend Core & Scripts",
    description: "Statically typed React component with JSX",
    defaultFilename: "App.tsx.spar",
    isComponent: true
  },
  {
    id: "wasm",
    extension: "wat",
    sparExtension: ".wasm.spar",
    name: "WebAssembly (WAT Text)",
    category: "Frontend Core & Scripts",
    description: "WebAssembly binary & text execution format",
    defaultFilename: "math.wasm.spar"
  },

  // 2. Styles & CSS Preprocessors
  {
    id: "css",
    extension: "css",
    sparExtension: ".css.spar",
    name: "Cascading Style Sheets (CSS)",
    category: "Styles & CSS Preprocessors",
    description: "Native modern browser styling rules",
    defaultFilename: "styles.css.spar",
    isStyle: true
  },
  {
    id: "scss",
    extension: "scss",
    sparExtension: ".scss.spar",
    name: "Sassy CSS (SCSS)",
    category: "Styles & CSS Preprocessors",
    description: "SCSS syntax with variables, nesting, and mixins",
    defaultFilename: "theme.scss.spar",
    isStyle: true
  },
  {
    id: "sass",
    extension: "sass",
    sparExtension: ".sass.spar",
    name: "SASS (Indented)",
    category: "Styles & CSS Preprocessors",
    description: "Syntactically Awesome Style Sheets (indentation-based)",
    defaultFilename: "main.sass.spar",
    isStyle: true
  },
  {
    id: "less",
    extension: "less",
    sparExtension: ".less.spar",
    name: "LESS Stylesheet",
    category: "Styles & CSS Preprocessors",
    description: "Leaner Style Sheets preprocessor",
    defaultFilename: "mixins.less.spar",
    isStyle: true
  },
  {
    id: "styl",
    extension: "styl",
    sparExtension: ".styl.spar",
    name: "Stylus Stylesheet",
    category: "Styles & CSS Preprocessors",
    description: "Stylus expressive stylesheet preprocessor",
    defaultFilename: "app.styl.spar",
    isStyle: true
  },
  {
    id: "pcss",
    extension: "pcss",
    sparExtension: ".pcss.spar",
    name: "PostCSS Source",
    category: "Styles & CSS Preprocessors",
    description: "PostCSS source with plugins and custom properties",
    defaultFilename: "global.pcss.spar",
    isStyle: true
  },

  // 3. Single-File Components & Templates
  {
    id: "vue",
    extension: "vue",
    sparExtension: ".vue.spar",
    name: "Vue.js Single-File Component",
    category: "Single-File Components & Templates",
    description: "Vue 3 SFC (<template>, <script setup>, <style scoped>)",
    defaultFilename: "Counter.vue.spar",
    isComponent: true
  },
  {
    id: "svelte",
    extension: "svelte",
    sparExtension: ".svelte.spar",
    name: "Svelte 5 Component",
    category: "Single-File Components & Templates",
    description: "Svelte reactive runes component",
    defaultFilename: "UserCard.svelte.spar",
    isComponent: true
  },
  {
    id: "astro",
    extension: "astro",
    sparExtension: ".astro.spar",
    name: "Astro Component",
    category: "Single-File Components & Templates",
    description: "Astro island component with zero-JS by default",
    defaultFilename: "Layout.astro.spar",
    isComponent: true
  },
  {
    id: "ejs",
    extension: "ejs",
    sparExtension: ".ejs.spar",
    name: "EJS Template",
    category: "Single-File Components & Templates",
    description: "Embedded JavaScript templating engine",
    defaultFilename: "header.ejs.spar"
  },
  {
    id: "hbs",
    extension: "hbs",
    sparExtension: ".hbs.spar",
    name: "Handlebars Template",
    category: "Single-File Components & Templates",
    description: "Mustache / Handlebars semantic templating",
    defaultFilename: "profile.hbs.spar"
  },
  {
    id: "pug",
    extension: "pug",
    sparExtension: ".pug.spar",
    name: "Pug (Jade) Template",
    category: "Single-File Components & Templates",
    description: "Indentation-based HTML template engine",
    defaultFilename: "index.pug.spar"
  },
  {
    id: "twig",
    extension: "twig",
    sparExtension: ".twig.spar",
    name: "Twig Template",
    category: "Single-File Components & Templates",
    description: "Flexible, secure PHP / Symfony template engine",
    defaultFilename: "page.twig.spar"
  },
  {
    id: "blade",
    extension: "blade.php",
    sparExtension: ".blade.php.spar",
    name: "Laravel Blade Template",
    category: "Single-File Components & Templates",
    description: "Laravel Blade templating syntax (@if, @foreach)",
    defaultFilename: "card.blade.php.spar"
  },

  // 4. Backend & Server-Side Web Languages
  {
    id: "php",
    extension: "php",
    sparExtension: ".php.spar",
    name: "PHP 8.x Web Service",
    category: "Backend & Server-Side Web Languages",
    description: "Modern PHP REST controller and typed domain classes",
    defaultFilename: "api.php.spar",
    isBackend: true
  },
  {
    id: "py",
    extension: "py",
    sparExtension: ".py.spar",
    name: "Python (FastAPI / Flask)",
    category: "Backend & Server-Side Web Languages",
    description: "Python async web endpoints with Pydantic typing",
    defaultFilename: "server.py.spar",
    isBackend: true
  },
  {
    id: "rb",
    extension: "rb",
    sparExtension: ".rb.spar",
    name: "Ruby (Sinatra / Rails)",
    category: "Backend & Server-Side Web Languages",
    description: "Ruby web routes and domain services",
    defaultFilename: "router.rb.spar",
    isBackend: true
  },
  {
    id: "go",
    extension: "go",
    sparExtension: ".go.spar",
    name: "Go (Golang Net/HTTP / Gin)",
    category: "Backend & Server-Side Web Languages",
    description: "High-concurrency compiled web server in Go",
    defaultFilename: "handler.go.spar",
    isBackend: true
  },
  {
    id: "cs",
    extension: "cs",
    sparExtension: ".cs.spar",
    name: "C# (ASP.NET Core Minimal API)",
    category: "Backend & Server-Side Web Languages",
    description: "ASP.NET Core typed endpoints and record DTOs",
    defaultFilename: "Program.cs.spar",
    isBackend: true
  },
  {
    id: "java",
    extension: "java",
    sparExtension: ".java.spar",
    name: "Java (Spring Boot Controller)",
    category: "Backend & Server-Side Web Languages",
    description: "Spring Boot REST controller with record payloads",
    defaultFilename: "ApiController.java.spar",
    isBackend: true
  },
  {
    id: "rs",
    extension: "rs",
    sparExtension: ".rs.spar",
    name: "Rust (Axum / Actix-web)",
    category: "Backend & Server-Side Web Languages",
    description: "Memory-safe high-throughput async web service in Rust",
    defaultFilename: "main.rs.spar",
    isBackend: true
  },

  // 5. Web Data, Config & APIs
  {
    id: "json",
    extension: "json",
    sparExtension: ".json.spar",
    name: "JSON Data",
    category: "Web Data, Config & APIs",
    description: "Standard REST API and data interchange",
    defaultFilename: "data.json.spar",
    isData: true
  },
  {
    id: "jsonld",
    extension: "jsonld",
    sparExtension: ".jsonld.spar",
    name: "JSON-LD (Structured SEO)",
    category: "Web Data, Config & APIs",
    description: "JSON for Linked Data and Schema.org rich snippets",
    defaultFilename: "schema.jsonld.spar",
    isData: true
  },
  {
    id: "graphql",
    extension: "graphql",
    sparExtension: ".graphql.spar",
    name: "GraphQL Schema & Queries",
    category: "Web Data, Config & APIs",
    description: "Type-safe API query definitions and schemas",
    defaultFilename: "schema.graphql.spar",
    isData: true
  },
  {
    id: "xml",
    extension: "xml",
    sparExtension: ".xml.spar",
    name: "XML / Sitemap / RSS",
    category: "Web Data, Config & APIs",
    description: "Extensible Markup Language document",
    defaultFilename: "sitemap.xml.spar",
    isData: true
  },
  {
    id: "yaml",
    extension: "yaml",
    sparExtension: ".yaml.spar",
    name: "YAML / OpenAPI Spec",
    category: "Web Data, Config & APIs",
    description: "Human-readable config and OpenAPI 3.0 API spec",
    defaultFilename: "openapi.yaml.spar",
    isData: true
  }
];

export function getLanguageById(id: string): WebLanguageDef | undefined {
  return WEB_LANGUAGES.find(l => l.id === id || l.extension === id);
}

export function detectLanguageFromFilename(filename: string): WebLanguageDef {
  const clean = filename.toLowerCase();
  for (const lang of WEB_LANGUAGES) {
    if (clean.endsWith(lang.sparExtension.toLowerCase())) {
      return lang;
    }
  }

  // Fallback to checking extension before .spar
  const match = clean.match(/\.([a-z0-9_\-\.]+)\.spar$/);
  if (match) {
    const ext = match[1];
    const found = WEB_LANGUAGES.find(l => l.extension === ext || l.id === ext);
    if (found) return found;
  }

  // Check direct extension
  for (const lang of WEB_LANGUAGES) {
    if (clean.endsWith(`.${lang.extension}`)) {
      return lang;
    }
  }

  return WEB_LANGUAGES.find(l => l.id === "tsx")!;
}
