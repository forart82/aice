/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Polyglot Web Decompilers for SPAR (*.XX -> *.XX.spar)
 * Ingests Vue, Svelte, Astro, HTML, CSS, Python, Go, Rust, GraphQL, YAML, etc. into SPAR.
 */

import { decompileTsToSpar } from "./ts-decompiler.ts";

export function decompileByLanguageId(source: string, langId: string, moduleId = "app"): string {
  switch (langId) {
    case "vue":
      return decompileVueToSpar(source, moduleId);
    case "svelte":
      return decompileSvelteToSpar(source, moduleId);
    case "astro":
      return decompileAstroToSpar(source, moduleId);
    case "html":
    case "htm":
      return decompileHtmlToSpar(source, moduleId);
    case "css":
    case "scss":
    case "sass":
    case "less":
    case "styl":
    case "pcss":
      return decompileCssToSpar(source, moduleId, langId);
    case "py":
      return decompilePythonToSpar(source, moduleId);
    case "go":
      return decompileGoToSpar(source, moduleId);
    case "rs":
      return decompileRustToSpar(source, moduleId);
    case "php":
      return decompilePhpToSpar(source, moduleId);
    case "graphql":
    case "gql":
      return decompileGraphQlToSpar(source, moduleId);
    case "json":
    case "jsonld":
      return decompileJsonToSpar(source, moduleId);
    case "yaml":
    case "yml":
      return decompileYamlToSpar(source, moduleId);
    default:
      // Default to TypeScript/JSX decompiler
      return decompileTsToSpar(source, moduleId).sparCode;
  }
}

function decompileVueToSpar(source: string, moduleId: string): string {
  const templateMatch = source.match(/<template>([\s\S]*?)<\/template>/i);
  const scriptMatch = source.match(/<script[^>]*>([\s\S]*?)<\/script>/i);

  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* framework "vue-3" sfc true *)`);

  if (scriptMatch) {
    // Extract TS types/vars
    const scriptCode = scriptMatch[1];
    const tsDecompiled = decompileTsToSpar(scriptCode, `${moduleId}/script`).sparCode;
    // Extract inner entities from script
    const innerEntities = tsDecompiled.replace(/\(@module[^\n]*\n/, "").replace(/\)$/, "").trim();
    if (innerEntities) {
      lines.push(`  ${innerEntities}`);
    }
  }

  // Component Layout
  lines.push(`\n  (# ${capitalize(moduleId)} (% props !unknown)`);
  lines.push(`    (do`);
  lines.push(`      (:= [count setCount] (!state 0))`);

  if (templateMatch) {
    const rawTpl = templateMatch[1].trim();
    lines.push(`      (< div (. class "vue-container" .)`);
    lines.push(`        (!str "${rawTpl.replace(/"/g, '\\"').replace(/\n/g, ' ')}")`);
    lines.push(`      >)`);
  } else {
    lines.push(`      (< div (. .) (!str "Vue Template") >)`);
  }

  lines.push(`    )`);
  lines.push(`  )`);
  lines.push(`)`);
  return lines.join("\n");
}

function decompileSvelteToSpar(source: string, moduleId: string): string {
  const scriptMatch = source.match(/<script[^>]*>([\s\S]*?)<\/script>/i);
  const templateContent = source.replace(/<script[^>]*>[\s\S]*?<\/script>/i, "").replace(/<style[^>]*>[\s\S]*?<\/style>/i, "").trim();

  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* framework "svelte-5" runes true *)`);

  if (scriptMatch) {
    lines.push(`  ;; Svelte Runes Logic`);
    lines.push(`  (:= count (!state 0))`);
  }

  lines.push(`\n  (# ${capitalize(moduleId)} (% props !unknown)`);
  lines.push(`    (do`);
  lines.push(`      (< div (. class "svelte-card" .)`);
  lines.push(`        (!str "${templateContent.replace(/"/g, '\\"').replace(/\n/g, ' ')}")`);
  lines.push(`      >)`);
  lines.push(`    )`);
  lines.push(`  )`);
  lines.push(`)`);
  return lines.join("\n");
}

function decompileAstroToSpar(source: string, moduleId: string): string {
  const frontmatterMatch = source.match(/^---\s*([\s\S]*?)\s*---/);
  const htmlContent = source.replace(/^---\s*[\s\S]*?\s*---/, "").trim();

  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* framework "astro" island true *)`);

  lines.push(`\n  (# ${capitalize(moduleId)} (% props (% title !s count !i))`);
  lines.push(`    (do`);
  lines.push(`      (< div (. class "astro-root" .)`);
  lines.push(`        (!str "${htmlContent.replace(/"/g, '\\"').replace(/\n/g, ' ')}")`);
  lines.push(`      >)`);
  lines.push(`    )`);
  lines.push(`  )`);
  lines.push(`)`);
  return lines.join("\n");
}

function decompileHtmlToSpar(source: string, moduleId: string): string {
  return `(@module ${moduleId}
  (* format "html5" *)

  (# Document (% props !unknown)
    (do
      (< div (. class "html-body" .)
        (!str "${source.replace(/"/g, '\\"').replace(/\n/g, ' ').slice(0, 150)}...")
      >)
    )
  )
)`;
}

function decompileCssToSpar(source: string, moduleId: string, format: string): string {
  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* format "${format}" *)`);

  // Extract CSS selectors
  const ruleRegex = /([\.#a-zA-Z0-9_\-]+)\s*\{([^}]+)\}/g;
  let match: RegExpExecArray | null;

  while ((match = ruleRegex.exec(source)) !== null) {
    const selector = match[1].replace(/^[\.#]/, "");
    const body = match[2];
    const props = body.split(";").map(s => s.trim()).filter(Boolean);

    lines.push(`\n  (& ${selector} (+`);
    for (const p of props) {
      const [k, v] = p.split(":").map(s => s.trim());
      if (k && v) {
        lines.push(`    ${k} "${v}"`);
      }
    }
    lines.push(`  +))`);
  }

  lines.push(`)`);
  return lines.join("\n");
}

function decompilePythonToSpar(source: string, moduleId: string): string {
  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* runtime "python-fastapi" *)`);

  // Extract Pydantic classes: class User(BaseModel):
  const classRegex = /class\s+([A-Za-z0-9_]+)\s*\((?:BaseModel)?\):([\s\S]*?)(?=\nclass|\ndef|$)/g;
  let classMatch: RegExpExecArray | null;

  while ((classMatch = classRegex.exec(source)) !== null) {
    const className = classMatch[1];
    const classBody = classMatch[2];
    const fieldLines = classBody.split("\n").map(l => l.trim()).filter(l => l.includes(":"));

    const fields: string[] = [];
    for (const fl of fieldLines) {
      const [name, type] = fl.split(":").map(s => s.trim());
      const sparType = type.startsWith("int") ? "!i" : type.startsWith("bool") ? "!b" : "!s";
      fields.push(`${name} ${sparType}`);
    }

    lines.push(`\n  (: ${className} (% ${fields.join(" ")}))`);
  }

  // Extract async def / def endpoints
  const fnRegex = /(?:@app\.[a-z]+\([^\)]*\)\s+)?async\s+def\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\):/g;
  let fnMatch: RegExpExecArray | null;
  while ((fnMatch = fnRegex.exec(source)) !== null) {
    const fnName = fnMatch[1];
    lines.push(`\n  (! ${fnName} (-> () !void) (console.log "FastAPI Endpoint"))`);
  }

  lines.push(`)`);
  return lines.join("\n");
}

function decompileGoToSpar(source: string, moduleId: string): string {
  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* runtime "golang" *)`);

  // Extract structs: type User struct { ... }
  const structRegex = /type\s+([A-Za-z0-9_]+)\s+struct\s*\{([\s\S]*?)\}/g;
  let match: RegExpExecArray | null;

  while ((match = structRegex.exec(source)) !== null) {
    const structName = match[1];
    const body = match[2];
    const fields: string[] = [];

    const fieldLines = body.split("\n").map(l => l.trim()).filter(Boolean);
    for (const fl of fieldLines) {
      const parts = fl.split(/\s+/);
      if (parts.length >= 2) {
        const name = parts[0].toLowerCase();
        const type = parts[1];
        const sparType = type === "int" ? "!i" : type === "bool" ? "!b" : "!s";
        fields.push(`${name} ${sparType}`);
      }
    }
    lines.push(`\n  (: ${structName} (% ${fields.join(" ")}))`);
  }

  lines.push(`)`);
  return lines.join("\n");
}

function decompileRustToSpar(source: string, moduleId: string): string {
  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* runtime "rust-axum" *)`);

  // Extract pub struct User { ... }
  const structRegex = /pub\s+struct\s+([A-Za-z0-9_]+)\s*\{([\s\S]*?)\}/g;
  let match: RegExpExecArray | null;

  while ((match = structRegex.exec(source)) !== null) {
    const structName = match[1];
    const body = match[2];
    const fields: string[] = [];

    const fieldLines = body.split("\n").map(l => l.trim()).filter(l => l.startsWith("pub "));
    for (const fl of fieldLines) {
      const clean = fl.replace(/^pub\s+/, "").replace(/,$/, "");
      const [name, type] = clean.split(":").map(s => s.trim());
      if (name && type) {
        const sparType = type.includes("i") || type.includes("u") ? "!i" : type === "bool" ? "!b" : "!s";
        fields.push(`${name} ${sparType}`);
      }
    }
    lines.push(`\n  (: ${structName} (% ${fields.join(" ")}))`);
  }

  lines.push(`)`);
  return lines.join("\n");
}

function decompilePhpToSpar(source: string, moduleId: string): string {
  return `(@module ${moduleId}
  (* runtime "php-8" *)
  (: Response (% status !s timestamp !i))
  (! handleRequest (-> () !void) (console.log "PHP Endpoint"))
)`;
}

function decompileGraphQlToSpar(source: string, moduleId: string): string {
  const lines: string[] = [];
  lines.push(`(@module ${moduleId}`);
  lines.push(`  (* format "graphql" *)`);

  const typeRegex = /type\s+([A-Za-z0-9_]+)\s*\{([\s\S]*?)\}/g;
  let match: RegExpExecArray | null;

  while ((match = typeRegex.exec(source)) !== null) {
    const typeName = match[1];
    if (typeName === "Query" || typeName === "Mutation") continue;
    const body = match[2];
    const fields: string[] = [];

    const fieldLines = body.split("\n").map(l => l.trim()).filter(l => l.includes(":"));
    for (const fl of fieldLines) {
      const [name, type] = fl.split(":").map(s => s.trim());
      const sparType = type.includes("Int") ? "!i" : type.includes("Boolean") ? "!b" : "!s";
      fields.push(`${name} ${sparType}`);
    }
    lines.push(`\n  (: ${typeName} (% ${fields.join(" ")}))`);
  }

  lines.push(`)`);
  return lines.join("\n");
}

function decompileJsonToSpar(source: string, moduleId: string): string {
  try {
    const parsed = JSON.parse(source);
    const keys = Object.keys(parsed);
    const fields = keys.map(k => {
      const val = parsed[k];
      const t = typeof val === "number" ? "!i" : typeof val === "boolean" ? "!b" : "!s";
      return `${k} ${t}`;
    });

    return `(@module ${moduleId}
  (* format "json" *)
  (: DataSchema (% ${fields.join(" ")}))
)`;
  } catch {
    return `(@module ${moduleId} (* format "json" *))`;
  }
}

function decompileYamlToSpar(source: string, moduleId: string): string {
  return `(@module ${moduleId}
  (* format "yaml" *)
  (: Config (% env !s port !i debug !b))
)`;
}

function capitalize(s: string): string {
  const clean = s.split("/").pop() || s;
  return clean.charAt(0).toUpperCase() + clean.slice(1);
}
