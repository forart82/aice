/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SPAR Decompilation Engine (Get : Concrete -> Abstract)
 * Ingests TypeScript, React JSX, and Angular code and decompiles to canonical SPAR S-expressions.
 */

export interface DecompileResult {
  sparCode: string;
  originalTokens: number;
  decompiledTokens: number;
  reductionPercentage: number;
}

export function decompileTsToSpar(source: string, moduleId = "app"): DecompileResult {
  const lines = source.split("\n");
  const sparLines: string[] = [];

  sparLines.push(`(@module ${moduleId}`);

  // Detect framework/styling from imports
  let framework = "react-19";
  let styling = "tailwind-v4";
  if (source.includes("@angular/core")) framework = "angular";
  if (source.includes("three")) framework = "threejs";
  if (source.includes("phaser")) framework = "phaser";
  if (source.includes("@capacitor")) framework = "capacitor";

  sparLines.push(`  (* framework "${framework}" styling "${styling}" *)`);

  // Extract imports
  const importRegex = /import\s+\{([^}]+)\}\s+from\s+["']([^"']+)["'];?/g;
  let importMatch: RegExpExecArray | null;
  const deps: Array<{ mod: string; syms: string[] }> = [];

  while ((importMatch = importRegex.exec(source)) !== null) {
    const syms = importMatch[1].split(",").map(s => s.trim().replace(/^type\s+/, "")).filter(Boolean);
    const mod = importMatch[2];
    deps.push({ mod, syms });
  }

  if (deps.length > 0) {
    sparLines.push(`  (deps (`);
    for (const d of deps) {
      sparLines.push(`    ("${d.mod}" ${d.syms.join(" ")})`);
    }
    sparLines.push(`  ))`);
  }

  // Extract Type Aliases & Interfaces
  const typeRegex = /(?:export\s+)?(?:type|interface)\s+([A-Za-z0-9_]+)(?:Props)?\s*(?:=|\{)([^;\{]*\{?[^\}]*\}?)/g;
  let typeMatch: RegExpExecArray | null;
  while ((typeMatch = typeRegex.exec(source)) !== null) {
    const typeName = typeMatch[1];
    const rawBody = typeMatch[2];

    if (rawBody.includes("{")) {
      // Record type
      const fieldRegex = /([a-zA-Z0-9_]+)(\??)\s*:\s*([^;,\n\}]+)/g;
      let fieldMatch: RegExpExecArray | null;
      const fields: string[] = [];
      while ((fieldMatch = fieldRegex.exec(rawBody)) !== null) {
        const fName = fieldMatch[1] + (fieldMatch[2] ? "?" : "");
        const fType = convertTsTypeToSpar(fieldMatch[3].trim());
        fields.push(`${fName} ${fType}`);
      }
      sparLines.push(`  (: ${typeName} (% ${fields.join(" ")}))`);
    } else {
      const converted = convertTsTypeToSpar(rawBody.trim());
      sparLines.push(`  (: ${typeName} ${converted})`);
    }
  }

  // Extract React / Functional Components
  const compRegex = /(?:export\s+)?function\s+([A-Z][A-Za-z0-9_]*)\s*\(([^)]*)\)(?::\s*[^\{]+)?\s*\{([\s\S]*?)\n\}/g;
  let compMatch: RegExpExecArray | null;
  while ((compMatch = compRegex.exec(source)) !== null) {
    const compName = compMatch[1];
    const rawProps = compMatch[2];
    const bodyStr = compMatch[3];

    // Determine props contract
    let propsSignature = "(% props !unknown)";
    const propTypeMatch = rawProps.match(/:\s*([A-Za-z0-9_]+)/);
    if (propTypeMatch) {
      propsSignature = `(% props ${propTypeMatch[1]})`;
    }

    sparLines.push(`\n  (# ${compName} ${propsSignature}`);
    sparLines.push(`    (do`);

    // Parse state hooks inside body
    const stateHookRegex = /const\s+\[([a-zA-Z0-9_]+),\s*([a-zA-Z0-9_]+)\]\s*=\s*useState\(([^)]*)\);/g;
    let hookMatch: RegExpExecArray | null;
    while ((hookMatch = stateHookRegex.exec(bodyStr)) !== null) {
      const stateVar = hookMatch[1];
      const setVar = hookMatch[2];
      const initialVal = hookMatch[3].trim() || "0";
      sparLines.push(`      (:= [${stateVar} ${setVar}] (!state ${initialVal}))`);
    }

    // Parse JSX return statement
    const returnJsxMatch = bodyStr.match(/return\s*\(\s*([\s\S]*?)\s*\);/);
    if (returnJsxMatch) {
      const jsxContent = returnJsxMatch[1].trim();
      const sparLayout = decompileJsxToSpar(jsxContent, 6);
      sparLines.push(sparLayout);
    } else {
      sparLines.push(`      (< div (. .) (!str "Empty") >)`);
    }

    sparLines.push(`    )`);
    sparLines.push(`  )`);
  }

  // Extract Standard Functions
  const fnRegex = /(?:export\s+)?function\s+([a-z][A-Za-z0-9_]*)\s*\(([^)]*)\)(?::\s*([^\{]+))?\s*\{([\s\S]*?)\n\}/g;
  let fnMatch: RegExpExecArray | null;
  while ((fnMatch = fnRegex.exec(source)) !== null) {
    const fnName = fnMatch[1];
    const rawParams = fnMatch[2];
    const rawRetType = fnMatch[3] ? fnMatch[3].trim() : "void";
    const bodyStr = fnMatch[4];

    const sparParams: string[] = [];
    if (rawParams.trim()) {
      const paramParts = rawParams.split(",");
      for (const p of paramParts) {
        const [pName, pType] = p.split(":").map(s => s.trim());
        if (pName && pType) {
          sparParams.push(`${pName} ${convertTsTypeToSpar(pType)}`);
        }
      }
    }

    const retSpar = convertTsTypeToSpar(rawRetType);

    sparLines.push(`\n  (! ${fnName} (-> (${sparParams.join(" ")}) ${retSpar})`);
    sparLines.push(`    (do`);

    // Statements
    const stmts = bodyStr.split("\n").map(s => s.trim()).filter(Boolean);
    for (const stmt of stmts) {
      if (stmt.startsWith("return ")) {
        const retExpr = stmt.replace(/^return\s+/, "").replace(/;$/, "");
        sparLines.push(`      ${convertExprToSpar(retExpr)}`);
      } else if (stmt.startsWith("const ") || stmt.startsWith("let ")) {
        const assignMatch = stmt.match(/(?:const|let)\s+([a-zA-Z0-9_]+)\s*=\s*(.+);/);
        if (assignMatch) {
          sparLines.push(`      (:= ${assignMatch[1]} ${convertExprToSpar(assignMatch[2])})`);
        }
      }
    }

    sparLines.push(`    )`);
    sparLines.push(`  )`);
  }

  sparLines.push(`)`);

  const sparCode = sparLines.join("\n");
  const originalTokens = Math.round(source.length / 3.8);
  const decompiledTokens = Math.round(sparCode.length / 4.8);
  const reductionPercentage = Math.round((1 - decompiledTokens / Math.max(1, originalTokens)) * 100);

  return {
    sparCode,
    originalTokens,
    decompiledTokens,
    reductionPercentage: Math.max(0, Math.min(80, reductionPercentage))
  };
}

function convertTsTypeToSpar(tsType: string): string {
  const clean = tsType.trim();
  if (clean === "string") return "!s";
  if (clean === "number") return "!i";
  if (clean === "boolean") return "!b";
  if (clean === "void") return "!void";
  if (clean === "unknown") return "!unknown";
  if (clean === "undefined") return "!nil";
  if (clean.startsWith("Result<")) {
    const match = clean.match(/Result<([^,]+),\s*([^>]+)>/);
    if (match) {
      return `Result[${convertTsTypeToSpar(match[1])}, ${convertTsTypeToSpar(match[2])}]`;
    }
  }
  return clean;
}

function convertExprToSpar(expr: string): string {
  const clean = expr.trim();
  if (/^[0-9]+$/.test(clean)) return clean;
  if (/^"[^"]*"$/.test(clean)) return clean;
  if (clean === "true" || clean === "false") return clean;

  // Binary expression e.g. a + 1 or count > 0
  const binMatch = clean.match(/^([a-zA-Z0-9_.]+)\s*(\+|\-|\*|\/|==|!=|>|<|>=|<=)\s*([a-zA-Z0-9_.]+)$/);
  if (binMatch) {
    return `(${binMatch[2]} ${binMatch[1]} ${binMatch[3]})`;
  }

  // Method call e.g. setCount(count + 1)
  const callMatch = clean.match(/^([a-zA-Z0-9_.]+)\((.*)\)$/);
  if (callMatch) {
    const fnName = callMatch[1];
    const args = callMatch[2] ? convertExprToSpar(callMatch[2]) : "";
    return `(${fnName} ${args})`.trim();
  }

  return clean;
}

function decompileJsxToSpar(jsx: string, indent = 6): string {
  const pad = " ".repeat(indent);
  const tagMatch = jsx.match(/<([a-zA-Z0-9_-]+)([^>]*)>([\s\S]*?)<\/\1>/);
  if (tagMatch) {
    const tag = tagMatch[1];
    const rawAttrs = tagMatch[2];
    const rawChildren = tagMatch[3].trim();

    // Extract attributes
    const attrs: string[] = [];
    const classMatch = rawAttrs.match(/className=["']([^"']+)["']/);
    if (classMatch) {
      attrs.push(`class "${classMatch[1]}"`);
    }
    const clickMatch = rawAttrs.match(/onClick=\{([^}]+)\}/);
    if (clickMatch) {
      attrs.push(`on:click ${clickMatch[1]}`);
    }

    const attrStr = attrs.length > 0 ? `(. ${attrs.join(" ")} .)` : "(. .)";

    // Process children
    if (!rawChildren) {
      return `${pad}(< ${tag} ${attrStr} >)`;
    }

    if (rawChildren.startsWith("<")) {
      const childSpar = decompileJsxToSpar(rawChildren, indent + 2);
      return `${pad}(< ${tag} ${attrStr}\n${childSpar}\n${pad}>)`;
    }

    // Text child or dynamic child
    if (rawChildren.startsWith("{") && rawChildren.endsWith("}")) {
      return `${pad}(< ${tag} ${attrStr} (!val ${rawChildren.slice(1, -1).trim()}) >)`;
    }

    return `${pad}(< ${tag} ${attrStr} (!str "${rawChildren}") >)`;
  }

  return `${pad}(< div (. .) (!str "Element") >)`;
}
