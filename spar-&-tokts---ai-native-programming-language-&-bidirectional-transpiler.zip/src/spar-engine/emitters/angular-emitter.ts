/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Target Emitter: Angular 19 Standalone Component + Signals + inject()
 */

import { SparModule, SparLayoutNode } from "../types.ts";
import { sparTypeToTs, sparExprToTs } from "./common.ts";

export function emitAngular(module: SparModule): string {
  const lines: string[] = [];

  lines.push(`/**`);
  lines.push(` * Automatically synthesized from SPAR intermediate representation`);
  lines.push(` * Module: ${module.id}`);
  lines.push(` * Framework: Angular 19 Standalone Signals Architecture`);
  lines.push(` */`);
  lines.push("");

  lines.push(`import { Component, signal, computed, inject, Input, ChangeDetectionStrategy } from "@angular/core";`);
  lines.push(`import { CommonModule } from "@angular/common";`);

  for (const dep of module.dependencies) {
    if (!dep.modulePath.startsWith("@angular")) {
      lines.push(`import { ${dep.imports.join(", ")} } from "${dep.modulePath}";`);
    }
  }
  lines.push("");

  // Emit Types
  for (const entity of module.entities) {
    if (entity.kind === "TypeDecl") {
      lines.push(`export type ${entity.name} = ${sparTypeToTs(entity.typeExpr)};\n`);
    }
  }

  // Emit Component
  for (const entity of module.entities) {
    if (entity.kind === "ComponentDecl") {
      const selectorName = `app-${entity.name.toLowerCase().replace(/([a-z])([A-Z])/g, "$1-$2")}`;
      const templateHtml = sparLayoutToAngularTemplate(entity.layout, 4);

      lines.push(`@Component({`);
      lines.push(`  selector: "${selectorName}",`);
      lines.push(`  standalone: true,`);
      lines.push(`  imports: [CommonModule],`);
      lines.push(`  changeDetection: ChangeDetectionStrategy.OnPush,`);
      lines.push(`  template: \`\n${templateHtml}\n  \``);
      lines.push(`})`);
      lines.push(`export class ${entity.name}Component {`);

      // Inputs
      if (entity.props) {
        for (const p of entity.props) {
          lines.push(`  @Input() ${p.name}!: ${sparTypeToTs(p.type)};`);
        }
      }

      // Signals, injections, methods
      if (entity.body.kind === "BlockExpr") {
        for (const expr of entity.body.expressions) {
          if (expr.kind === "AssignExpr") {
            const varName = expr.variable;
            const rhs = expr.value;
            if (rhs.kind === "HookExpr") {
              if (rhs.hookType === "signal") {
                lines.push(`  readonly ${varName} = signal(${sparExprToTs(rhs.initOrDep)});`);
              } else if (rhs.hookType === "computed") {
                lines.push(`  readonly ${varName} = computed(${sparExprToTs(rhs.initOrDep)});`);
              } else if (rhs.hookType === "inject") {
                lines.push(`  private readonly ${varName} = inject(${sparExprToTs(rhs.initOrDep)});`);
              }
            } else if (rhs.kind === "LambdaExpr") {
              const params = rhs.params.map(p => `${p.name}: ${sparTypeToTs(p.type)}`).join(", ");
              const ret = rhs.returnType ? `: ${sparTypeToTs(rhs.returnType)}` : "";
              lines.push(`  ${varName}(${params})${ret} {`);
              lines.push(`    ${sparExprToTs(rhs.body)}`);
              lines.push(`  }`);
            } else {
              lines.push(`  ${varName} = ${sparExprToTs(rhs)};`);
            }
          }
        }
      }

      lines.push(`}\n`);
    }
  }

  return lines.join("\n").trim();
}

function sparLayoutToAngularTemplate(node: SparLayoutNode, indent = 4): string {
  const pad = " ".repeat(indent);
  switch (node.kind) {
    case "ElementNode":
      const attrs = Object.entries(node.attributes).map(([k, v]) => {
        if (k === "class") {
          return v.kind === "LiteralExpr" ? `class="${v.raw}"` : `[class]="${sparExprToTs(v)}"`;
        }
        if (k.startsWith("on:")) {
          const evt = k.slice(3);
          return `(${evt})="${sparExprToTs(v)}()"`;
        }
        return `[${k}]="${sparExprToTs(v)}"`;
      }).join(" ");

      const openTag = attrs ? `<${node.tag} ${attrs}>` : `<${node.tag}>`;
      if (node.children.length === 0) return `${pad}${openTag}</${node.tag}>`;
      const inner = node.children.map(c => sparLayoutToAngularTemplate(c, indent + 2)).join("\n");
      return `${pad}${openTag}\n${inner}\n${pad}</${node.tag}>`;

    case "ConditionalLayoutNode":
      const cond = sparExprToTs(node.condition);
      const thenContent = sparLayoutToAngularTemplate(node.thenBranch, indent + 2);
      if (node.elseBranch) {
        const elseContent = sparLayoutToAngularTemplate(node.elseBranch, indent + 2);
        return `${pad}@if (${cond}) {\n${thenContent}\n${pad}} @else {\n${elseContent}\n${pad}}`;
      }
      return `${pad}@if (${cond}) {\n${thenContent}\n${pad}}`;

    case "LoopLayoutNode":
      const list = sparExprToTs(node.listExpr);
      const itemContent = sparLayoutToAngularTemplate(node.template, indent + 2);
      return `${pad}@for (${node.itemSymbol} of ${list}; track ${node.itemSymbol}) {\n${itemContent}\n${pad}}`;

    case "TextLiteralNode":
      return `${pad}${node.content}`;

    case "TextDynamicNode":
      return `${pad}{{ ${sparExprToTs(node.expr)} }}`;

    default:
      return "";
  }
}
