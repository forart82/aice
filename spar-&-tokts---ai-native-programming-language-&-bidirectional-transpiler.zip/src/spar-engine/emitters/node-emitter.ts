/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Target Emitter: Node.js 22/24 Native Zero-Dependency Target
 * Implements TokTS algebraic Result[T, E] and node:test / node:assert
 */

import { SparModule } from "../types.ts";
import { sparTypeToTs, sparExprToTs } from "./common.ts";

export function emitNodeNative(module: SparModule): string {
  const lines: string[] = [];

  lines.push(`/**`);
  lines.push(` * Automatically synthesized from SPAR / TokTS intermediate representation`);
  lines.push(` * Module: ${module.id}`);
  lines.push(` * Runtime: Node.js 22/24 Native Zero-Dependency (--experimental-strip-types)`);
  lines.push(` */`);
  lines.push("");

  // Result algebraic type definition
  lines.push(`// Canonical Result[T, E] runtime algebra`);
  lines.push(`export type Ok<T> = { readonly ok: true; readonly value: T };`);
  lines.push(`export type Err<E> = { readonly ok: false; readonly error: E };`);
  lines.push(`export type Result<T, E> = Ok<T> | Err<E>;`);
  lines.push("");
  lines.push(`export const ok = <T>(value: T): Ok<T> => ({ ok: true, value });`);
  lines.push(`export const err = <E>(error: E): Err<E> => ({ ok: false, error });`);
  lines.push("");
  lines.push(`import { test, describe, it } from "node:test";`);
  lines.push(`import assert from "node:assert/strict";`);
  lines.push("");

  // Module dependencies
  for (const dep of module.dependencies) {
    if (!dep.modulePath.startsWith("node:")) {
      lines.push(`import { ${dep.imports.join(", ")} } from "${dep.modulePath}";`);
    }
  }
  lines.push("");

  // Types
  for (const entity of module.entities) {
    if (entity.kind === "TypeDecl") {
      lines.push(`export type ${entity.name} = ${sparTypeToTs(entity.typeExpr)};\n`);
    }
  }

  // Functions
  for (const entity of module.entities) {
    if (entity.kind === "FunctionDecl") {
      if (entity.name.startsWith("__test_")) {
        // Test entity
        const testTitle = entity.name.replace("__test_", "").replace(/_/g, " ");
        lines.push(`test("${testTitle}", () => {`);
        lines.push(`  ${sparExprToTs(entity.body)}`);
        lines.push(`});\n`);
      } else {
        const params = entity.params.map(p => `${p.name}: ${sparTypeToTs(p.type)}`).join(", ");
        const retType = sparTypeToTs(entity.returnType);
        lines.push(`export function ${entity.name}(${params}): ${retType} {`);
        lines.push(`  ${sparExprToTs(entity.body)}`);
        lines.push(`}\n`);
      }
    }
  }

  return lines.join("\n").trim();
}
