/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Target Emitter: Capacitor 8 Mobile Bridge with Typestate State Automaton
 */

import { SparModule } from "../types.ts";
import { sparTypeToTs } from "./common.ts";

export function emitCapacitor(module: SparModule): string {
  const lines: string[] = [];

  lines.push(`/**`);
  lines.push(` * Automatically synthesized from SPAR intermediate representation`);
  lines.push(` * Module: ${module.id}`);
  lines.push(` * Target: Capacitor 8 Mobile Bridge (Android / iOS / Web)`);
  lines.push(` */`);
  lines.push("");

  lines.push(`import { Capacitor } from "@capacitor/core";`);
  lines.push(`import { Haptics, ImpactStyle } from "@capacitor/haptics";`);
  lines.push(`import { StatusBar, Style } from "@capacitor/status-bar";`);
  lines.push(`import { ScreenOrientation } from "@capacitor/screen-orientation";`);
  lines.push("");

  // Emit types
  for (const entity of module.entities) {
    if (entity.kind === "TypeDecl") {
      lines.push(`export type ${entity.name} = ${sparTypeToTs(entity.typeExpr)};\n`);
    }
  }

  lines.push(`export type MobileBridgeState = "Uninitialized" | "Configured" | "Active";`);
  lines.push("");
  lines.push(`export class MobileDeviceBridge {`);
  lines.push(`  private static state: MobileBridgeState = "Uninitialized";`);
  lines.push("");
  lines.push(`  public static async initialize(): Promise<boolean> {`);
  lines.push(`    if (this.state !== "Uninitialized") return true;`);
  lines.push(`    const isNative = Capacitor.isNativePlatform();`);
  lines.push(`    if (isNative) {`);
  lines.push(`      await StatusBar.setStyle({ style: Style.Dark });`);
  lines.push(`      await ScreenOrientation.lock({ orientation: "portrait" });`);
  lines.push(`    }`);
  lines.push(`    this.state = "Configured";`);
  lines.push(`    return true;`);
  lines.push(`  }`);
  lines.push("");
  lines.push(`  public static async triggerFeedback(impact: ImpactStyle = ImpactStyle.Medium): Promise<void> {`);
  lines.push(`    if (!Capacitor.isPluginAvailable("Haptics")) return;`);
  lines.push(`    await Haptics.impact({ style: impact });`);
  lines.push(`  }`);
  lines.push("");
  lines.push(`  public static getPlatform(): string {`);
  lines.push(`    return Capacitor.getPlatform();`);
  lines.push(`  }`);
  lines.push(`}`);

  return lines.join("\n").trim();
}
