/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Shared Type & Expression Formatter for SPAR Polyglot Emitters
 */

import { SparTypeExpr, SparExpr, SparLayoutNode } from "../types.ts";

export function sparTypeToTs(typeExpr: SparTypeExpr): string {
  switch (typeExpr.kind) {
    case "PrimitiveType":
      switch (typeExpr.name) {
        case "!u": return "number";
        case "!i": return "number";
        case "!f": return "number";
        case "!s": return "string";
        case "!b": return "boolean";
        case "!void": return "void";
        case "!unknown": return "unknown";
        case "!nil": return "undefined";
        default: return "any";
      }
    case "RefinementType":
      // In TS, refinement types project to nominal base type or brand
      return sparTypeToTs({ kind: "PrimitiveType", name: typeExpr.baseType });
    case "UnionType":
      return typeExpr.types.map(sparTypeToTs).join(" | ");
    case "RecordType":
      if (typeExpr.fields.length === 0) return "Record<string, unknown>";
      return `{\n  ${typeExpr.fields.map(f => `${f.name}${f.optional ? "?" : ""}: ${sparTypeToTs(f.type)};`).join("\n  ")}\n}`;
    case "TypestateType":
      return `"${typeExpr.fromState}" | "${typeExpr.toState}"`;
    case "EffectType":
      return sparTypeToTs(typeExpr.returnType);
    case "ResultType":
      return `Result<${sparTypeToTs(typeExpr.okType)}, ${sparTypeToTs(typeExpr.errType)}>`;
    case "TypeRef":
      if (typeExpr.args && typeExpr.args.length > 0) {
        return `${typeExpr.name}<${typeExpr.args.map(sparTypeToTs).join(", ")}>`;
      }
      return typeExpr.name;
    default:
      return "any";
  }
}

export function sparExprToTs(expr: SparExpr): string {
  switch (expr.kind) {
    case "LiteralExpr":
      if (typeof expr.raw === "string") return `"${expr.raw}"`;
      return String(expr.raw);
    case "IdentifierExpr":
      return expr.name;
    case "AssignExpr":
      return `const ${expr.variable} = ${sparExprToTs(expr.value)};`;
    case "BlockExpr":
      return expr.expressions.map(e => {
        const rendered = sparExprToTs(e);
        return rendered.endsWith(";") ? rendered : `${rendered};`;
      }).join("\n");
    case "ApplyExpr":
      // Infix operators
      const binOps = ["+", "-", "*", "/", "%", "==", "!=", ">", "<", ">=", "<=", "&&", "||", "and", "or"];
      if (binOps.includes(expr.operator) && expr.args.length === 2) {
        const op = expr.operator === "and" ? "&&" : expr.operator === "or" ? "||" : expr.operator;
        return `(${sparExprToTs(expr.args[0])} ${op} ${sparExprToTs(expr.args[1])})`;
      }
      if (expr.operator === "!") {
        return `!${sparExprToTs(expr.args[0])}`;
      }
      // Method calls like scene.add or renderer.render
      if (expr.operator.includes(".")) {
        return `${expr.operator}(${expr.args.map(sparExprToTs).join(", ")})`;
      }
      // New operator
      if (expr.operator === "!new") {
        const className = sparExprToTs(expr.args[0]);
        const ctorArgs = expr.args.slice(1).map(sparExprToTs).join(", ");
        return `new ${className}(${ctorArgs})`;
      }
      // Throw
      if (expr.operator === "!throw") {
        return `throw new Error(${sparExprToTs(expr.args[0])})`;
      }
      // General call
      return `${expr.operator}(${expr.args.map(sparExprToTs).join(", ")})`;
    case "MatchExpr":
      return `(() => {\n  switch (${sparExprToTs(expr.target)}) {\n${expr.cases.map(c => `    case ${sparExprToTs(c.pattern)}: return ${sparExprToTs(c.result)};`).join("\n")}\n    default: throw new Error("Unhandled match pattern");\n  }\n})()`;
    case "LambdaExpr":
      const params = expr.params.map(p => `${p.name}: ${sparTypeToTs(p.type)}`).join(", ");
      const retType = expr.returnType ? `: ${sparTypeToTs(expr.returnType)}` : "";
      return `(${params})${retType} => {\n  ${sparExprToTs(expr.body)}\n}`;
    case "TryPropagateExpr":
      return `_unwrap(${sparExprToTs(expr.inner)})`;
    case "LinearAllocExpr":
      return sparExprToTs(expr.target);
    case "LinearTransitionExpr":
      return `${expr.resource}.dispose()`;
    case "NativeCallExpr":
      return `${expr.api}(${expr.args.map(sparExprToTs).join(", ")})`;
    case "HookExpr":
      if (expr.hookType === "state") return `useState(${sparExprToTs(expr.initOrDep)})`;
      if (expr.hookType === "signal") return `signal(${sparExprToTs(expr.initOrDep)})`;
      if (expr.hookType === "computed") return `computed(${sparExprToTs(expr.initOrDep)})`;
      if (expr.hookType === "inject") return `inject(${sparExprToTs(expr.initOrDep)})`;
      return sparExprToTs(expr.initOrDep);
    default:
      return "";
  }
}

export function sparLayoutToJsx(node: SparLayoutNode, indent = 2): string {
  const pad = " ".repeat(indent);

  switch (node.kind) {
    case "ElementNode":
      const attrEntries = Object.entries(node.attributes);
      const attrStr = attrEntries.map(([k, v]) => {
        let propName = k;
        if (k === "class") propName = "className";
        if (k.startsWith("on:")) {
          const evt = k.slice(3);
          propName = `on${evt.charAt(0).toUpperCase()}${evt.slice(1)}`;
        }
        if (v.kind === "LiteralExpr" && typeof v.raw === "string") {
          return `${propName}="${v.raw}"`;
        }
        return `${propName}={${sparExprToTs(v)}}`;
      }).join(" ");

      const openTag = attrStr ? `<${node.tag} ${attrStr}>` : `<${node.tag}>`;

      if (node.children.length === 0) {
        return `${pad}<${node.tag}${attrStr ? " " + attrStr : ""} />`;
      }

      const inner = node.children.map(c => sparLayoutToJsx(c, indent + 2)).join("\n");
      return `${pad}${openTag}\n${inner}\n${pad}</${node.tag}>`;

    case "ConditionalLayoutNode":
      const cond = sparExprToTs(node.condition);
      const thenJsx = sparLayoutToJsx(node.thenBranch, indent + 2).trim();
      const elseJsx = node.elseBranch ? sparLayoutToJsx(node.elseBranch, indent + 2).trim() : "null";
      return `${pad}{${cond} ? (\n${pad}  ${thenJsx}\n${pad}) : (\n${pad}  ${elseJsx}\n${pad})}`;

    case "LoopLayoutNode":
      const list = sparExprToTs(node.listExpr);
      const itemTpl = sparLayoutToJsx(node.template, indent + 4).trim();
      return `${pad}{${list}.map((${node.itemSymbol}, idx) => (\n${pad}  <React.Fragment key={idx}>\n${pad}    ${itemTpl}\n${pad}  </React.Fragment>\n${pad}))}`;

    case "TextLiteralNode":
      return `${pad}${node.content}`;

    case "TextDynamicNode":
      return `${pad}{${sparExprToTs(node.expr)}}`;

    default:
      return "";
  }
}
