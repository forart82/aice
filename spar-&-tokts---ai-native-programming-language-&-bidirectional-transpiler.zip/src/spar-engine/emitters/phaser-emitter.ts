/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Target Emitter: Phaser 2D Arcade Game Scene
 */

import { SparModule } from "../types.ts";

export function emitPhaser(module: SparModule): string {
  const lines: string[] = [];

  lines.push(`/**`);
  lines.push(` * Automatically synthesized from SPAR intermediate representation`);
  lines.push(` * Module: ${module.id}`);
  lines.push(` * Engine: Phaser 3+ / Arcade Physics 2D`);
  lines.push(` */`);
  lines.push("");

  lines.push(`import Phaser from "phaser";`);
  lines.push("");

  lines.push(`export class SpaceGameScene extends Phaser.Scene {`);
  lines.push(`  private player!: Phaser.Physics.Arcade.Sprite;`);
  lines.push(`  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;`);
  lines.push(`  private scoreText!: Phaser.GameObjects.Text;`);
  lines.push(`  private score: number = 0;`);
  lines.push("");
  lines.push(`  constructor() {`);
  lines.push(`    super({ key: "${module.id}" });`);
  lines.push(`  }`);
  lines.push("");
  lines.push(`  preload(): void {`);
  lines.push(`    // Asset loading stage`);
  lines.push(`    this.load.image("ship", "assets/ship.png");`);
  lines.push(`    this.load.image("star", "assets/star.png");`);
  lines.push(`  }`);
  lines.push("");
  lines.push(`  create(): void {`);
  lines.push(`    // 2D Scene construction`);
  lines.push(`    this.player = this.physics.add.sprite(400, 300, "ship");`);
  lines.push(`    this.player.setCollideWorldBounds(true);`);
  lines.push(`    this.player.setDamping(true);`);
  lines.push(`    this.player.setDrag(0.98);`);
  lines.push(`    this.player.setMaxVelocity(400);`);
  lines.push("");
  lines.push(`    if (this.input.keyboard) {`);
  lines.push(`      this.cursors = this.input.keyboard.createCursorKeys();`);
  lines.push(`    }`);
  lines.push("");
  lines.push(`    this.scoreText = this.add.text(16, 16, "Score: 0", {`);
  lines.push(`      fontSize: "20px",`);
  lines.push(`      color: "#ffffff"`);
  lines.push(`    });`);
  lines.push(`  }`);
  lines.push("");
  lines.push(`  update(_time: number, delta: number): void {`);
  lines.push(`    if (!this.cursors) return;`);
  lines.push("");
  lines.push(`    if (this.cursors.left.isDown) {`);
  lines.push(`      this.player.setAngularVelocity(-300);`);
  lines.push(`    } else if (this.cursors.right.isDown) {`);
  lines.push(`      this.player.setAngularVelocity(300);`);
  lines.push(`    } else {`);
  lines.push(`      this.player.setAngularVelocity(0);`);
  lines.push(`    }`);
  lines.push("");
  lines.push(`    if (this.cursors.up.isDown) {`);
  lines.push(`      this.physics.velocityFromRotation(this.player.rotation, 300, this.player.body!.velocity);`);
  lines.push(`    }`);
  lines.push(`  }`);
  lines.push(`}`);
  lines.push("");
  lines.push(`export function initPhaserGame(parentContainerId: string): Phaser.Game {`);
  lines.push(`  const config: Phaser.Types.Core.GameConfig = {`);
  lines.push(`    type: Phaser.AUTO,`);
  lines.push(`    width: 800,`);
  lines.push(`    height: 600,`);
  lines.push(`    parent: parentContainerId,`);
  lines.push(`    physics: {`);
  lines.push(`      default: "arcade",`);
  lines.push(`      arcade: { gravity: { y: 0, x: 0 }, debug: false }`);
  lines.push(`    },`);
  lines.push(`    scene: [SpaceGameScene]`);
  lines.push(`  };`);
  lines.push(`  return new Phaser.Game(config);`);
  lines.push(`}`);

  return lines.join("\n").trim();
}
