/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Target Emitter: React 19 + Tailwind CSS v4 + TypeScript
 */

import { SparModule } from "../types.ts";
import { sparTypeToTs, sparExprToTs, sparLayoutToJsx } from "./common.ts";

export function emitReact(module: SparModule): string {
  const lines: string[] = [];

  // Header comment
  lines.push(`/**`);
  lines.push(` * Automatically synthesized from SPAR intermediate representation`);
  lines.push(` * Module: ${module.id}`);
  lines.push(` * Framework: React 19 | Styling: Tailwind CSS v4`);
  lines.push(` */`);
  lines.push("");

  // Standard React imports
  lines.push(`import React, { useState, useEffect, useMemo, useCallback } from "react";`);

  // Dependency imports from module
  for (const dep of module.dependencies) {
    if (dep.modulePath !== "react") {
      lines.push(`import { ${dep.imports.join(", ")} } from "${dep.modulePath}";`);
    }
  }
  lines.push("");

  // Emit Type Declarations
  for (const entity of module.entities) {
    if (entity.kind === "TypeDecl") {
      lines.push(`export type ${entity.name} = ${sparTypeToTs(entity.typeExpr)};\n`);
    }
  }

  // Emit Pure Functions
  for (const entity of module.entities) {
    if (entity.kind === "FunctionDecl") {
      const params = entity.params.map(p => `${p.name}: ${sparTypeToTs(p.type)}`).join(", ");
      const retType = sparTypeToTs(entity.returnType);
      lines.push(`export function ${entity.name}(${params}): ${retType} {`);
      lines.push(`  ${sparExprToTs(entity.body)}`);
      lines.push(`}\n`);
    }
  }

  // Emit Components
  for (const entity of module.entities) {
    if (entity.kind === "ComponentDecl") {
      const propsType = entity.propContractName
        ? entity.propContractName
        : entity.props && entity.props.length > 0
        ? `{\n  ${entity.props.map(p => `${p.name}: ${sparTypeToTs(p.type)};`).join("\n  ")}\n}`
        : "Record<string, never>";

      lines.push(`export interface ${entity.name}Props ${entity.propContractName ? `extends ${entity.propContractName}` : `= ${propsType}`};`);
      lines.push("");
      lines.push(`export function ${entity.name}(props: ${entity.name}Props): React.JSX.Element {`);

      // Component body (state hooks, handlers)
      if (entity.body.kind === "BlockExpr") {
        for (const expr of entity.body.expressions) {
          const stmt = sparExprToTs(expr);
          lines.push(`  ${stmt}`);
        }
      } else {
        const stmt = sparExprToTs(entity.body);
        if (stmt) lines.push(`  ${stmt}`);
      }

      // Return JSX layout
      lines.push("");
      lines.push(`  return (`);
      lines.push(sparLayoutToJsx(entity.layout, 4));
      lines.push(`  );`);
      lines.push(`}\n`);
      lines.push(`export default ${entity.name};`);
    }
  }

  return lines.join("\n").trim();
}
