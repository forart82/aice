/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SPAR Multi-File & Whole-Folder Workspace Engine
 * Handles bidirectional folder compilation, Virtual File System (VFS), and ZIP archives.
 */

import JSZip from "jszip";
import { BidirectionalLensEngine } from "./lens.ts";
import { TargetLanguage } from "./types.ts";
import { detectLanguageFromFilename, getLanguageById } from "./languages.ts";

export interface VirtualFile {
  path: string;
  content: string;
  type?: "typescript" | "jsx" | "spar" | "json" | "config" | "html" | "css";
  targetLang?: string;
}

export interface WorkspaceManifest {
  name: string;
  target: string;
  packageManager?: string;
  bundler?: string;
}

export interface SparWorkspaceUnit {
  manifest: WorkspaceManifest;
  files: Array<{
    filePath: string;
    sparSource: string;
  }>;
}

export class WorkspaceEngine {
  /**
   * Compiles an abstract SPAR @workspace document into a complete multi-file project tree.
   * Recognizes *.XX.spar filenames and compiles them to *.XX files.
   */
  public static putWorkspace(
    workspaceSpar: string,
    fallbackTarget: string = "react-tailwind"
  ): VirtualFile[] {
    const files: VirtualFile[] = [];

    // Parse workspace header: (@workspace "name" (* ... *) ...)
    const wsMatch = workspaceSpar.match(/\(@workspace\s+["']?([a-zA-Z0-9_\-]+)["']?/);
    const workspaceName = wsMatch ? wsMatch[1] : "spar-project";

    let target = fallbackTarget;
    const targetMatch = workspaceSpar.match(/target\s+["']([a-zA-Z0-9_\-]+)["']/);
    if (targetMatch) {
      target = targetMatch[1];
    }

    // Extract all (@file "path" (@module ...)) blocks
    const fileBlocks = this.extractFileBlocks(workspaceSpar);

    if (fileBlocks.length === 0) {
      // Single module fallback
      const detected = detectLanguageFromFilename(target);
      const transpile = BidirectionalLensEngine.put(workspaceSpar, detected.id);
      const ext = detected.extension;
      files.push({
        path: `src/App.${ext}`,
        content: transpile.code,
        targetLang: detected.id
      });
    } else {
      for (const block of fileBlocks) {
        // Handle *.XX.spar naming
        let compiledPath = block.filePath;
        let fileTarget = target;

        if (block.filePath.endsWith(".spar")) {
          // e.g. "src/components/Counter.vue.spar" -> "src/components/Counter.vue"
          compiledPath = block.filePath.replace(/\.spar$/, "");
          const lang = detectLanguageFromFilename(block.filePath);
          fileTarget = lang.id;
        } else {
          const lang = detectLanguageFromFilename(block.filePath);
          fileTarget = lang.id;
        }

        const transpile = BidirectionalLensEngine.put(block.sparSource, fileTarget);
        files.push({
          path: compiledPath,
          content: transpile.code,
          targetLang: fileTarget
        });
      }
    }

    // Scaffolding
    files.push({
      path: "package.json",
      content: this.generatePackageJson(workspaceName, target as TargetLanguage),
      type: "json"
    });

    files.push({
      path: "tsconfig.json",
      content: this.generateTsConfig(target as TargetLanguage),
      type: "json"
    });

    return files;
  }

  /**
   * Decompiles an entire folder of concrete web files into a unified SPAR @workspace document.
   * Maps each file foo.XX to foo.XX.spar.
   */
  public static getWorkspace(
    files: VirtualFile[],
    workspaceName = "fullstack-project",
    target: string = "react-tailwind"
  ): string {
    const lines: string[] = [];

    lines.push(`(@workspace "${workspaceName}"`);
    lines.push(`  (* target "${target}" convention "*.XX.spar" *)`);

    const sourceFiles = files.filter(f => 
      !f.path.includes("node_modules") &&
      !f.path.includes("package-lock") &&
      !f.path.endsWith(".map")
    );

    if (sourceFiles.length === 0) {
      lines.push(`  ;; No source files found in workspace.`);
      lines.push(`)`);
      return lines.join("\n");
    }

    for (const f of sourceFiles) {
      const lang = detectLanguageFromFilename(f.path);
      const sparFilename = f.path.endsWith(".spar") ? f.path : `${f.path}.spar`;
      const moduleId = f.path.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9_\-\/]/g, "_");

      const decompiledSpar = BidirectionalLensEngine.get(f.content, lang.id, moduleId);

      lines.push(`\n  (@file "${sparFilename}"`);
      const indented = decompiledSpar.split("\n").map(l => `    ${l}`).join("\n");
      lines.push(indented);
      lines.push(`  )`);
    }

    lines.push(`)`);
    return lines.join("\n");
  }

  /**
   * Bundles all virtual files into a downloadable ZIP archive.
   */
  public static async exportToZip(files: VirtualFile[], zipFilename = "spar-project.zip"): Promise<Blob> {
    const zip = new JSZip();

    for (const f of files) {
      zip.file(f.path, f.content);
    }

    const blob = await zip.generateAsync({ type: "blob" });
    return blob;
  }

  /**
   * Ingests an uploaded ZIP file and extracts all text source files.
   */
  public static async importFromZip(file: File | Blob): Promise<VirtualFile[]> {
    const zip = await JSZip.loadAsync(file);
    const virtualFiles: VirtualFile[] = [];

    const filePromises: Promise<void>[] = [];

    zip.forEach((relativePath, zipEntry) => {
      if (zipEntry.dir) return;

      // Filter relevant source files
      if (
        relativePath.endsWith(".ts") ||
        relativePath.endsWith(".tsx") ||
        relativePath.endsWith(".js") ||
        relativePath.endsWith(".jsx") ||
        relativePath.endsWith(".spar") ||
        relativePath.endsWith(".tok") ||
        relativePath.endsWith(".json") ||
        relativePath.endsWith(".html") ||
        relativePath.endsWith(".css")
      ) {
        filePromises.push(
          zipEntry.async("string").then(content => {
            virtualFiles.push({
              path: relativePath,
              content
            });
          })
        );
      }
    });

    await Promise.all(filePromises);
    return virtualFiles;
  }

  private static extractFileBlocks(workspaceSpar: string): Array<{ filePath: string; sparSource: string }> {
    const blocks: Array<{ filePath: string; sparSource: string }> = [];
    const fileTagRegex = /\(@file\s+["']([^"']+)["']\s*([\s\S]*?)(?=\(@file|\)$)/g;

    let match: RegExpExecArray | null;
    while ((match = fileTagRegex.exec(workspaceSpar)) !== null) {
      const filePath = match[1];
      const sparSource = match[2].trim().replace(/\)$/, "").trim();
      blocks.push({ filePath, sparSource });
    }

    return blocks;
  }

  private static generatePackageJson(name: string, target: TargetLanguage): string {
    const isReact = target === "react-tailwind";
    const isAngular = target === "angular-signals";
    const isThree = target === "threejs-webgl";
    const isPhaser = target === "phaser-2d";
    const isCapacitor = target === "capacitor-mobile";

    const deps: Record<string, string> = {};
    const devDeps: Record<string, string> = {
      typescript: "^5.8.0",
      vite: "^6.0.0"
    };

    if (isReact) {
      deps["react"] = "^19.0.0";
      deps["react-dom"] = "^19.0.0";
      deps["lucide-react"] = "^0.475.0";
      devDeps["@tailwindcss/vite"] = "^4.0.0";
      devDeps["tailwindcss"] = "^4.0.0";
      devDeps["@types/react"] = "^19.0.0";
      devDeps["@types/react-dom"] = "^19.0.0";
    } else if (isAngular) {
      deps["@angular/core"] = "^19.0.0";
      deps["@angular/common"] = "^19.0.0";
      deps["rxjs"] = "^7.8.0";
    } else if (isThree) {
      deps["three"] = "^0.174.0";
      devDeps["@types/three"] = "^0.174.0";
    } else if (isPhaser) {
      deps["phaser"] = "^3.88.0";
    } else if (isCapacitor) {
      deps["@capacitor/core"] = "^8.0.0";
      deps["@capacitor/haptics"] = "^8.0.0";
      deps["@capacitor/status-bar"] = "^8.0.0";
    }

    return JSON.stringify({
      name,
      version: "1.0.0",
      type: "module",
      scripts: {
        dev: "vite",
        build: "vite build",
        preview: "vite preview",
        check: "tsc --noEmit"
      },
      dependencies: deps,
      devDependencies: devDeps
    }, null, 2);
  }

  private static generateTsConfig(target: TargetLanguage): string {
    return JSON.stringify({
      compilerOptions: {
        target: "ES2022",
        module: "NodeNext",
        moduleResolution: "NodeNext",
        jsx: target === "react-tailwind" ? "react-jsx" : "preserve",
        strict: true,
        skipLibCheck: true,
        allowImportingTsExtensions: true,
        noEmit: true
      },
      include: ["src/**/*"]
    }, null, 2);
  }

  private static generateViteConfig(target: TargetLanguage): string {
    if (target === "react-tailwind") {
      return `import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()]
});`;
    }

    return `import { defineConfig } from "vite";

export default defineConfig({
  server: { port: 3000 }
});`;
  }

  private static generateIndexHtml(title: string, target: TargetLanguage): string {
    const isReact = target === "react-tailwind";
    return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${title} (Generated by SPAR)</title>
  </head>
  <body class="bg-slate-950 text-white">
    <div id="root"></div>
    ${isReact ? '<script type="module" src="/src/main.tsx"></script>' : '<script type="module" src="/src/main.ts"></script>'}
  </body>
</html>`;
  }
}
