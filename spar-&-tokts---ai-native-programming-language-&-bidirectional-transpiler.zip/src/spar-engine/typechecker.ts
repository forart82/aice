/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SPAR Type Calculus, Linear Typestate Automata & Refinement Solver
 */

import {
  SparModule,
  StaticAnalysisReport,
  DiagnosticEntry,
  SparExpr,
  EffectKind,
  SourceSpan
} from "./types.ts";

export function typecheckSpar(module: SparModule): StaticAnalysisReport {
  const diagnostics: DiagnosticEntry[] = [];
  const typestateTransitions: StaticAnalysisReport["typestateTransitions"] = [];
  const refinementChecks: StaticAnalysisReport["refinementChecks"] = [];
  const algebraicEffects: StaticAnalysisReport["algebraicEffects"] = [];

  // Track declared typestates & resources across module
  const resourceTypestates = new Map<string, {
    state: string;
    allocatedLine: number;
    disposedLine?: number;
  }>();

  // Track refinement types in module
  const refinementTypes = new Map<string, {
    symbol: string;
    predicate: SparExpr;
    baseType: string;
  }>();

  // 1. Collect all declared Types
  for (const entity of module.entities) {
    if (entity.kind === "TypeDecl") {
      if (entity.typeExpr.kind === "RefinementType") {
        refinementTypes.set(entity.name, {
          symbol: entity.typeExpr.symbol,
          predicate: entity.typeExpr.predicate,
          baseType: entity.typeExpr.baseType
        });

        // Test sample refinement verification condition
        const verified = verifyRefinementPredicate(entity.typeExpr.predicate);
        refinementChecks.push({
          symbol: entity.name,
          predicate: formatExpr(entity.typeExpr.predicate),
          verified: verified.ok,
          sampleValue: verified.sample
        });

        if (!verified.ok) {
          diagnostics.push({
            status: "REJECTED",
            error_phase: "REFINEMENT_VERIFICATION",
            span: entity.span || { line: 1, col: 1 },
            violation: {
              code: "E2001_UNSATISFIABLE_REFINEMENT",
              message: `Refinement predicate '${formatExpr(entity.typeExpr.predicate)}' is unsatisfiable or contradictory.`
            },
            invariant_correction_rule: "Ensure bounds are consistent: min <= max."
          });
        }
      }

      if (entity.typeExpr.kind === "TypestateType") {
        typestateTransitions.push({
          resource: entity.name,
          from: entity.typeExpr.fromState,
          to: entity.typeExpr.toState,
          line: entity.span?.line || 1,
          valid: true
        });
      }
    }
  }

  // 2. Inspect Function Declarations & Component Bodies
  for (const entity of module.entities) {
    if (entity.kind === "FunctionDecl") {
      const declaredEffects = entity.effects || [];
      const incurredEffects = new Set<EffectKind>();

      // Walk function body
      walkExpr(entity.body, entity.span?.line || 1, (expr, currentLine) => {
        // Linear Alloc: (!linearAlloc ...)
        if (expr.kind === "LinearAllocExpr") {
          incurredEffects.add("GPU");
        }

        // Variable assignment that might bind a linear resource
        if (expr.kind === "AssignExpr") {
          const varName = expr.variable;
          if (expr.value.kind === "LinearAllocExpr") {
            resourceTypestates.set(varName, {
              state: "Allocated",
              allocatedLine: currentLine
            });
            typestateTransitions.push({
              resource: varName,
              from: "Unallocated",
              to: "Allocated",
              line: currentLine,
              valid: true
            });
          }

          // Check if assigning a value to a refinement-typed variable
          checkRefinementAssignment(varName, expr.value, currentLine);
        }

        // Disposal / State Transition: (!dispose res)
        if (expr.kind === "LinearTransitionExpr") {
          const res = expr.resource;
          const currentResource = resourceTypestates.get(res);
          if (currentResource) {
            if (currentResource.state === "Disposed") {
              diagnostics.push({
                status: "REJECTED",
                error_phase: "TYPESTATE_VERIFICATION",
                span: expr.span || { line: currentLine, col: 1, symbol: `!dispose ${res}` },
                violation: {
                  code: "E3003_DOUBLE_DISPOSAL",
                  message: `Linear resource '${res}' is already disposed at line ${currentResource.disposedLine}. Double disposal detected.`,
                  context: { resource: res, previouslyDisposedAt: currentResource.disposedLine }
                },
                invariant_correction_rule: `Remove redundant (!dispose ${res}) invocation.`
              });
            } else {
              currentResource.state = "Disposed";
              currentResource.disposedLine = currentLine;
              typestateTransitions.push({
                resource: res,
                from: "Allocated",
                to: "Disposed",
                line: currentLine,
                valid: true
              });
            }
          }
        }

        // Usage of resource in expressions e.g. (renderer.render scene camera) or (cube.rotation.x)
        if (expr.kind === "ApplyExpr") {
          // Check if operator or args reference a disposed resource
          const opTarget = expr.operator.split(".")[0];
          checkResourceUse(opTarget, expr.span || { line: currentLine, col: 1, symbol: expr.operator });

          for (const arg of expr.args) {
            if (arg.kind === "IdentifierExpr") {
              checkResourceUse(arg.name, arg.span || { line: currentLine, col: 1, symbol: arg.name });
            }
          }

          // Incurred effects detection
          if (expr.operator.includes("render") || expr.operator.includes("gl") || expr.operator.includes("draw")) {
            incurredEffects.add("GPU");
          }
          if (expr.operator.includes("fetch") || expr.operator.includes("http") || expr.operator.includes("ws")) {
            incurredEffects.add("Network");
          }
          if (expr.operator.includes("fs") || expr.operator.includes("file") || expr.operator.includes("console")) {
            incurredEffects.add("IO");
          }
        }

        // Native Call: (!nativeCall ...)
        if (expr.kind === "NativeCallExpr") {
          incurredEffects.add("Native");
        }

        // Try unwrap operator: (? expr) or expr?
        if (expr.kind === "TryPropagateExpr") {
          const retType = entity.returnType;
          if (retType.kind !== "ResultType" && !(retType.kind === "TypeRef" && retType.name.startsWith("Result"))) {
            diagnostics.push({
              status: "REJECTED",
              error_phase: "TYPE_CALCULUS",
              span: expr.span || { line: currentLine, col: 1 },
              violation: {
                code: "E2003_TRY_OPERATOR_OUTSIDE_RESULT",
                message: `Postfix '?' unwrap operator utilized inside function '${entity.name}' returning non-Result type '${retType.kind}'.`,
                context: { functionName: entity.name, returnType: retType }
              },
              invariant_correction_rule: `Change '${entity.name}' return type signature to 'Result[T, E]'.`,
              fix: `Result[${formatType(retType)}, Error]`
            });
          }
        }
      });

      // Verify Algebraic Effects Conformance
      const undeclaredEffects = Array.from(incurredEffects).filter(e => !declaredEffects.includes(e));
      const isEffectsValid = undeclaredEffects.length === 0;

      algebraicEffects.push({
        fnName: entity.name,
        declaredEffects,
        incurredEffects: Array.from(incurredEffects),
        valid: isEffectsValid
      });

      if (!isEffectsValid) {
        diagnostics.push({
          status: "REJECTED",
          error_phase: "EFFECT_CONFORMANCE",
          span: entity.span || { line: 1, col: 1, symbol: entity.name },
          violation: {
            code: "E4001_UNDECLARED_ALGEBRAIC_EFFECT",
            message: `Function '${entity.name}' executes side effects [${undeclaredEffects.join(", ")}] but signature declares [${declaredEffects.join(", ")}].`,
            context: { undeclaredEffects, declaredEffects }
          },
          invariant_correction_rule: `Annotate function signature with effect wrapper '(!^ ${formatType(entity.returnType)} [${Array.from(incurredEffects).join(" ")}])'.`,
          fix: `(!^ ${formatType(entity.returnType)} [${Array.from(incurredEffects).join(" ")}])`
        });
      }
    }

    if (entity.kind === "ComponentDecl") {
      // Components incur DOM and State effects implicitly
      algebraicEffects.push({
        fnName: entity.name,
        declaredEffects: ["DOM", "State"],
        incurredEffects: ["DOM", "State"],
        valid: true
      });
    }
  }

  function checkResourceUse(resName: string, span: SourceSpan) {
    const res = resourceTypestates.get(resName);
    if (res && res.state === "Disposed") {
      diagnostics.push({
        status: "REJECTED",
        error_phase: "TYPESTATE_VERIFICATION",
        span,
        violation: {
          code: "E3002_INVALID_TYPESTATE",
          message: `Resource '${resName}' utilized in typestate 'Disposed'. Required: 'Allocated'.`,
          context: {
            allocated_at: { line: res.allocatedLine, col: 1 },
            disposed_at: { line: res.disposedLine, col: 1 }
          }
        },
        invariant_correction_rule: `Remove premature (!dispose ${resName}) at line ${res.disposedLine} or clone linear reference before invocation.`,
        fix: `// keep ${resName} alive until end of lifecycle`
      });
    }
  }

  function checkRefinementAssignment(varName: string, valExpr: SparExpr, currentLine: number) {
    // If variable name or type has an attached refinement predicate
    for (const [refName, refDef] of refinementTypes.entries()) {
      if (varName.toLowerCase().includes(refName.toLowerCase()) || varName.toLowerCase().includes(refDef.symbol.toLowerCase())) {
        if (valExpr.kind === "LiteralExpr" && typeof valExpr.raw === "number") {
          const num = valExpr.raw;
          const satisfies = testNumericPredicate(refDef.predicate, num);
          if (!satisfies) {
            diagnostics.push({
              status: "REJECTED",
              error_phase: "REFINEMENT_VERIFICATION",
              span: valExpr.span || { line: currentLine, col: 1, symbol: varName },
              violation: {
                code: "E2002_REFINEMENT_CONSTRAINT_VIOLATED",
                message: `Literal value ${num} assigned to '${varName}' violates refinement type '${refName}' predicate '${formatExpr(refDef.predicate)}'.`,
                context: { assignedValue: num, refinementType: refName }
              },
              invariant_correction_rule: `Provide a value satisfying constraint '${formatExpr(refDef.predicate)}'.`
            });
          }
        }
      }
    }
  }

  const overallStatus = diagnostics.some(d => d.status === "REJECTED") ? "REJECTED" : "VERIFIED";

  return {
    status: overallStatus,
    diagnostics,
    typestateTransitions,
    refinementChecks,
    algebraicEffects
  };
}

// Linear arithmetic predicate solver for Presburger bounds: (and (>= p 1) (<= p 65535))
function verifyRefinementPredicate(pred: SparExpr): { ok: boolean; sample?: number } {
  if (pred.kind === "ApplyExpr") {
    if (pred.operator === "and") {
      let min = -Infinity;
      let max = Infinity;

      for (const clause of pred.args) {
        if (clause.kind === "ApplyExpr") {
          const op = clause.operator;
          const litArg = clause.args.find(a => a.kind === "LiteralExpr") as { kind: "LiteralExpr"; raw: number } | undefined;
          if (litArg && typeof litArg.raw === "number") {
            if (op === ">=") min = Math.max(min, litArg.raw);
            if (op === ">") min = Math.max(min, litArg.raw + 1);
            if (op === "<=") max = Math.min(max, litArg.raw);
            if (op === "<") max = Math.min(max, litArg.raw - 1);
          }
        }
      }

      if (min > max) {
        return { ok: false };
      }
      return { ok: true, sample: min === -Infinity ? 8080 : min };
    }
  }
  return { ok: true, sample: 1 };
}

function testNumericPredicate(pred: SparExpr, val: number): boolean {
  if (pred.kind === "ApplyExpr") {
    if (pred.operator === "and") {
      return pred.args.every(a => testNumericPredicate(a, val));
    }
    if (pred.operator === ">=") {
      const lit = pred.args.find(a => a.kind === "LiteralExpr") as { raw: number } | undefined;
      return lit ? val >= lit.raw : true;
    }
    if (pred.operator === "<=") {
      const lit = pred.args.find(a => a.kind === "LiteralExpr") as { raw: number } | undefined;
      return lit ? val <= lit.raw : true;
    }
    if (pred.operator === ">") {
      const lit = pred.args.find(a => a.kind === "LiteralExpr") as { raw: number } | undefined;
      return lit ? val > lit.raw : true;
    }
    if (pred.operator === "<") {
      const lit = pred.args.find(a => a.kind === "LiteralExpr") as { raw: number } | undefined;
      return lit ? val < lit.raw : true;
    }
  }
  return true;
}

function walkExpr(expr: SparExpr, line: number, visitor: (e: SparExpr, l: number) => void) {
  const currentLine = expr.span?.line || line;
  visitor(expr, currentLine);

  switch (expr.kind) {
    case "BlockExpr":
      for (const e of expr.expressions) walkExpr(e, currentLine, visitor);
      break;
    case "AssignExpr":
      walkExpr(expr.value, currentLine, visitor);
      break;
    case "ApplyExpr":
      for (const a of expr.args) walkExpr(a, currentLine, visitor);
      break;
    case "MatchExpr":
      walkExpr(expr.target, currentLine, visitor);
      for (const c of expr.cases) {
        walkExpr(c.pattern, currentLine, visitor);
        walkExpr(c.result, currentLine, visitor);
      }
      break;
    case "LambdaExpr":
      walkExpr(expr.body, currentLine, visitor);
      break;
    case "TryPropagateExpr":
      walkExpr(expr.inner, currentLine, visitor);
      break;
    case "LinearAllocExpr":
      walkExpr(expr.target, currentLine, visitor);
      break;
    case "NativeCallExpr":
      for (const a of expr.args) walkExpr(a, currentLine, visitor);
      break;
    case "HookExpr":
      walkExpr(expr.initOrDep, currentLine, visitor);
      break;
  }
}

function formatExpr(expr: SparExpr): string {
  if (expr.kind === "IdentifierExpr") return expr.name;
  if (expr.kind === "LiteralExpr") return String(expr.raw);
  if (expr.kind === "ApplyExpr") {
    return `(${expr.operator} ${expr.args.map(formatExpr).join(" ")})`;
  }
  return "";
}

function formatType(t: any): string {
  if (t.kind === "PrimitiveType") return t.name;
  if (t.kind === "TypeRef") return t.name;
  if (t.kind === "RecordType") return "{ ... }";
  return "!unknown";
}
