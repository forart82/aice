/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Semantic Polyglot AI Representation (SPAR) & TokTS
 * Universal Abstract Syntax Tree (UAST) & Type Calculus Definitions
 */

export type SourceSpan = {
  line: number;
  col: number;
  endLine?: number;
  endCol?: number;
  symbol?: string;
};

export type PrimitiveKind = 
  | "!u"       // Unsigned integer
  | "!i"       // Signed 32-bit integer
  | "!f"       // IEEE 754 64-bit float
  | "!s"       // UTF-8 string
  | "!b"       // Boolean
  | "!void"    // Unit / void
  | "!unknown" // Safe unknown
  | "!nil";    // Null / undefined

export type EffectKind = "IO" | "DOM" | "Async" | "State" | "Network" | "GPU" | "Native";

export interface PrimitiveTypeNode {
  kind: "PrimitiveType";
  name: PrimitiveKind;
  span?: SourceSpan;
}

export interface RefinementTypeNode {
  kind: "RefinementType";
  symbol: string;
  baseType: PrimitiveKind;
  predicate: SparExpr;
  span?: SourceSpan;
}

export interface UnionTypeNode {
  kind: "UnionType";
  types: SparTypeExpr[];
  span?: SourceSpan;
}

export interface RecordTypeNode {
  kind: "RecordType";
  fields: Array<{ name: string; type: SparTypeExpr; optional?: boolean }>;
  span?: SourceSpan;
}

export interface TypestateTypeNode {
  kind: "TypestateType";
  resource: string;
  fromState: string;
  toState: string;
  span?: SourceSpan;
}

export interface EffectTypeNode {
  kind: "EffectType";
  returnType: SparTypeExpr;
  effects: EffectKind[];
  span?: SourceSpan;
}

export interface ResultTypeNode {
  kind: "ResultType";
  okType: SparTypeExpr;
  errType: SparTypeExpr;
  span?: SourceSpan;
}

export interface TypeRefNode {
  kind: "TypeRef";
  name: string;
  args?: SparTypeExpr[];
  span?: SourceSpan;
}

export type SparTypeExpr = 
  | PrimitiveTypeNode
  | RefinementTypeNode
  | UnionTypeNode
  | RecordTypeNode
  | TypestateTypeNode
  | EffectTypeNode
  | ResultTypeNode
  | TypeRefNode;

export interface SparManifestEntry {
  key: string;
  value: string | number | boolean;
}

export interface SparDependency {
  modulePath: string;
  imports: string[];
}

export interface SparTypeDecl {
  kind: "TypeDecl";
  name: string;
  typeExpr: SparTypeExpr;
  isExported?: boolean;
  span?: SourceSpan;
}

export interface SparParam {
  name: string;
  type: SparTypeExpr;
}

export interface SparFunctionDecl {
  kind: "FunctionDecl";
  name: string;
  params: SparParam[];
  returnType: SparTypeExpr;
  body: SparExpr;
  effects?: EffectKind[];
  isExported?: boolean;
  span?: SourceSpan;
}

export interface SparComponentDecl {
  kind: "ComponentDecl";
  name: string;
  propContractName?: string;
  props?: Array<{ name: string; type: SparTypeExpr }>;
  body: SparExpr;
  layout: SparLayoutNode;
  span?: SourceSpan;
}

export interface SparStyleRule {
  property: string;
  value: string;
}

export interface SparStyleDecl {
  kind: "StyleDecl";
  name: string;
  rules: SparStyleRule[];
  span?: SourceSpan;
}

// Layout nodes for DOM / Components
export type SparLayoutNode =
  | {
      kind: "ElementNode";
      tag: string;
      attributes: Record<string, SparExpr>;
      children: SparLayoutNode[];
      span?: SourceSpan;
    }
  | {
      kind: "ConditionalLayoutNode";
      condition: SparExpr;
      thenBranch: SparLayoutNode;
      elseBranch?: SparLayoutNode;
      span?: SourceSpan;
    }
  | {
      kind: "LoopLayoutNode";
      listExpr: SparExpr;
      itemSymbol: string;
      template: SparLayoutNode;
      span?: SourceSpan;
    }
  | {
      kind: "TextLiteralNode";
      content: string;
      span?: SourceSpan;
    }
  | {
      kind: "TextDynamicNode";
      expr: SparExpr;
      span?: SourceSpan;
    };

// Expressions
export type SparExpr =
  | { kind: "LiteralExpr"; raw: string | number | boolean | null; litType: PrimitiveKind; span?: SourceSpan }
  | { kind: "IdentifierExpr"; name: string; span?: SourceSpan }
  | { kind: "ApplyExpr"; operator: string; args: SparExpr[]; span?: SourceSpan }
  | { kind: "AssignExpr"; variable: string; value: SparExpr; span?: SourceSpan }
  | { kind: "BlockExpr"; expressions: SparExpr[]; span?: SourceSpan }
  | { kind: "MatchExpr"; target: SparExpr; cases: Array<{ pattern: SparExpr; result: SparExpr }>; span?: SourceSpan }
  | { kind: "LambdaExpr"; params: SparParam[]; returnType?: SparTypeExpr; body: SparExpr; span?: SourceSpan }
  | { kind: "TryPropagateExpr"; inner: SparExpr; span?: SourceSpan } // TokTS Result unwrap postfix '?'
  | { kind: "LinearAllocExpr"; target: SparExpr; stateName: string; span?: SourceSpan }
  | { kind: "LinearTransitionExpr"; resource: string; toState: string; span?: SourceSpan }
  | { kind: "NativeCallExpr"; api: string; args: SparExpr[]; span?: SourceSpan }
  | { kind: "HookExpr"; hookType: "state" | "signal" | "computed" | "inject"; initOrDep: SparExpr; span?: SourceSpan };

export type SparEntity =
  | SparTypeDecl
  | SparFunctionDecl
  | SparComponentDecl
  | SparStyleDecl;

export interface SparModule {
  id: string;
  manifest: Record<string, string | number | boolean>;
  dependencies: SparDependency[];
  entities: SparEntity[];
  rawSource?: string;
}

// Diagnostics contract for Autonomous AI
export type DiagnosticSeverity = "REJECTED" | "VERIFIED" | "WARNING";

export type ErrorPhase =
  | "SYNTACTIC_CONFORMANCE"
  | "TYPE_CALCULUS"
  | "REFINEMENT_VERIFICATION"
  | "TYPESTATE_VERIFICATION"
  | "EFFECT_CONFORMANCE"
  | "LENS_INVERTIBILITY";

export interface DiagnosticViolation {
  code: string;
  message: string;
  context?: Record<string, unknown>;
}

export interface DiagnosticEntry {
  status: DiagnosticSeverity;
  error_phase: ErrorPhase;
  span: SourceSpan;
  violation: DiagnosticViolation;
  invariant_correction_rule?: string;
  fix?: string;
}

export interface StaticAnalysisReport {
  status: DiagnosticSeverity;
  diagnostics: DiagnosticEntry[];
  typestateTransitions: Array<{
    resource: string;
    from: string;
    to: string;
    line: number;
    valid: boolean;
  }>;
  refinementChecks: Array<{
    symbol: string;
    predicate: string;
    verified: boolean;
    sampleValue?: string | number;
  }>;
  algebraicEffects: Array<{
    fnName: string;
    declaredEffects: EffectKind[];
    incurredEffects: EffectKind[];
    valid: boolean;
  }>;
}

export type TargetLanguage = 
  | "react-tailwind"
  | "angular-signals"
  | "threejs-webgl"
  | "phaser-2d"
  | "capacitor-mobile"
  | "node-native"
  | "html" | "htm" | "js" | "mjs" | "cjs" | "ts" | "jsx" | "tsx" | "wasm" | "wat"
  | "css" | "scss" | "sass" | "less" | "styl" | "pcss"
  | "vue" | "svelte" | "astro" | "ejs" | "hbs" | "handlebars" | "pug" | "twig" | "blade"
  | "php" | "py" | "rb" | "go" | "cs" | "java" | "rs"
  | "json" | "jsonld" | "graphql" | "gql" | "xml" | "yaml" | "yml"
  | string;
