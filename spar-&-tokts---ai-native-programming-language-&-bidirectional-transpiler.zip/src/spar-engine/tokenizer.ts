/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SPAR Lexical Tokenizer with Exact Source Coordinate Mapping
 */

export type TokenType =
  | "LPAREN"       // (
  | "RPAREN"       // )
  | "LANGLE"       // <
  | "RANGLE"       // >
  | "LBRACKET"     // [
  | "RBRACKET"     // ]
  | "LBRACE"       // {
  | "RBRACE"       // }
  | "MODULE_TAG"   // (@module
  | "MANIFEST_BEG" // (*
  | "MANIFEST_END" // *)
  | "ATTR_BEG"     // (.
  | "ATTR_END"     // .)
  | "STYLE_BEG"    // (+
  | "STYLE_END"    // +)
  | "TYPE_DECL"    // (:
  | "FN_DECL"      // (!
  | "COMP_DECL"    // (#
  | "STYLE_DECL"   // (&
  | "COND_DECL"    // (?
  | "ASSIGN_OP"    // (:= or :=
  | "ARROW"        // ->
  | "TYPESTATE_OP" // (~
  | "EFFECT_OP"    // (!^
  | "VAL_OP"       // (!val
  | "MATCH_OP"     // (==
  | "STR_TAG"      // !str
  | "TRY_OP"       // ? postfix or operator
  | "SYMBOL"       // identifiers, primitives (!i, !s, !b, etc.)
  | "STRING"       // "..."
  | "NUMBER"       // 123, 3.14, 0x00ff00
  | "BOOLEAN"      // true, false
  | "EOF";

export interface Token {
  type: TokenType;
  value: string;
  line: number;
  col: number;
  offset: number;
}

export function tokenizeSpar(source: string): Token[] {
  const tokens: Token[] = [];
  let pos = 0;
  let line = 1;
  let col = 1;

  function advance(count = 1) {
    for (let i = 0; i < count; i++) {
      if (source[pos + i] === "\n") {
        line++;
        col = 1;
      } else {
        col++;
      }
    }
    pos += count;
  }

  while (pos < source.length) {
    const ch = source[pos];

    // Whitespace
    if (ch === " " || ch === "\t" || ch === "\r") {
      advance(1);
      continue;
    }
    if (ch === "\n") {
      advance(1);
      continue;
    }

    // Comments ;; or //
    if ((ch === ";" && source[pos + 1] === ";") || (ch === "/" && source[pos + 1] === "/")) {
      while (pos < source.length && source[pos] !== "\n") {
        advance(1);
      }
      continue;
    }

    const curLine = line;
    const curCol = col;
    const curOffset = pos;

    // Multi-char prefix tags
    if (source.startsWith("(@module", pos)) {
      tokens.push({ type: "MODULE_TAG", value: "(@module", line: curLine, col: curCol, offset: curOffset });
      advance(8);
      continue;
    }
    if (source.startsWith("(*", pos)) {
      tokens.push({ type: "MANIFEST_BEG", value: "(*", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("*)", pos)) {
      tokens.push({ type: "MANIFEST_END", value: "*)", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(.", pos)) {
      tokens.push({ type: "ATTR_BEG", value: "(.", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith(".)", pos)) {
      tokens.push({ type: "ATTR_END", value: ".)", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(+", pos)) {
      tokens.push({ type: "STYLE_BEG", value: "(+", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("+)", pos)) {
      tokens.push({ type: "STYLE_END", value: "+)", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(:=", pos)) {
      tokens.push({ type: "ASSIGN_OP", value: "(:=", line: curLine, col: curCol, offset: curOffset });
      advance(3);
      continue;
    }
    if (source.startsWith("(:", pos)) {
      tokens.push({ type: "TYPE_DECL", value: "(:", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(!val", pos)) {
      tokens.push({ type: "VAL_OP", value: "(!val", line: curLine, col: curCol, offset: curOffset });
      advance(5);
      continue;
    }
    if (source.startsWith("(!^", pos)) {
      tokens.push({ type: "EFFECT_OP", value: "(!^", line: curLine, col: curCol, offset: curOffset });
      advance(3);
      continue;
    }
    if (source.startsWith("(!", pos)) {
      tokens.push({ type: "FN_DECL", value: "(!", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(#", pos)) {
      tokens.push({ type: "COMP_DECL", value: "(#", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(&", pos)) {
      tokens.push({ type: "STYLE_DECL", value: "(&", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(~", pos)) {
      tokens.push({ type: "TYPESTATE_OP", value: "(~", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("(==", pos)) {
      tokens.push({ type: "MATCH_OP", value: "(==", line: curLine, col: curCol, offset: curOffset });
      advance(3);
      continue;
    }
    if (source.startsWith("(?:", pos)) {
      // Refinement type declaration
      tokens.push({ type: "LPAREN", value: "(", line: curLine, col: curCol, offset: curOffset });
      tokens.push({ type: "SYMBOL", value: "?:", line: curLine, col: curCol + 1, offset: curOffset + 1 });
      advance(3);
      continue;
    }
    if (source.startsWith("(? ", pos) || source.startsWith("(?\n", pos) || source.startsWith("(?\t", pos)) {
      tokens.push({ type: "COND_DECL", value: "(?", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("->", pos)) {
      tokens.push({ type: "ARROW", value: "->", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith(":=", pos)) {
      tokens.push({ type: "ASSIGN_OP", value: ":=", line: curLine, col: curCol, offset: curOffset });
      advance(2);
      continue;
    }
    if (source.startsWith("!str", pos)) {
      tokens.push({ type: "STR_TAG", value: "!str", line: curLine, col: curCol, offset: curOffset });
      advance(4);
      continue;
    }

    // String literals
    if (ch === '"' || ch === "'") {
      const quote = ch;
      let strVal = "";
      advance(1); // skip quote
      while (pos < source.length && source[pos] !== quote) {
        if (source[pos] === "\\" && pos + 1 < source.length) {
          strVal += source[pos + 1];
          advance(2);
        } else {
          strVal += source[pos];
          advance(1);
        }
      }
      if (pos < source.length) {
        advance(1); // skip closing quote
      }
      tokens.push({ type: "STRING", value: strVal, line: curLine, col: curCol, offset: curOffset });
      continue;
    }

    // Numbers (hex, float, int)
    if (/[0-9]/.test(ch) || (ch === "-" && /[0-9]/.test(source[pos + 1] || ""))) {
      let numStr = "";
      if (source.startsWith("0x", pos) || source.startsWith("0X", pos)) {
        numStr += source.slice(pos, pos + 2);
        advance(2);
        while (pos < source.length && /[0-9a-fA-F]/.test(source[pos])) {
          numStr += source[pos];
          advance(1);
        }
      } else {
        while (pos < source.length && /[0-9.\-_]/.test(source[pos])) {
          numStr += source[pos];
          advance(1);
        }
      }
      tokens.push({ type: "NUMBER", value: numStr, line: curLine, col: curCol, offset: curOffset });
      continue;
    }

    // Single character delimiters
    if (ch === "(") {
      tokens.push({ type: "LPAREN", value: "(", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === ")") {
      tokens.push({ type: "RPAREN", value: ")", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === "<") {
      tokens.push({ type: "LANGLE", value: "<", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === ">") {
      tokens.push({ type: "RANGLE", value: ">", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === "[") {
      tokens.push({ type: "LBRACKET", value: "[", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === "]") {
      tokens.push({ type: "RBRACKET", value: "]", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === "{") {
      tokens.push({ type: "LBRACE", value: "{", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === "}") {
      tokens.push({ type: "RBRACE", value: "}", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }
    if (ch === "?") {
      tokens.push({ type: "TRY_OP", value: "?", line: curLine, col: curCol, offset: curOffset });
      advance(1);
      continue;
    }

    // Symbols / Identifiers (including !i, !s, !b, %, |, :, on:click, class, math operators)
    let sym = "";
    while (
      pos < source.length &&
      !/[\s\(\)\[\]\{\}<>;"']/.test(source[pos])
    ) {
      sym += source[pos];
      advance(1);
    }

    if (sym.length > 0) {
      if (sym === "true" || sym === "false") {
        tokens.push({ type: "BOOLEAN", value: sym, line: curLine, col: curCol, offset: curOffset });
      } else {
        tokens.push({ type: "SYMBOL", value: sym, line: curLine, col: curCol, offset: curOffset });
      }
      continue;
    }

    // Fallback single character
    advance(1);
  }

  tokens.push({ type: "EOF", value: "", line, col, offset: pos });
  return tokens;
}
