/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from "react";
import { Header } from "./components/Header.tsx";
import { CodeEditorPane } from "./components/CodeEditorPane.tsx";
import { WorkspaceExplorer } from "./components/WorkspaceExplorer.tsx";
import { AiDocumentationModal } from "./components/AiDocumentationModal.tsx";
import { TokenomicsPanel } from "./components/TokenomicsPanel.tsx";
import { VerificationPanel } from "./components/VerificationPanel.tsx";
import { DiagnosticsPanel } from "./components/DiagnosticsPanel.tsx";
import { LensVerifierPanel } from "./components/LensVerifierPanel.tsx";
import { LiveSandbox } from "./components/LiveSandbox.tsx";
import { PRESETS, PresetItem } from "./spar-engine/presets.ts";
import { TargetLanguage } from "./spar-engine/types.ts";
import { BidirectionalLensEngine } from "./spar-engine/lens.ts";
import { compareTokenomics } from "./spar-engine/tokenomics.ts";
import { WorkspaceEngine, VirtualFile } from "./spar-engine/workspace.ts";
import { 
  Zap, 
  ShieldCheck, 
  Bug, 
  Scale, 
  Play, 
  FolderTree, 
  ArrowRightLeft,
  FileCode,
  Download,
  Upload
} from "lucide-react";

export default function App() {
  const [selectedPresetId, setSelectedPresetId] = useState<string>("workspace-polyglot-web");
  const [direction, setDirection] = useState<"spar-to-target" | "target-to-spar">("spar-to-target");
  const [targetLang, setTargetLang] = useState<string>("vue");

  // Code buffers
  const [sparCode, setSparCode] = useState<string>(PRESETS[0].sparCode);
  const [targetCode, setTargetCode] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"tokenomics" | "verification" | "diagnostics" | "lens" | "sandbox">("tokenomics");
  const [highlightedLine, setHighlightedLine] = useState<number | undefined>(undefined);

  // Multi-File Workspace State
  const [activeFilePath, setActiveFilePath] = useState<string>("src/components/Counter.vue");
  const [showExplorer, setShowExplorer] = useState<boolean>(true);
  const [isAiDocsOpen, setIsAiDocsOpen] = useState<boolean>(false);

  // Workspace file tree projection
  const workspaceFiles: VirtualFile[] = useMemo(() => {
    return WorkspaceEngine.putWorkspace(sparCode, targetLang);
  }, [sparCode, targetLang]);

  // Keep active file valid
  useEffect(() => {
    if (workspaceFiles.length > 0 && !workspaceFiles.some(f => f.path === activeFilePath)) {
      const sourceFile = workspaceFiles.find(f => f.path.startsWith("src/") || f.path.startsWith("server/")) || workspaceFiles[0];
      if (sourceFile) {
        setActiveFilePath(sourceFile.path);
        if (sourceFile.targetLang) {
          setTargetLang(sourceFile.targetLang);
        }
      }
    }
  }, [workspaceFiles, activeFilePath]);

  // Handle file click in sidebar with auto-target detection
  const handleSelectFile = (path: string) => {
    setActiveFilePath(path);
    const file = workspaceFiles.find(f => f.path === path);
    if (file && file.targetLang) {
      setTargetLang(file.targetLang);
    }
  };

  // Update targetCode when active file changes or in single module mode
  useEffect(() => {
    if (direction === "spar-to-target") {
      const currentFile = workspaceFiles.find(f => f.path === activeFilePath);
      if (currentFile) {
        setTargetCode(currentFile.content);
      } else {
        const result = BidirectionalLensEngine.put(sparCode, targetLang);
        setTargetCode(result.code);
      }
    }
  }, [sparCode, targetLang, direction, activeFilePath, workspaceFiles]);

  // Decompile when TargetCode changes in target-to-spar mode
  const handleTargetCodeChange = (newTargetCode: string) => {
    setTargetCode(newTargetCode);
    if (direction === "target-to-spar") {
      const recoveredSpar = BidirectionalLensEngine.get(newTargetCode);
      setSparCode(recoveredSpar);
    }
  };

  // Compile result & static report
  const transpileResult = useMemo(() => {
    return BidirectionalLensEngine.put(sparCode, targetLang);
  }, [sparCode, targetLang]);

  // Tokenomics metrics
  const tokenomics = useMemo(() => {
    return compareTokenomics(sparCode, targetCode || transpileResult.code);
  }, [sparCode, targetCode, transpileResult.code]);

  // Lens Laws verification
  const lensResult = useMemo(() => {
    return BidirectionalLensEngine.verifyLensLaws(sparCode, targetLang);
  }, [sparCode, targetLang]);

  const handleSelectPreset = (preset: PresetItem) => {
    setSelectedPresetId(preset.id);
    setTargetLang(preset.target);
    setSparCode(preset.sparCode);
    setHighlightedLine(undefined);

    if (preset.id === "typestate-violation-diagnostic") {
      setActiveTab("diagnostics");
    }
  };

  const handleToggleDirection = () => {
    if (direction === "spar-to-target") {
      setDirection("target-to-spar");
    } else {
      setDirection("spar-to-target");
      const currentFile = workspaceFiles.find(f => f.path === activeFilePath);
      setTargetCode(currentFile ? currentFile.content : transpileResult.code);
    }
  };

  const handleReset = () => {
    const current = PRESETS.find(p => p.id === selectedPresetId) || PRESETS[0];
    handleSelectPreset(current);
  };

  // Autonomous Quick-Fix Handler
  const handleApplyFix = (_fix: string, line: number) => {
    setHighlightedLine(line);

    if (selectedPresetId === "typestate-violation-diagnostic") {
      const fixedCode = sparCode.replace(
        `;; Premature disposal before rendering call!\n      (!dispose geom)\n\n`,
        `// Linear typestate invariant preserved: geom retained for rendering\n`
      );
      setSparCode(fixedCode);
    } else {
      const lines = sparCode.split("\n");
      if (line > 0 && line <= lines.length) {
        lines[line - 1] = `;; [Auto-Fixed] ${lines[line - 1]}`;
        setSparCode(lines.join("\n"));
      }
    }
  };

  // Export full workspace to ZIP
  const handleExportZip = async () => {
    const blob = await WorkspaceEngine.exportToZip(workspaceFiles, `${selectedPresetId}.zip`);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${selectedPresetId}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Import folder / ZIP and decompile to SPAR @workspace
  const handleImportZip = async (file: File) => {
    try {
      const imported = await WorkspaceEngine.importFromZip(file);
      if (imported.length > 0) {
        const decompiledWs = WorkspaceEngine.getWorkspace(imported, file.name.replace(/\.[^/.]+$/, ""), targetLang);
        setSparCode(decompiledWs);
        setSelectedPresetId("custom-imported-workspace");
        alert(`Successfully ingested ${imported.length} files from '${file.name}' and decompiled to unified SPAR workspace!`);
      }
    } catch (err: any) {
      alert(`Failed to import ZIP: ${err.message || String(err)}`);
    }
  };

  // Add new file to workspace
  const handleAddNewFile = (path: string) => {
    const newFileBlock = `\n  (@file "${path}"\n    (@module ${path.replace(/[^a-zA-Z0-9]/g, "_")}\n      (: NewType (% id !s))\n      (! sampleFn (-> () !void) (console.log "Hello"))\n    )\n  )`;
    if (sparCode.includes("(@workspace")) {
      const updated = sparCode.replace(/\)$/, `${newFileBlock}\n)`);
      setSparCode(updated);
    } else {
      setSparCode(`(@workspace "my-app"\n  (@file "${path}"\n${sparCode}\n  )\n)`);
    }
    setActiveFilePath(path);
  };

  const tokenSavingsPercent = Math.round(tokenomics.compressionRatio * 100);
  const verificationPassed = transpileResult.report.status === "VERIFIED";

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-900 selection:text-white">
      {/* Top Application Header */}
      <Header
        currentPreset={selectedPresetId}
        onSelectPreset={handleSelectPreset}
        direction={direction}
        onToggleDirection={handleToggleDirection}
        targetLang={targetLang}
        onSelectTarget={setTargetLang}
        tokenSavingsPercent={tokenSavingsPercent}
        tokensSaved={tokenomics.tokenSavings}
        verificationPassed={verificationPassed}
        onReset={handleReset}
        onOpenAiDocs={() => setIsAiDocsOpen(true)}
      />

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-5">
        {/* Workspace Toolbar Banner */}
        <div className="flex items-center justify-between p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 text-xs flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowExplorer(!showExplorer)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-xs font-medium transition ${
                showExplorer
                  ? "bg-slate-800 border-slate-700 text-cyan-300"
                  : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
              }`}
              title="Toggle Project Files Tree"
            >
              <FolderTree className="w-3.5 h-3.5 text-cyan-400" />
              <span>Project Files ({workspaceFiles.length})</span>
            </button>

            <div className="hidden sm:flex items-center gap-2">
              <span className="font-semibold text-white">Active Archetype:</span>
              <span className="text-cyan-400 font-medium">
                {PRESETS.find(p => p.id === selectedPresetId)?.title || "Custom Workspace"}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportZip}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-indigo-600/80 hover:bg-indigo-500 text-white rounded-lg font-medium transition text-[11px]"
              title="Download entire project as ZIP"
            >
              <Download className="w-3 h-3" />
              <span>Download ZIP</span>
            </button>

            <div className="flex items-center gap-1.5 text-slate-400 font-mono text-[11px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
              <ArrowRightLeft className="w-3 h-3 text-indigo-400" />
              <span>
                {direction === "spar-to-target" ? "Put: S-Expr → Multi-File" : "Get: Multi-File → S-Expr"}
              </span>
            </div>
          </div>
        </div>

        {/* Multi-File Explorer & Dual-Pane Code Studio */}
        <div className="flex gap-4 h-[470px]">
          {/* File Tree Explorer (Collapsible) */}
          {showExplorer && (
            <WorkspaceExplorer
              files={workspaceFiles}
              activeFile={activeFilePath}
              onSelectFile={handleSelectFile}
              onExportZip={handleExportZip}
              onImportZip={handleImportZip}
              onAddNewFile={handleAddNewFile}
              workspaceName={selectedPresetId}
            />
          )}

          {/* Left Pane: SPAR Editor (or Target if direction reversed) */}
          <div className="flex-1 min-w-0">
            {direction === "spar-to-target" ? (
              <CodeEditorPane
                title="SPAR S-Expression Specification (Universal AST)"
                badge="IR Space"
                badgeColor="bg-cyan-950 text-cyan-300 border-cyan-800"
                code={sparCode}
                onChange={setSparCode}
                readOnly={false}
                diagnostics={transpileResult.report.diagnostics}
                tokenCount={tokenomics.spar.tokenCount}
                tokensPerLine={tokenomics.spar.tokensPerLine}
                highlightedLine={highlightedLine}
              />
            ) : (
              <CodeEditorPane
                title={`Target File: ${activeFilePath}`}
                badge="Concrete Input"
                badgeColor="bg-indigo-950 text-indigo-300 border-indigo-800"
                code={targetCode}
                onChange={handleTargetCodeChange}
                readOnly={false}
                tokenCount={tokenomics.target.tokenCount}
                tokensPerLine={tokenomics.target.tokensPerLine}
              />
            )}
          </div>

          {/* Right Pane: Synthesized Target (or Decompiled SPAR if direction reversed) */}
          <div className="flex-1 min-w-0">
            {direction === "spar-to-target" ? (
              <CodeEditorPane
                title={`Synthesized: ${activeFilePath} (${targetLang})`}
                badge="Put: Concrete Target"
                badgeColor="bg-indigo-950 text-indigo-300 border-indigo-800"
                code={targetCode || transpileResult.code}
                readOnly={true}
                tokenCount={tokenomics.target.tokenCount}
                tokensPerLine={tokenomics.target.tokensPerLine}
              />
            ) : (
              <CodeEditorPane
                title="Decompiled SPAR (Universal AST)"
                badge="Get: Abstract Output"
                badgeColor="bg-cyan-950 text-cyan-300 border-cyan-800"
                code={sparCode}
                readOnly={true}
                diagnostics={transpileResult.report.diagnostics}
                tokenCount={tokenomics.spar.tokenCount}
                tokensPerLine={tokenomics.spar.tokensPerLine}
              />
            )}
          </div>
        </div>

        {/* Tabbed Analysis & Execution Workbench */}
        <div className="space-y-4 pt-1">
          {/* Tabs Navigation Bar */}
          <div className="flex items-center gap-1 border-b border-slate-800 pb-2 overflow-x-auto">
            <button
              onClick={() => setActiveTab("tokenomics")}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition shrink-0 ${
                activeTab === "tokenomics"
                  ? "bg-slate-800 text-cyan-400 border border-slate-700 shadow"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>Tokenomics &amp; BPE Entropy</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800">
                -{tokenSavingsPercent}%
              </span>
            </button>

            <button
              onClick={() => setActiveTab("verification")}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition shrink-0 ${
                activeTab === "verification"
                  ? "bg-slate-800 text-cyan-400 border border-slate-700 shadow"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Type Calculus &amp; Typestates</span>
              {verificationPassed ? (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800">
                  Verified
                </span>
              ) : (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-950 text-rose-400 border border-rose-800">
                  Violation
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab("diagnostics")}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition shrink-0 ${
                activeTab === "diagnostics"
                  ? "bg-slate-800 text-cyan-400 border border-slate-700 shadow"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Bug className="w-4 h-4 text-rose-400" />
              <span>Autonomous AI Diagnostics</span>
              {transpileResult.report.diagnostics.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-950 text-rose-400 border border-rose-800 font-mono">
                  {transpileResult.report.diagnostics.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab("lens")}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition shrink-0 ${
                activeTab === "lens"
                  ? "bg-slate-800 text-cyan-400 border border-slate-700 shadow"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Scale className="w-4 h-4 text-indigo-400" />
              <span>Bidirectional Lens Prover</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 font-mono">
                {lensResult.isomorphismScore}%
              </span>
            </button>

            <button
              onClick={() => setActiveTab("sandbox")}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition shrink-0 ${
                activeTab === "sandbox"
                  ? "bg-slate-800 text-cyan-400 border border-slate-700 shadow"
                  : "text-slate-400 hover:text-white hover:bg-slate-900"
              }`}
            >
              <Play className="w-4 h-4 text-emerald-400" />
              <span>Live Sandboxed Execution</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">
                Canvas / WebGL
              </span>
            </button>
          </div>

          {/* Active Tab Content Area */}
          <div className="pt-2">
            {activeTab === "tokenomics" && <TokenomicsPanel tokenomics={tokenomics} />}
            {activeTab === "verification" && <VerificationPanel report={transpileResult.report} />}
            {activeTab === "diagnostics" && (
              <DiagnosticsPanel
                diagnostics={transpileResult.report.diagnostics}
                onApplyFix={handleApplyFix}
              />
            )}
            {activeTab === "lens" && (
              <LensVerifierPanel
                lensResult={lensResult}
                onRerun={() => {}}
              />
            )}
            {activeTab === "sandbox" && (
              <LiveSandbox
                target={targetLang}
                sparCode={sparCode}
              />
            )}
          </div>
        </div>
      </main>

      {/* Footer Specs & Invariants */}
      <footer className="mt-auto bg-slate-900 border-t border-slate-800 py-3 px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-slate-400 font-medium">Standards Compliance:</span>
            <span>SentencePiece Unigram (256k)</span>
            <span>·</span>
            <span>Linear Typestate Calculus</span>
            <span>·</span>
            <span>Bidirectional Lens Laws</span>
            <span>·</span>
            <span>Multi-File Workspace VFS</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsAiDocsOpen(true)}
              className="text-cyan-400 hover:underline"
            >
              AI_GRAMMAR_SPEC.md
            </button>
            <span>·</span>
            <span>Targets: React 19 · Angular 19 · Three.js · Phaser · Capacitor · Node</span>
          </div>
        </div>
      </footer>

      {/* In-App AI Documentation & System Instructions Modal */}
      <AiDocumentationModal
        isOpen={isAiDocsOpen}
        onClose={() => setIsAiDocsOpen(false)}
      />
    </div>
  );
}
