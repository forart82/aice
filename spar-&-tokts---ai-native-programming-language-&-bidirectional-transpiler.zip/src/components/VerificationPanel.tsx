/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { StaticAnalysisReport } from "../spar-engine/types.ts";
import { ShieldCheck, ArrowRight, CheckCircle2, AlertTriangle, Layers, Activity, Sliders } from "lucide-react";

interface VerificationPanelProps {
  report: StaticAnalysisReport;
}

export function VerificationPanel({ report }: VerificationPanelProps) {
  return (
    <div className="space-y-6">
      {/* Overview Status Banner */}
      <div className={`p-4 rounded-xl border flex items-center justify-between ${
        report.status === "VERIFIED"
          ? "bg-cyan-950/40 border-cyan-800 text-cyan-200"
          : "bg-rose-950/40 border-rose-800 text-rose-200"
      }`}>
        <div className="flex items-center gap-3">
          {report.status === "VERIFIED" ? (
            <div className="w-9 h-9 rounded-lg bg-cyan-900/60 flex items-center justify-center text-cyan-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
          ) : (
            <div className="w-9 h-9 rounded-lg bg-rose-900/60 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
          )}
          <div>
            <h4 className="text-sm font-bold text-white">
              {report.status === "VERIFIED"
                ? "All Static Type Invariants Discharged & Verified"
                : "Static Invariant Violations Detected"}
            </h4>
            <p className="text-xs text-slate-300">
              {report.status === "VERIFIED"
                ? "Linear typestates, refinement constraints, and algebraic effects conform to formal invariants."
                : "Type checker caught safety violations before code synthesis."}
            </p>
          </div>
        </div>

        <span className={`text-xs px-2.5 py-1 rounded-full font-mono font-bold ${
          report.status === "VERIFIED" ? "bg-cyan-900 text-cyan-300 border border-cyan-700" : "bg-rose-900 text-rose-300 border border-rose-700"
        }`}>
          {report.status}
        </span>
      </div>

      {/* Grid: Typestates & Refinements */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Linear Typestate Tracking */}
        <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              Linear Typestate Automata (GPU / WebSockets / Native)
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Linear progression</span>
          </div>

          <p className="text-xs text-slate-400">
            Enforces strict linear lifecycles: resources transition through discrete states, prohibiting use-after-free and memory leaks.
          </p>

          {report.typestateTransitions.length === 0 ? (
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800/80 text-xs text-slate-500 italic text-center">
              No stateful mutable resources declared in this module.
            </div>
          ) : (
            <div className="space-y-2.5">
              {report.typestateTransitions.map((t, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-cyan-300">{t.resource}</span>
                    <span className="text-slate-500">line {t.line}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[11px]">
                      {t.from}
                    </span>
                    <ArrowRight className="w-3 h-3 text-slate-500" />
                    <span className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                      t.to === "Disposed" ? "bg-purple-950 text-purple-300 border border-purple-800" : "bg-cyan-950 text-cyan-300 border border-cyan-800"
                    }`}>
                      {t.to}
                    </span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-1" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Refinement Type Solver */}
        <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-400" />
              Refinement Types &amp; Presburger Bounds
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Compile-time solver</span>
          </div>

          <p className="text-xs text-slate-400">
            Discharges first-order arithmetic predicates at compile time, eliminating out-of-bounds errors before runtime.
          </p>

          {report.refinementChecks.length === 0 ? (
            <div className="p-4 rounded-lg bg-slate-950 border border-slate-800/80 text-xs text-slate-500 italic text-center">
              No refinement types declared in this module.
            </div>
          ) : (
            <div className="space-y-2.5">
              {report.refinementChecks.map((r, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-lg bg-slate-950 border border-slate-800 space-y-2 text-xs font-mono"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-emerald-300">{r.symbol}</span>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px]">
                      Satisfiable
                    </span>
                  </div>
                  <div className="text-slate-400 text-[11px] bg-slate-900 p-1.5 rounded border border-slate-800/60">
                    Predicate: <span className="text-cyan-400">{r.predicate}</span>
                  </div>
                  {r.sampleValue !== undefined && (
                    <div className="text-[11px] text-slate-400">
                      Sample witness: <span className="text-amber-400">{r.sampleValue}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Algebraic Effects Matrix */}
      <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-400" />
            Algebraic Effect Boundaries Tracking
          </h3>
          <span className="text-[11px] font-mono text-slate-400">Side-effect calculus</span>
        </div>

        <p className="text-xs text-slate-400">
          Enforces purity: functions must explicitly declare side effects in their signatures (<code className="text-cyan-400">(!^ Type [Effects])</code>) to invoke DOM, GPU, IO, or network operations.
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono text-slate-300">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Function / Component</th>
                <th className="py-2.5 px-3">Declared Effects</th>
                <th className="py-2.5 px-3">Incurred Side Effects</th>
                <th className="py-2.5 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {report.algebraicEffects.map((eff, idx) => (
                <tr key={idx}>
                  <td className="py-2.5 px-3 font-semibold text-cyan-300">{eff.fnName}</td>
                  <td className="py-2.5 px-3">
                    {eff.declaredEffects.length > 0 ? (
                      <div className="flex gap-1 flex-wrap">
                        {eff.declaredEffects.map((e, i) => (
                          <span key={i} className="px-1.5 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 text-[10px]">
                            {e}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-slate-500 italic">Pure (None)</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    {eff.incurredEffects.length > 0 ? (
                      <div className="flex gap-1 flex-wrap">
                        {eff.incurredEffects.map((e, i) => (
                          <span key={i} className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                            {e}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-emerald-400">Pure Computation</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3">
                    {eff.valid ? (
                      <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Valid
                      </span>
                    ) : (
                      <span className="text-rose-400 flex items-center gap-1 font-semibold">
                        <AlertTriangle className="w-3.5 h-3.5" /> Undeclared
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
