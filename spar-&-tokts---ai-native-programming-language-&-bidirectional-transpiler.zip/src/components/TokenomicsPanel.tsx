/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ComparativeTokenomics } from "../spar-engine/tokenomics.ts";
import { Zap, TrendingDown, Maximize2, ShieldAlert, Cpu, Sparkles, CheckCircle } from "lucide-react";

interface TokenomicsPanelProps {
  tokenomics: ComparativeTokenomics;
}

export function TokenomicsPanel({ tokenomics }: TokenomicsPanelProps) {
  const percentSaved = Math.round(tokenomics.compressionRatio * 100);

  return (
    <div className="space-y-6">
      {/* Top Hero Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Token Savings Card */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-emerald-950/60 to-slate-900 border border-emerald-800/80 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-400 tracking-wider uppercase">Token Reduction</span>
            <div className="p-1.5 rounded-lg bg-emerald-900/60 text-emerald-300">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tabular-nums">-{percentSaved}%</span>
            <span className="text-xs text-emerald-400 font-mono">({tokenomics.tokenSavings} tokens)</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            SPAR uses {tokenomics.spar.tokenCount} tokens vs {tokenomics.target.tokenCount} in standard target.
          </p>
        </div>

        {/* Context Window Expansion Card */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-cyan-950/60 to-slate-900 border border-cyan-800/80 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-cyan-400 tracking-wider uppercase">Effective Context</span>
            <div className="p-1.5 rounded-lg bg-cyan-900/60 text-cyan-300">
              <Maximize2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tabular-nums">
              {tokenomics.contextExpansionMultiplier}×
            </span>
            <span className="text-xs text-cyan-400 font-medium">more code per prompt</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Expands model's reasoning window across full-stack repositories.
          </p>
        </div>

        {/* Attention Entropy Reduction */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-950/60 to-slate-900 border border-indigo-800/80 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-indigo-400 tracking-wider uppercase">Entropy Reduction</span>
            <div className="p-1.5 rounded-lg bg-indigo-900/60 text-indigo-300">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tabular-nums">
              {tokenomics.attentionEntropyReduction}%
            </span>
            <span className="text-xs text-indigo-400 font-medium">lower uncertainty</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Univalent syntax eliminates competing stylistic generation paths.
          </p>
        </div>

        {/* Scaffolding Elimination */}
        <div className="p-4 rounded-xl bg-gradient-to-br from-purple-950/60 to-slate-900 border border-purple-800/80 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-purple-400 tracking-wider uppercase">Boilerplate Pruned</span>
            <div className="p-1.5 rounded-lg bg-purple-900/60 text-purple-300">
              <ShieldAlert className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-white tabular-nums">
              {tokenomics.target.syntacticScaffoldingTokens}
            </span>
            <span className="text-xs text-purple-400 font-medium">tokens eliminated</span>
          </div>
          <p className="mt-1 text-xs text-slate-400">
            Closing braces, closing tags, redundant keywords, and delimiters.
          </p>
        </div>
      </div>

      {/* Visual Token Comparison Bar */}
      <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Cpu className="w-4 h-4 text-cyan-400" />
          SentencePiece Tokenizer Allocation (Gemini 256k Vocabulary)
        </h3>

        {/* Target Stack Bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-400">Conventional Web Stack (TS + JSX + CSS)</span>
            <span className="text-slate-300 font-bold">{tokenomics.target.tokenCount} tokens (100% baseline)</span>
          </div>
          <div className="w-full h-5 rounded-lg bg-slate-800 overflow-hidden flex shadow-inner">
            <div
              className="bg-indigo-500 h-full flex items-center justify-center text-[10px] text-white font-mono"
              style={{ width: `${Math.round((tokenomics.target.tokenCount - tokenomics.target.syntacticScaffoldingTokens) / Math.max(1, tokenomics.target.tokenCount) * 100)}%` }}
              title="Semantic Logic Tokens"
            >
              Logic ({tokenomics.target.tokenCount - tokenomics.target.syntacticScaffoldingTokens})
            </div>
            <div
              className="bg-rose-500/80 h-full flex items-center justify-center text-[10px] text-white font-mono"
              style={{ width: `${Math.round(tokenomics.target.syntacticScaffoldingTokens / Math.max(1, tokenomics.target.tokenCount) * 100)}%` }}
              title="Syntactic Scaffolding & Delimiters"
            >
              Scaffolding ({tokenomics.target.syntacticScaffoldingTokens})
            </div>
          </div>
        </div>

        {/* SPAR Compressed Stack Bar */}
        <div className="space-y-1.5 pt-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-cyan-400 font-semibold">SPAR Dense S-Expression Tree</span>
            <span className="text-emerald-400 font-bold">
              {tokenomics.spar.tokenCount} tokens ({Math.round((tokenomics.spar.tokenCount / Math.max(1, tokenomics.target.tokenCount)) * 100)}% of baseline)
            </span>
          </div>
          <div className="w-full h-5 rounded-lg bg-slate-800 overflow-hidden flex shadow-inner">
            <div
              className="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full flex items-center justify-center text-[10px] text-slate-950 font-bold font-mono"
              style={{ width: `${Math.min(100, Math.round((tokenomics.spar.tokenCount / Math.max(1, tokenomics.target.tokenCount)) * 100))}%` }}
            >
              SPAR Logic ({tokenomics.spar.tokenCount})
            </div>
          </div>
        </div>
      </div>

      {/* Deep Theoretical Grounding Comparison Table */}
      <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl">
        <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          Empirical Tokenomics Comparison Across Structural Metrics
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono text-slate-300">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Metric</th>
                <th className="py-2.5 px-3">Conventional Full-Stack</th>
                <th className="py-2.5 px-3">SPAR Architecture</th>
                <th className="py-2.5 px-3 text-emerald-400">Optimization Gain</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Token Count</td>
                <td className="py-2.5 px-3 text-slate-400">{tokenomics.target.tokenCount} tokens</td>
                <td className="py-2.5 px-3 text-cyan-300 font-bold">{tokenomics.spar.tokenCount} tokens</td>
                <td className="py-2.5 px-3 text-emerald-400 font-bold">-{percentSaved}% token consumption</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Characters / Bytes</td>
                <td className="py-2.5 px-3 text-slate-400">{tokenomics.target.charCount} chars · {tokenomics.target.byteCount} B</td>
                <td className="py-2.5 px-3 text-cyan-300">{tokenomics.spar.charCount} chars · {tokenomics.spar.byteCount} B</td>
                <td className="py-2.5 px-3 text-emerald-400">Compressed byte density</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Syntactic Scaffolding</td>
                <td className="py-2.5 px-3 text-rose-400">{tokenomics.target.syntacticScaffoldingTokens} tokens (braces, tags)</td>
                <td className="py-2.5 px-3 text-emerald-400">0 redundant tokens</td>
                <td className="py-2.5 px-3 text-emerald-400">100% univalent unigram alignment</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Syntactic Ambiguity</td>
                <td className="py-2.5 px-3 text-amber-400">High (divergent formatting paths)</td>
                <td className="py-2.5 px-3 text-cyan-300">Zero (deterministic S-expressions)</td>
                <td className="py-2.5 px-3 text-emerald-400">Prevents hallucinated closing tags</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-semibold text-white">Type Verification</td>
                <td className="py-2.5 px-3 text-slate-400">Late external 'tsc --noEmit'</td>
                <td className="py-2.5 px-3 text-cyan-300">Linear Typestates + Presburger Bounds</td>
                <td className="py-2.5 px-3 text-emerald-400">Immediate static invariants</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
