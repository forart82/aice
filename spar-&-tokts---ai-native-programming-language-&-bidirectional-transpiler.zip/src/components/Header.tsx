/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  Cpu, 
  ArrowLeftRight, 
  Sparkles, 
  CheckCircle2, 
  Layers, 
  Compass, 
  Zap, 
  RefreshCw,
  FileCode,
  ShieldCheck
} from "lucide-react";
import { TargetLanguage } from "../spar-engine/types.ts";
import { PRESETS, PresetItem } from "../spar-engine/presets.ts";

interface HeaderProps {
  currentPreset: string;
  onSelectPreset: (preset: PresetItem) => void;
  direction: "spar-to-target" | "target-to-spar";
  onToggleDirection: () => void;
  targetLang: string;
  onSelectTarget: (lang: string) => void;
  tokenSavingsPercent: number;
  tokensSaved: number;
  verificationPassed: boolean;
  onReset: () => void;
  onOpenAiDocs: () => void;
}

export function Header({
  currentPreset,
  onSelectPreset,
  direction,
  onToggleDirection,
  targetLang,
  onSelectTarget,
  tokenSavingsPercent,
  tokensSaved,
  verificationPassed,
  onReset,
  onOpenAiDocs
}: HeaderProps) {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 select-none">
      <div className="max-w-7xl mx-auto px-4 py-3 sm:px-6 flex flex-wrap items-center justify-between gap-3">
        {/* Logo and Identity */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 ring-1 ring-cyan-400/30">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
                SPAR <span className="text-xs px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 font-mono">*.XX.spar</span>
              </h1>
              <span className="text-xs text-slate-400 font-medium hidden sm:inline">&amp; Polyglot Web Transpiler</span>
            </div>
            <p className="text-xs text-slate-400 hidden md:block">
              Bidirectional AI Language for 32+ Frontend, Backend, Styles &amp; Template Formats
            </p>
          </div>
        </div>

        {/* Center Controls: Preset Selector & Target Lang */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Preset Selector */}
          <div className="flex items-center bg-slate-800/80 rounded-lg p-1 border border-slate-700/80">
            <Compass className="w-3.5 h-3.5 text-cyan-400 ml-1.5 mr-1" />
            <select
              value={currentPreset}
              onChange={(e) => {
                const found = PRESETS.find(p => p.id === e.target.value);
                if (found) onSelectPreset(found);
              }}
              className="bg-transparent text-xs text-slate-200 font-medium py-1 px-1.5 focus:outline-none cursor-pointer max-w-[210px]"
            >
              <optgroup label="Multi-File Projects (*.XX.spar)">
                <option value="workspace-polyglot-web">Polyglot Web Hub (@workspace)</option>
                <option value="workspace-fullstack-store">React E-Commerce Store</option>
              </optgroup>
              <optgroup label="Components & Templates">
                <option value="vue-sfc-counter">Vue 3 (Counter.vue.spar)</option>
                <option value="svelte-runes-card">Svelte 5 (Card.svelte.spar)</option>
                <option value="react-tailwind-counter">React 19 (App.tsx.spar)</option>
                <option value="angular-signals-card">Angular 19 Signals</option>
              </optgroup>
              <optgroup label="Backend & Server-Side">
                <option value="python-fastapi-service">Python FastAPI (server.py.spar)</option>
                <option value="golang-microservice">Go Net/HTTP (handler.go.spar)</option>
                <option value="rust-axum-service">Rust Axum (service.rs.spar)</option>
                <option value="node-result-algebra">Node 22 Result[T, E]</option>
              </optgroup>
              <optgroup label="Styles & Data APIs">
                <option value="scss-theme-styles">SCSS (theme.scss.spar)</option>
                <option value="graphql-schema-def">GraphQL (schema.graphql.spar)</option>
              </optgroup>
              <optgroup label="Graphics & Mobile">
                <option value="threejs-linear-gpu">Three.js WebGL</option>
                <option value="capacitor-mobile-bridge">Capacitor 8 Mobile</option>
              </optgroup>
              <optgroup label="Diagnostics & AI Self-Repair">
                <option value="typestate-violation-diagnostic">Typestate Violation (E3002)</option>
              </optgroup>
            </select>
          </div>

          {/* Direction Switcher Button */}
          <button
            onClick={onToggleDirection}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition"
            title="Toggle Transpilation Direction (Put vs Get)"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-400" />
            <span className="font-mono text-[11px]">
              {direction === "spar-to-target" ? "SPAR → Target" : "Target → SPAR"}
            </span>
          </button>

          {/* Target Architecture Selector */}
          <div className="flex items-center bg-slate-800/80 rounded-lg p-1 border border-slate-700/80">
            <Layers className="w-3.5 h-3.5 text-indigo-400 ml-1.5 mr-1" />
            <select
              value={targetLang}
              onChange={(e) => onSelectTarget(e.target.value)}
              className="bg-transparent text-xs text-slate-200 font-medium py-1 px-1.5 focus:outline-none cursor-pointer max-w-[190px]"
            >
              <optgroup label="Frontend Core & Scripts">
                <option value="tsx">TypeScript JSX (*.tsx)</option>
                <option value="ts">TypeScript (*.ts)</option>
                <option value="jsx">JavaScript JSX (*.jsx)</option>
                <option value="js">JavaScript (*.js)</option>
                <option value="html">HTML5 Document (*.html)</option>
                <option value="wasm">WebAssembly WAT (*.wasm)</option>
              </optgroup>
              <optgroup label="Single-File Components">
                <option value="vue">Vue 3 SFC (*.vue)</option>
                <option value="svelte">Svelte 5 Runes (*.svelte)</option>
                <option value="astro">Astro Island (*.astro)</option>
                <option value="pug">Pug Template (*.pug)</option>
                <option value="blade">Laravel Blade (*.blade.php)</option>
                <option value="ejs">EJS Template (*.ejs)</option>
                <option value="hbs">Handlebars (*.hbs)</option>
                <option value="twig">Twig Template (*.twig)</option>
              </optgroup>
              <optgroup label="Styles & Preprocessors">
                <option value="css">CSS3 Modern (*.css)</option>
                <option value="scss">Sassy CSS (*.scss)</option>
                <option value="sass">SASS Indented (*.sass)</option>
                <option value="less">LESS Stylesheet (*.less)</option>
                <option value="styl">Stylus (*.styl)</option>
                <option value="pcss">PostCSS (*.pcss)</option>
              </optgroup>
              <optgroup label="Backend & Server-Side">
                <option value="py">Python FastAPI (*.py)</option>
                <option value="go">Go Net/HTTP (*.go)</option>
                <option value="rs">Rust Axum (*.rs)</option>
                <option value="php">PHP 8.x (*.php)</option>
                <option value="rb">Ruby Sinatra (*.rb)</option>
                <option value="cs">C# ASP.NET Core (*.cs)</option>
                <option value="java">Java Spring Boot (*.java)</option>
                <option value="node-native">Node 22 Native (*.ts)</option>
              </optgroup>
              <optgroup label="Web Data, Config & APIs">
                <option value="graphql">GraphQL Schema (*.graphql)</option>
                <option value="json">JSON Data (*.json)</option>
                <option value="jsonld">JSON-LD SEO (*.jsonld)</option>
                <option value="yaml">YAML / OpenAPI (*.yaml)</option>
                <option value="xml">XML Document (*.xml)</option>
              </optgroup>
            </select>
          </div>

          {/* AI Guide & Prompt Button */}
          <button
            onClick={onOpenAiDocs}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-cyan-950 hover:bg-cyan-900 border border-cyan-800 text-xs font-semibold text-cyan-300 transition shadow"
            title="Open AI Prompt & Grammar Specification"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Docs &amp; Prompt</span>
          </button>
        </div>

        {/* Right Status Badges */}
        <div className="flex items-center gap-2">
          {/* Token Reduction Pill */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs font-medium">
            <Zap className="w-3 h-3 text-emerald-400 animate-pulse" />
            <span>-{tokenSavingsPercent}% Tokens</span>
            <span className="text-[10px] text-emerald-400/80 font-mono">({tokensSaved} saved)</span>
          </div>

          {/* Type Invariants Status */}
          <div className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border ${
            verificationPassed
              ? "bg-cyan-950/70 border-cyan-800 text-cyan-300"
              : "bg-rose-950/70 border-rose-800 text-rose-300"
          }`}>
            <ShieldCheck className="w-3 h-3" />
            <span>{verificationPassed ? "Invariants Verified" : "Errors Detected"}</span>
          </div>

          <button
            onClick={onReset}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
            title="Reload default preset"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
}
