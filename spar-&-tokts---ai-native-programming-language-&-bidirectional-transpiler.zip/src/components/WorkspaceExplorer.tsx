/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from "react";
import { 
  Folder, 
  FolderOpen, 
  FileCode, 
  Download, 
  Upload, 
  Plus, 
  FileJson, 
  FileText, 
  Archive,
  Layers,
  Sparkles,
  FolderTree
} from "lucide-react";
import { VirtualFile, WorkspaceEngine } from "../spar-engine/workspace.ts";

interface WorkspaceExplorerProps {
  files: VirtualFile[];
  activeFile: string;
  onSelectFile: (path: string) => void;
  onExportZip: () => void;
  onImportZip: (file: File) => void;
  onAddNewFile: (path: string) => void;
  workspaceName: string;
}

export function WorkspaceExplorer({
  files,
  activeFile,
  onSelectFile,
  onExportZip,
  onImportZip,
  onAddNewFile,
  workspaceName
}: WorkspaceExplorerProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportZip(file);
      e.target.value = "";
    }
  };

  const handleAddPrompt = () => {
    const filename = prompt("Enter new file path (e.g., src/utils/format.ts):", "src/new-module.ts");
    if (filename && filename.trim()) {
      onAddNewFile(filename.trim());
    }
  };

  const getFileIcon = (path: string) => {
    if (path.endsWith(".json")) return <FileJson className="w-3.5 h-3.5 text-amber-400" />;
    if (path.endsWith(".tsx") || path.endsWith(".jsx")) return <FileCode className="w-3.5 h-3.5 text-cyan-400" />;
    if (path.endsWith(".ts")) return <FileCode className="w-3.5 h-3.5 text-indigo-400" />;
    if (path.endsWith(".spar") || path.endsWith(".tok")) return <Sparkles className="w-3.5 h-3.5 text-emerald-400" />;
    return <FileText className="w-3.5 h-3.5 text-slate-400" />;
  };

  return (
    <div className="w-64 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col h-full shadow-xl shrink-0">
      {/* Top Header */}
      <div className="px-3.5 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FolderTree className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold text-white truncate max-w-[120px]">
            {workspaceName}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handleAddPrompt}
            className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition"
            title="Add File"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition"
            title="Import Folder or ZIP"
          >
            <Upload className="w-3.5 h-3.5" />
          </button>

          <input
            ref={fileInputRef}
            type="file"
            accept=".zip"
            onChange={handleFileChange}
            className="hidden"
          />

          <button
            onClick={onExportZip}
            className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition"
            title="Download Workspace as ZIP"
          >
            <Download className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* File Tree List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-0.5 font-mono text-xs">
        <div className="flex items-center gap-1.5 px-2 py-1 text-slate-500 font-semibold text-[11px]">
          <FolderOpen className="w-3.5 h-3.5 text-slate-400" />
          <span>Project Root ({files.length} files)</span>
        </div>

        {files.map((file) => {
          const isSelected = activeFile === file.path;
          return (
            <button
              key={file.path}
              onClick={() => onSelectFile(file.path)}
              className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-left text-xs transition ${
                isSelected
                  ? "bg-cyan-950/70 text-cyan-300 font-medium border border-cyan-800/80"
                  : "text-slate-300 hover:bg-slate-900/80 hover:text-white"
              }`}
            >
              {getFileIcon(file.path)}
              <span className="truncate flex-1">{file.path}</span>
            </button>
          );
        })}
      </div>

      {/* Bottom Batch Actions */}
      <div className="p-2.5 bg-slate-900/70 border-t border-slate-800 flex gap-2">
        <button
          onClick={onExportZip}
          className="flex-1 py-1.5 px-2 bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-[11px] rounded-lg flex items-center justify-center gap-1.5 transition shadow"
        >
          <Archive className="w-3 h-3" />
          <span>Export ZIP</span>
        </button>

        <button
          onClick={() => fileInputRef.current?.click()}
          className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-[11px] rounded-lg flex items-center justify-center gap-1 transition border border-slate-700"
          title="Upload ZIP repository"
        >
          <Upload className="w-3 h-3 text-cyan-400" />
          <span>Import</span>
        </button>
      </div>
    </div>
  );
}
