/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { LensVerificationResult } from "../spar-engine/lens.ts";
import { CheckCircle2, AlertTriangle, ArrowRight, RotateCcw, Scale, ShieldCheck } from "lucide-react";

interface LensVerifierPanelProps {
  lensResult: LensVerificationResult;
  onRerun: () => void;
}

export function LensVerifierPanel({ lensResult, onRerun }: LensVerifierPanelProps) {
  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-950 flex items-center justify-center border border-indigo-800">
            <Scale className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              Bidirectional Lens Invertibility &amp; Isomorphism Proof
              <span className="text-xs px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800 font-mono">
                {lensResult.isomorphismScore}% Fidelity
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Validates asymmetric lens laws to ensure zero semantic entropy loss during bidirectional round trips.
            </p>
          </div>
        </div>

        <button
          onClick={onRerun}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow transition"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Rerun Formal Lens Prover</span>
        </button>
      </div>

      {/* The Two Classical Lens Laws */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* PutGet Law */}
        <div className={`p-4 rounded-xl border space-y-2 ${
          lensResult.putGetSatisfied ? "bg-slate-900/90 border-emerald-800/80" : "bg-slate-900/90 border-amber-800/80"
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-200">
              1. Well-Behavedness (PutGet) Law
            </span>
            {lensResult.putGetSatisfied ? (
              <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" /> Satisfied
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[11px] text-amber-400 font-semibold">
                <AlertTriangle className="w-3.5 h-3.5" /> Trivia Variance
              </span>
            )}
          </div>
          <div className="p-2 rounded bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-400">
            Get(Put(a, c)) = a
          </div>
          <p className="text-xs text-slate-400">
            Synthesizing a SPAR document into target code and immediately decompiling it recovers the original program without information loss.
          </p>
        </div>

        {/* GetPut Law */}
        <div className={`p-4 rounded-xl border space-y-2 ${
          lensResult.getPutSatisfied ? "bg-slate-900/90 border-emerald-800/80" : "bg-slate-900/90 border-amber-800/80"
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-200">
              2. Stability (GetPut) Law
            </span>
            {lensResult.getPutSatisfied ? (
              <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" /> Satisfied
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[11px] text-amber-400 font-semibold">
                <AlertTriangle className="w-3.5 h-3.5" /> Normalized
              </span>
            )}
          </div>
          <div className="p-2 rounded bg-slate-950 border border-slate-800 font-mono text-xs text-cyan-400">
            Put(Get(c), c) = c
          </div>
          <p className="text-xs text-slate-400">
            Decompiling a concrete codebase to SPAR and re-emitting it into concrete files preserves functional and structural behavior identically.
          </p>
        </div>
      </div>

      {/* Execution Pipeline Diagram */}
      <div className="p-5 rounded-xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
        <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
          Lens Transformation Cycle
        </h4>

        <div className="flex items-center justify-between gap-2 p-4 rounded-lg bg-slate-950 border border-slate-800 flex-wrap">
          <div className="text-center px-3 py-2 rounded bg-slate-900 border border-slate-800">
            <span className="text-[10px] text-slate-500 font-mono block">Abstract Space</span>
            <span className="text-xs font-bold text-cyan-300 font-mono">SPAR (a)</span>
          </div>

          <div className="flex items-center gap-1 text-slate-500 text-xs font-mono">
            <ArrowRight className="w-4 h-4 text-indigo-400" />
            <span>Put: Emitter</span>
          </div>

          <div className="text-center px-3 py-2 rounded bg-slate-900 border border-slate-800">
            <span className="text-[10px] text-slate-500 font-mono block">Concrete Space</span>
            <span className="text-xs font-bold text-indigo-300 font-mono">Target Code (c)</span>
          </div>

          <div className="flex items-center gap-1 text-slate-500 text-xs font-mono">
            <ArrowRight className="w-4 h-4 text-emerald-400" />
            <span>Get: Decompile</span>
          </div>

          <div className="text-center px-3 py-2 rounded bg-slate-900 border border-slate-800">
            <span className="text-[10px] text-slate-500 font-mono block">Recovered Space</span>
            <span className="text-xs font-bold text-emerald-300 font-mono">SPAR (a')</span>
          </div>
        </div>

        {/* Audit Notes */}
        <div className="space-y-1.5 pt-2">
          {lensResult.notes.map((note, i) => (
            <div key={i} className="text-xs font-mono text-slate-300 flex items-center gap-2">
              <span>{note}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
