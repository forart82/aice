/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Copy, Check, Code, FileText, AlertCircle } from "lucide-react";
import { DiagnosticEntry } from "../spar-engine/types.ts";

interface CodeEditorPaneProps {
  title: string;
  badge?: string;
  badgeColor?: string;
  code: string;
  onChange?: (val: string) => void;
  readOnly?: boolean;
  diagnostics?: DiagnosticEntry[];
  tokenCount?: number;
  tokensPerLine?: number;
  highlightedLine?: number;
}

export function CodeEditorPane({
  title,
  badge,
  badgeColor = "bg-cyan-900/60 text-cyan-300 border-cyan-800",
  code,
  onChange,
  readOnly = false,
  diagnostics = [],
  tokenCount,
  tokensPerLine,
  highlightedLine
}: CodeEditorPaneProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const lines = code.split("\n");
  const errorLines = new Set(diagnostics.map(d => d.span.line));

  return (
    <div className="flex flex-col h-full bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
      {/* Pane Top Bar */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-slate-900/90 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Code className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-semibold text-slate-200 tracking-wide">{title}</span>
          {badge && (
            <span className={`text-[10px] px-2 py-0.5 rounded-full border font-mono ${badgeColor}`}>
              {badge}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {tokenCount !== undefined && (
            <span className="text-[11px] text-slate-400 font-mono bg-slate-800/80 px-2 py-0.5 rounded border border-slate-700/60">
              <span className="text-cyan-400 font-semibold">{tokenCount}</span> tokens
              {tokensPerLine !== undefined && ` · ${tokensPerLine}/line`}
            </span>
          )}

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 px-2.5 py-1 rounded border border-slate-700/60 transition"
            title="Copy source code"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 text-slate-400" />
                <span>Copy</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Editor Content Area */}
      <div className="relative flex-1 flex overflow-hidden font-mono text-xs leading-relaxed">
        {/* Line Numbers Gutter */}
        <div className="w-12 py-3 bg-slate-900/40 text-slate-600 select-none text-right pr-3 border-r border-slate-800/60 font-mono text-[11px]">
          {lines.map((_, i) => {
            const lineNum = i + 1;
            const hasError = errorLines.has(lineNum);
            const isTargetHighlight = highlightedLine === lineNum;

            return (
              <div
                key={i}
                className={`h-5 leading-5 flex items-center justify-end gap-1 ${
                  hasError ? "text-rose-400 font-bold" : isTargetHighlight ? "text-amber-400 font-semibold" : ""
                }`}
              >
                {hasError && <AlertCircle className="w-2.5 h-2.5 text-rose-500 animate-pulse" />}
                <span>{lineNum}</span>
              </div>
            );
          })}
        </div>

        {/* Text Area / Code Content */}
        {readOnly ? (
          <div className="flex-1 p-3 overflow-auto bg-slate-950 text-slate-200 selection:bg-cyan-900 selection:text-white">
            {lines.map((lineText, i) => {
              const lineNum = i + 1;
              const hasError = errorLines.has(lineNum);
              const isTargetHighlight = highlightedLine === lineNum;

              return (
                <div
                  key={i}
                  className={`h-5 leading-5 px-1 rounded whitespace-pre ${
                    hasError
                      ? "bg-rose-950/40 border-l-2 border-rose-500 text-rose-200"
                      : isTargetHighlight
                      ? "bg-amber-950/30 border-l-2 border-amber-500 text-amber-100"
                      : ""
                  }`}
                >
                  <HighlightedLine text={lineText} />
                </div>
              );
            })}
          </div>
        ) : (
          <textarea
            value={code}
            onChange={(e) => onChange?.(e.target.value)}
            spellCheck={false}
            className="flex-1 p-3 bg-slate-950 text-slate-200 font-mono text-xs resize-none focus:outline-none overflow-auto whitespace-pre selection:bg-cyan-900 selection:text-white"
            placeholder="Type or paste SPAR prefix code here..."
          />
        )}
      </div>

      {/* Editor Bottom Info */}
      <div className="px-3 py-1.5 bg-slate-900/70 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
        <span className="flex items-center gap-1.5">
          <FileText className="w-3 h-3 text-slate-500" />
          <span>{lines.length} lines · {code.length} characters</span>
        </span>
        <span>{readOnly ? "Synthesized Output (Read Only)" : "Interactive SPAR Workspace"}</span>
      </div>
    </div>
  );
}

// Lightweight syntax token styler for SPAR / TS
function HighlightedLine({ text }: { text: string }) {
  if (text.trim().startsWith(";;") || text.trim().startsWith("//") || text.trim().startsWith("/*") || text.trim().startsWith("*")) {
    return <span className="text-slate-500 italic">{text}</span>;
  }

  // Highlight SPAR keywords and markers
  const formatted = text.replace(
    /(\(@module|\(\#|\(\!|\(\:|\(\?|\(~|\(!\^|\(!val|\(:=|\(do|!str|!state|!signal|!computed|!inject|!linearAlloc|!dispose|!nativeCall)/g,
    '<span class="text-cyan-400 font-bold">$1</span>'
  ).replace(
    /(!i|!s|!b|!f|!u|!void|!unknown|!nil)/g,
    '<span class="text-emerald-400 font-semibold">$1</span>'
  ).replace(
    /(import|export|function|const|let|return|type|interface)/g,
    '<span class="text-indigo-400 font-semibold">$1</span>'
  );

  return <span dangerouslySetInnerHTML={{ __html: formatted }} />;
}
