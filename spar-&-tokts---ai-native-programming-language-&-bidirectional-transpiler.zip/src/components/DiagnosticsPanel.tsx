/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { DiagnosticEntry } from "../spar-engine/types.ts";
import { AlertCircle, CheckCircle2, Wrench, Copy, Check, Terminal, Bug } from "lucide-react";

interface DiagnosticsPanelProps {
  diagnostics: DiagnosticEntry[];
  onApplyFix?: (fix: string, line: number) => void;
}

export function DiagnosticsPanel({ diagnostics, onApplyFix }: DiagnosticsPanelProps) {
  const [copied, setCopied] = useState(false);

  const jsonPayload = JSON.stringify(
    diagnostics.length === 0
      ? {
          status: "VERIFIED",
          diagnostics_count: 0,
          invariants_checked: ["SYNTACTIC_CONFORMANCE", "TYPE_CALCULUS", "TYPESTATE_VERIFICATION", "REFINEMENT_BOUNDS", "EFFECT_CONFORMANCE"],
          message: "All invariants hold. No corrections required."
        }
      : diagnostics.map(d => ({
          status: d.status,
          error_phase: d.error_phase,
          span: d.span,
          violation: d.violation,
          invariant_correction_rule: d.invariant_correction_rule,
          candidate_fix: d.fix
        })),
    null,
    2
  );

  const handleCopyJson = () => {
    navigator.clipboard.writeText(jsonPayload);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Bug className="w-4 h-4 text-cyan-400" />
            Deterministic AI Diagnostic Manifest &amp; Self-Correction Telemetry
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Structured machine-readable telemetry designed for autonomous LLM self-healing without conversational ambiguity.
          </p>
        </div>

        <button
          onClick={handleCopyJson}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-slate-200 border border-slate-700 transition shadow"
        >
          {copied ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-emerald-400">JSON Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5 text-slate-400" />
              <span>Copy AI Telemetry JSON</span>
            </>
          )}
        </button>
      </div>

      {/* Diagnostics List Cards */}
      {diagnostics.length === 0 ? (
        <div className="p-6 rounded-xl bg-slate-900/80 border border-emerald-900/60 flex items-center gap-4 text-emerald-300">
          <div className="w-10 h-10 rounded-xl bg-emerald-950 flex items-center justify-center border border-emerald-800">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Zero Invariant Violations</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              The AST satisfies all formal typing rules, linear typestate lifecycles, and algebraic effect boundaries.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          {diagnostics.map((diag, index) => (
            <div
              key={index}
              className="p-4 rounded-xl bg-slate-900/90 border border-rose-900/80 shadow-lg space-y-3"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="p-1.5 rounded-lg bg-rose-950 text-rose-400 border border-rose-800 mt-0.5">
                    <AlertCircle className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-mono font-bold text-rose-400">
                        {diag.violation.code}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                        Phase: {diag.error_phase}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">
                        Line {diag.span.line}:{diag.span.col}
                      </span>
                    </div>
                    <p className="text-xs font-medium text-white mt-1">
                      {diag.violation.message}
                    </p>
                  </div>
                </div>

                {diag.fix && onApplyFix && (
                  <button
                    onClick={() => onApplyFix(diag.fix!, diag.span.line)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md transition shrink-0"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Apply Autonomous Fix</span>
                  </button>
                )}
              </div>

              {/* Invariant correction rule */}
              {diag.invariant_correction_rule && (
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
                  <span className="text-slate-500 font-semibold block text-[10px] uppercase tracking-wider mb-0.5">
                    Invariant Self-Correction Directive
                  </span>
                  <span className="text-cyan-300">{diag.invariant_correction_rule}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Raw JSON Telemetry Terminal */}
      <div className="rounded-xl bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl">
        <div className="px-4 py-2 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-mono font-semibold text-slate-300">
              gemini-diagnostic-telemetry.json
            </span>
          </div>
          <span className="text-[10px] font-mono text-slate-500">RFC-SPAR-784 Compliance</span>
        </div>
        <pre className="p-4 text-xs font-mono text-cyan-300 overflow-x-auto max-h-72 leading-relaxed selection:bg-cyan-900">
          {jsonPayload}
        </pre>
      </div>
    </div>
  );
}
