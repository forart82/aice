/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { X, Copy, Check, BookOpen, Bot, Terminal, Code2, Sparkles } from "lucide-react";

interface AiDocumentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AiDocumentationModal({ isOpen, onClose }: AiDocumentationModalProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<"prompt" | "cheat-sheet" | "diagnostic" | "usage">("prompt");

  if (!isOpen) return null;

  const rawAiPrompt = `# AI Model System Prompt: SPAR (Semantic Polyglot AI Representation)

You are an autonomous compiler and software synthesis engine operating via SPAR.
Rather than emitting verbose human boilerplate (closing tags, brackets, semicolons, redundant types),
you reason and output code using SPAR's univalent prefix S-expression AST.

### CORE GRAMMAR MNEMONICS:
- Modules: (@module <id> (* manifest *) (deps (("mod" sym1 sym2))) ...)
- Types: (: <Name> <TypeExpr>)
- Refinements: (: Port (?: p !i (and (>= p 1) (<= p 65535))))
- Typestates: (: SocketState (~ Open -> Closed))
- Algebraic Effects: (!^ <ReturnType> [<Effects>])  ;; e.g. [IO GPU DOM State Native]
- Fallible Results: Result[T, E] with postfix '?' unwrap operator
- Pure Functions: (! <name> (-> (<params>) <ReturnType>) <body>)
- Components: (# <Name> (% <props>) <LayoutNode>)
- Layout Nodes: (< tag (. attr val .) children... >)  ;; NO CLOSING TAGS
- Dynamic Text: (!val expr) or !str "literal"
- Reactive State: (:= [val setVal] (!state 0))
- Dynamic Matching: (== target (case pat result)+)

### NEGATIVE CONSTRAINTS:
1. NEVER emit closing HTML/XML tags (</div>, </Component>).
2. NEVER emit semicolons (;) or unchecked try/catch blocks.
3. ALWAYS wrap fallible operations in Result[T, E].
4. NEVER use a linear resource after disposal (!dispose res).
`;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(rawAiPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
              <Bot className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                AI Coding Agent Documentation &amp; Grammar Specification
              </h2>
              <p className="text-xs text-slate-400">
                Teach autonomous models (Gemini 3.8 Flash, Claude, GPT) to code in token-dense SPAR.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Tabs */}
        <div className="px-6 pt-3 bg-slate-950/40 border-b border-slate-800 flex gap-2">
          <button
            onClick={() => setActiveTab("prompt")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-t-lg transition border-b-2 ${
              activeTab === "prompt"
                ? "border-cyan-400 text-cyan-400 bg-slate-900"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            AI System Prompt
          </button>
          <button
            onClick={() => setActiveTab("cheat-sheet")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-t-lg transition border-b-2 ${
              activeTab === "cheat-sheet"
                ? "border-cyan-400 text-cyan-400 bg-slate-900"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            Syntax Cheat-Sheet
          </button>
          <button
            onClick={() => setActiveTab("diagnostic")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-t-lg transition border-b-2 ${
              activeTab === "diagnostic"
                ? "border-cyan-400 text-cyan-400 bg-slate-900"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            Self-Healing Telemetry
          </button>
          <button
            onClick={() => setActiveTab("usage")}
            className={`px-3 py-1.5 text-xs font-semibold rounded-t-lg transition border-b-2 ${
              activeTab === "usage"
                ? "border-cyan-400 text-cyan-400 bg-slate-900"
                : "border-transparent text-slate-400 hover:text-white"
            }`}
          >
            How to Use with LLMs
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 flex-1 overflow-y-auto space-y-4 text-xs">
          {activeTab === "prompt" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-300 font-semibold">
                  Zero-Shot System Prompt (Copy directly to AI Studio or IDE Agents):
                </span>
                <button
                  onClick={handleCopyPrompt}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-semibold shadow transition"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-300" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy System Prompt</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-cyan-300 font-mono text-[11px] leading-relaxed overflow-x-auto max-h-96">
                {rawAiPrompt}
              </pre>
            </div>
          )}

          {activeTab === "cheat-sheet" && (
            <div className="space-y-4 text-slate-300">
              <h4 className="text-sm font-bold text-white">SPAR Token &amp; Operator Directory</h4>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-cyan-400 font-mono font-bold block">Primitifs (!i, !s, !b, !f, !void)</span>
                  <p className="text-slate-400 text-[11px]">
                    Single-token primitives mapping directly to 32-bit int, string, bool, float, and unit.
                  </p>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-emerald-400 font-mono font-bold block">Refinements (?: var type pred)</span>
                  <p className="text-slate-400 text-[11px]">
                    Mathematical constraints verified at compile-time by Presburger arithmetic solver.
                  </p>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-indigo-400 font-mono font-bold block">Linear Typestate (~ S1 -&gt; S2)</span>
                  <p className="text-slate-400 text-[11px]">
                    State automata enforcing sequential transitions (Allocated -&gt; Disposed) on GPU &amp; WebSockets.
                  </p>
                </div>
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                  <span className="text-purple-400 font-mono font-bold block">Result[T, E] &amp; Postfix ?</span>
                  <p className="text-slate-400 text-[11px]">
                    Algebraic sum type for defensive error handling, unpacking with unary postfix operator.
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === "diagnostic" && (
            <div className="space-y-3">
              <h4 className="text-sm font-bold text-white">Autonomous Machine-Readable JSON Telemetry</h4>
              <p className="text-slate-400">
                When an invariant fails, feed this exact JSON structure back to the AI model. It isolates the line, col, violation, and correction rule so the model can repair it without conversational guessing.
              </p>
              <pre className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-amber-300 font-mono text-[11px] leading-relaxed">
{`{
  "status": "REJECTED",
  "error_phase": "TYPESTATE_VERIFICATION",
  "span": { "line": 14, "col": 7, "symbol": "renderer.render" },
  "violation": {
    "code": "E3002_INVALID_TYPESTATE",
    "message": "Resource 'geom' utilized in typestate 'Disposed'. Required: 'Allocated'."
  },
  "invariant_correction_rule": "Remove premature (!dispose geom) at line 12",
  "candidate_fix": "// preserve geom"
}`}
              </pre>
            </div>
          )}

          {activeTab === "usage" && (
            <div className="space-y-4 text-slate-300">
              <h4 className="text-sm font-bold text-white">How to Integrate with Autonomous AI Workflows</h4>
              <ol className="list-decimal list-inside space-y-2 text-slate-400 leading-relaxed">
                <li>
                  <strong className="text-white">Provide AI_GRAMMAR_SPEC.md:</strong> Paste into your model's System Instructions (e.g. in Google AI Studio or Cursor/Windsurf agent settings).
                </li>
                <li>
                  <strong className="text-white">Request Output in SPAR:</strong> Instruct the model: <em className="text-cyan-400">"Generate the entire full-stack application as a unified (@workspace ...) in SPAR"</em>.
                </li>
                <li>
                  <strong className="text-white">Automatic Lens Compilation:</strong> Run the generated SPAR document through the SPAR Transpiler Engine to synthesize strict TypeScript, React, Angular, Three.js, or Node files.
                </li>
                <li>
                  <strong className="text-white">Automated Feedback Loop:</strong> If the compiler flags an invariant, pass the JSON diagnostic telemetry back to the model for zero-conversation self-healing.
                </li>
              </ol>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-950 border-t border-slate-800 flex justify-between items-center text-xs text-slate-500">
          <span>Documentation File: AI_GRAMMAR_SPEC.md</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
