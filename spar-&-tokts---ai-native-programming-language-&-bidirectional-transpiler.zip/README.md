# SPAR: Semantic Polyglot AI Representation & Web Transpilation Engine

[![TypeScript](https://img.shields.io/badge/TypeScript-5.8%2B-blue)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-6.0%2B-646CFF)](https://vitejs.dev/)
[![React 19](https://img.shields.io/badge/React-19.0-61DAFB)](https://react.dev/)
[![Vue 3](https://img.shields.io/badge/Vue-3.5-4FC08D)](https://vuejs.org/)
[![Svelte 5](https://img.shields.io/badge/Svelte-5.0-FF3E00)](https://svelte.dev/)
[![FastAPI](https://img.shields.io/badge/Python-FastAPI-009688)](https://fastapi.tiangolo.com/)
[![Golang](https://img.shields.io/badge/Go-1.24-00ADD8)](https://go.dev/)
[![Rust](https://img.shields.io/badge/Rust-Axum-DEA584)](https://www.rust-lang.org/)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache_2.0-green.svg)](https://opensource.org/licenses/Apache-2.0)

> **A high-density, strictly-typed intermediate representation (IR) and bidirectional transpilation engine designed specifically for autonomous AI code synthesis across 32+ web formats using the `*.XX.spar` convention.**

---

## 🎯 The `*.XX.spar` Standard

Every SPAR file targeting a specific web programming language or framework ends with `*.XX.spar`, where `XX` is the target compilation extension:

```
src/
├── components/
│   ├── Counter.vue.spar       <--->   Counter.vue (Vue 3 SFC)
│   ├── Card.svelte.spar       <--->   Card.svelte (Svelte 5 Runes)
│   ├── App.tsx.spar           <--->   App.tsx (React 19 JSX)
│   └── Layout.astro.spar      <--->   Layout.astro (Astro Component)
├── styles/
│   ├── theme.scss.spar        <--->   theme.scss (Sassy CSS)
│   └── global.css.spar        <--->   global.css (Modern CSS3)
├── server/
│   ├── api.py.spar            <--->   api.py (Python FastAPI)
│   ├── main.go.spar           <--->   main.go (Go Net/HTTP)
│   ├── service.rs.spar        <--->   service.rs (Rust Axum)
│   └── endpoint.php.spar      <--->   endpoint.php (PHP 8.x)
└── schema/
    ├── api.graphql.spar       <--->   api.graphql (GraphQL SDL)
    └── openapi.yaml.spar      <--->   openapi.yaml (OpenAPI 3.0)
```

---

## 🚀 Supported 32+ Web Language Formats

### 1. Frontend Core & Scripts
- `*.html`, `*.htm` — HyperText Markup Language
- `*.js` — JavaScript (client & Node.js)
- `*.mjs` — JavaScript ECMAScript Module (`import` / `export`)
- `*.cjs` — CommonJS module (`require` / `module.exports`)
- `*.ts` — Statically typed TypeScript
- `*.jsx` — JavaScript with JSX syntax extension
- `*.tsx` — TypeScript with JSX syntax extension (React 19)
- `*.wasm` — WebAssembly Text (WAT) & execution representation

### 2. Styles & CSS Preprocessors
- `*.css` — Cascading Style Sheets (native browser styling)
- `*.scss` — Sassy CSS (SCSS syntax with variables and nesting)
- `*.sass` — Syntactically Awesome Style Sheets (indentation-based)
- `*.less` — Leaner Style Sheets preprocessor
- `*.styl` — Stylus expressive stylesheet preprocessor
- `*.pcss` — PostCSS source file

### 3. Single-File Components & Templates
- `*.vue` — Vue.js 3 single-file component (`<template>`, `<script setup>`, `<style scoped>`)
- `*.svelte` — Svelte 5 component with `$state` runes
- `*.astro` — Astro island component
- `*.ejs` — Embedded JavaScript templating
- `*.hbs`, `*.handlebars` — Handlebars semantic template
- `*.pug` — Pug (formerly Jade) indentation-based HTML template
- `*.twig` — Twig template engine (Symfony / PHP)
- `*.blade.php` — Laravel Blade template (`@if`, `@foreach`)

### 4. Backend & Server-Side Web Languages
- `*.php` — PHP: Hypertext Preprocessor 8.x modern classes & controllers
- `*.py` — Python (FastAPI, Flask, Django) with typed Pydantic models
- `*.rb` — Ruby (Sinatra, Ruby on Rails)
- `*.go` — Go (Golang Net/HTTP, Gin) compiled web services
- `*.cs` — C# (ASP.NET Core Minimal APIs & records)
- `*.java` — Java (Spring Boot REST controllers & records)
- `*.rs` — Rust (Axum, Actix-web) memory-safe async web services

### 5. Web Data, Config & APIs
- `*.json` — JavaScript Object Notation REST interchange
- `*.jsonld` — JSON for Linked Data (SEO Schema.org rich snippets)
- `*.graphql`, `*.gql` — GraphQL schema and query definitions
- `*.xml` — Extensible Markup Language (sitemaps, RSS feeds)
- `*.yaml`, `*.yml` — YAML (OpenAPI 3.0 / Swagger and server configurations)

---

## ⚡ Multi-File `@workspace` Compilation

Compile an entire polyglot repository in both directions:

```lisp
(@workspace "hyper-store"
  (* convention "*.XX.spar" bundler "vite" *)

  (@file "src/components/Counter.vue.spar"
    (@module ui/counter
      (* framework "vue-3" sfc true *)
      (: Props (% label !s))
      (# Counter (% props Props)
        (do
          (:= count (!state 0))
          (< button (. on:click (setCount (+ count 1)) .)
            (!str "Count: ") (!val count)
          >)
        )
      )
    )
  )

  (@file "server/api.py.spar"
    (@module server/api
      (* runtime "python-fastapi" *)
      (: Product (% id !s price !i inStock !b))
      (! getProducts (-> () [Product])
        (do
          [(% id "prod-1" price 99 inStock true)]
        )
      )
    )
  )
)
```

- **`Put: Workspace SPAR → Directory Tree`**: Automatically outputs `src/components/Counter.vue`, `server/api.py`, `package.json`, `tsconfig.json`, and all scaffolding files.
- **`Get: Directory Tree → Workspace SPAR`**: Recursively crawls your project folder and decompiles all files into `*.XX.spar` representations!

---

## 🤖 AI Model Integration

To instruct **Gemini 3.8 Flash**, **Claude 3.7**, or **GPT-4o** to write code in SPAR, see **`AI_GRAMMAR_SPEC.md`**.
Copy that file directly into your model's System Prompt or AI Studio Agent instructions.
